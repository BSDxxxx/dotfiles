// ==UserScript==
// @name 屏蔽百度右侧热点、贴吧广告
// @namespace Violentmonkey Scripts
// @match *://*.baidu.com/*
// @grant none
// ==/UserScript==
window.onload = function () {
  'use strict';
  if (document.getElementById("content_right") != null) {
    document.getElementById("content_right").remove()
  }
  $('span.label_text:contains(广告)').closest('li.clearfix').remove();
}