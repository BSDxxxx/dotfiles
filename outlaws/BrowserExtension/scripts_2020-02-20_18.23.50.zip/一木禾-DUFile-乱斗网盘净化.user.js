// ==UserScript==
// @icon         http://www.yimuhe.com/favicon.ico
// @name         一木禾/DUFile/乱斗网盘净化
// @namespace    http://tampermonkey.net/
// @version      0.2.3
// @description  屏蔽广告/优化下载流程
// @author       Avral
// @match        *://www.yimuhe.com/*
// @match        *://dufile.com/*
// @match        *://www.66disk.com/*
// @require      http://code.jquery.com/jquery-3.4.1.min.js
// @require      https://unpkg.com/tesseract.js@v2.0.0-alpha.13/dist/tesseract.min.js
// @grant        none
// @run-at       document-start
// ==/UserScript==

//计算图像的灰度值,公式为：Gray = R*0.299 + G*0.587 + B*0.114
function CalculateGrayValue(rValue,gValue,bValue){
  return parseInt(rValue * 0.299 + gValue * 0.587 + bValue * 0.114);
}

//彩色图像灰度化
function ProcessToGrayImage(canvas){
  //取得图像数据
  var ctx = canvas.getContext("2d");
  var canvasData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  //这个循环是取得图像的每一个点，在计算灰度后将灰度设置给原图像

  for (var x = 0; x < canvasData.width; x++) {
	//alert("x="+x);
	for (var y = 0; y < canvasData.height; y++) {
	  //alert("y="+y);
	  // Index of the pixel in the array
	  var idx = (x + y * canvas.width) * 4;

	  // The RGB values
	  var r = canvasData.data[idx + 0];
	  var g = canvasData.data[idx + 1];
	  var b = canvasData.data[idx + 2];
	  //更新图像数据
	  var gray = CalculateGrayValue(r , g , b);
	  canvasData.data[idx + 0] = gray;
	  canvasData.data[idx + 1] = gray;
	  canvasData.data[idx + 2] = gray;
	}
  }
  ctx.putImageData(canvasData, 0, 0);
}

//一维OTSU图像处理算法
function OTSUAlgorithm(canvas){
  var m_pFstdHistogram = new Array();//表示灰度值的分布点概率
  var m_pFGrayAccu = new Array();//其中每一个值等于m_pFstdHistogram中从0到当前下标值的和
  var m_pFGrayAve = new Array();//其中每一值等于m_pFstdHistogram中从0到当前指定下标值*对应的下标之和
  var m_pAverage=0;//值为m_pFstdHistogram【256】中每一点的分布概率*当前下标之和
  var m_pHistogram = new Array();//灰度直方图
  var i,j;
  var temp=0,fMax=0;//定义一个临时变量和一个最大类间方差的值
  var nThresh = 0;//最优阀值
  //初始化各项参数
  for(i=0; i<256; i++){
	m_pFstdHistogram[i] = 0;
	m_pFGrayAccu[i] = 0;
	m_pFGrayAve[i] = 0;
	m_pHistogram[i] = 0;
  }
  //获取图像信息
  var ctx = canvas.getContext('2d');
  var canvasData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  //获取图像的像素
  var pixels = canvasData.data;
  //下面统计图像的灰度分布信息
  for(i=0; i<pixels.length; i+=4){
	//获取r的像素值，因为灰度图像，r=g=b，所以取第一个即可
	m_pHistogram[pixels[i]]++;
  }
  //下面计算每一个灰度点在图像中出现的概率
  var size = canvasData.width * canvasData.height;
  for(i=0; i<256; i++){
	m_pFstdHistogram[i] = m_pHistogram[i] / size;
  }
  //下面开始计算m_pFGrayAccu和m_pFGrayAve和m_pAverage的值
  for(i=0; i<256; i++){
	for(j=0; j<=i; j++){
	  //计算m_pFGaryAccu[256]
	  m_pFGrayAccu[i] += m_pFstdHistogram[j];
	  //计算m_pFGrayAve[256]
	  m_pFGrayAve[i] += j * m_pFstdHistogram[j];
	}
	//计算平均值
	m_pAverage += i * m_pFstdHistogram[i];
  }
  //下面开始就算OSTU的值，从0-255个值中分别计算ostu并寻找出最大值作为分割阀值
  for (i = 0 ; i < 256 ; i++){
	temp = (m_pAverage * m_pFGrayAccu[i] - m_pFGrayAve[i])
	  * (m_pAverage * m_pFGrayAccu[i] - m_pFGrayAve[i])
	/ (m_pFGrayAccu[i] * (1 - m_pFGrayAccu[i]));
	if (temp > fMax)
	{
	  fMax = temp;
	  nThresh = i;
	}
  }
  //下面执行二值化过程
  for(i=0; i<canvasData.width; i++){
	for(j=0; j<canvasData.height; j++){
	  //取得每一点的位置
	  var ids = (i + j*canvasData.width)*4;
	  //取得像素的R分量的值
	  var r = canvasData.data[ids];
	  //与阀值进行比较，如果小于阀值，那么将改点置为0，否则置为255
	  var gray = r>nThresh?255:0;
	  canvasData.data[ids+0] = gray;
	  canvasData.data[ids+1] = gray;
	  canvasData.data[ids+2] = gray;
	}
  }
  //显示二值化图像
  ctx.putImageData(canvasData,0,0);
}

//去噪点
function ClearNoise(canvas, N, R){
  //取得图像数据
  var ctx = canvas.getContext("2d");
  var canvasData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  //有时多次降噪可能会达到较好的结果
  for (var t = 0; t < R; t++) {
	//每个点与周围8个点比较，RBG值相等小于3个的过滤
	for (var x = 0; x < canvasData.width; x++) {
	  for (var y = 0; y < canvasData.height; y++) {
		// Index of the pixel in the array
		var idx = (x + y * canvas.width) * 4;
		//if (canvasData.data[idx]==255)continue;
		var samenum = 0;
		for (var addon_x = -1; addon_x < 2; addon_x++) {
		  for (var addon_y = -1; addon_y < 2; addon_y++) {
			if (addon_x == 0 && addon_y == 0)continue;
			var nowpix = [x+addon_x, y+addon_y];
			if (nowpix[0] >= 0 &&
				nowpix[0] < canvasData.width &&
				nowpix[1] >= 0 &&
				nowpix[1] < canvasData.height) {
			  var nowidx = (nowpix[0] + nowpix[1] * canvas.width) * 4;
			  if (canvasData.data[idx] == canvasData.data[nowidx])samenum++;
			}
		  }
		}
		if (samenum<N) {
		  canvasData.data[idx + 0] = 255;
		  canvasData.data[idx + 1] = 255;
		  canvasData.data[idx + 2] = 255;
		}
	  }
	}
  }
  ctx.putImageData(canvasData, 0, 0);
}

function TestClearNoise(canvas, N, R){
  function GetPixCol(data, idx){
	var r = data[idx+0];
	var g = data[idx+1];
	var b = data[idx+2];
	return r<<16 + g<<8 + b;
  }
  //取得图像数据
  var ctx = canvas.getContext("2d");
  var canvasData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  //有时多次降噪可能会达到较好的结果
  for (var t = 0; t < R; t++) {
	//遍历每个像素点
	for (var x = 0; x < canvasData.width; x++) {
	  for (var y = 0; y < canvasData.height; y++) {
		// Index of the pixel in the array
		var idx = (x + y * canvas.width) * 4;
		var col = GetPixCol(canvasData.data, idx);
		var samenum = 0;
		var difcol = new Array();
		//取周围8个点坐标
		for (var addon_x = -1; addon_x < 2; addon_x++) {
		  for (var addon_y = -1; addon_y < 2; addon_y++) {
			if (addon_x == 0 && addon_y == 0)continue;
			var nowpix = [x+addon_x, y+addon_y];
			if (nowpix[0] < 0 || nowpix[0] >= canvasData.width || nowpix[1] < 0 || nowpix[1] >= canvasData.height)continue;
			var nowidx = (nowpix[0] + nowpix[1] * canvas.width) * 4;
			var nowcol = GetPixCol(canvasData.data, nowidx);
			//比较点颜色
			if (col == nowcol) {
			  samenum++;
			} else {
			  difcol[nowcol] = (difcol[nowcol] ? difcol[nowcol] : 0) + 1;
			}
		  }
		}
		var diff = new Array();
		diff[1] = -1;
		for (var col2num in difcol) {
		  if (diff[1] < difcol[col2num]) {
			diff[0] = col2num;
			diff[1] = difcol[col2num];
		  }
		}
		if (samenum<1 && diff[1] > 1) {
		  canvasData.data[idx + 0] = (diff[0]>>16)&0xFF;
		  canvasData.data[idx + 1] = (diff[0]>>8)&0xFF;
		  canvasData.data[idx + 2] = (diff[0]>>0)&0xFF;
		}
	  }
	}
  }
  ctx.putImageData(canvasData, 0, 0);
}

function  testcanvas(img){
  var canvas = document.createElement("canvas");
  canvas.width = img.width;
  canvas.height = img.height;

  var ctx = canvas.getContext("2d");
  ctx.drawImage(img, 0, 0, img.width, img.height);

  ProcessToGrayImage(canvas);
  OTSUAlgorithm(canvas);
  ClearNoise(canvas, 3, 3);

  /*TestClearNoise(canvas, 1, 1);
  ProcessToGrayImage(canvas);
  OTSUAlgorithm(canvas);*/

  // $('form[name="yzcode"]')[0].appendChild(canvas);
  return canvas;
}

(function() {
  'use strict';
  var window_url = window.location.href;
  var website_host = window.location.host;
  if(window_url.indexOf("/file")!=-1){
	if(website_host == 'dufile.com')
	{
	  $(document).ready(function(){
		if($('#down_interval_tag')[0]==null){
		  window.location.href = window_url.replace("/file", "/down");
		}
	  });
	  return;
	}
	window.location.href = window_url.replace("/file", "/down");
	return;
  }
  window.adsbygoogle = [];
  document.onclick = function(){}
  document.onkeydown = function(){}
  document.write = function(){}
  document.writeln = function(){}
  window.__qy_pop_up_tg = {}

  $(document).ready(function(){
	var vcode = $('#vcode_img')[0];
	if (!vcode)return;
	vcode.onload = function(){
	  const worker = new Tesseract.TesseractWorker();
	  var canvas = testcanvas($('#vcode_img')[0]);
	  worker.recognize(canvas, 'eng', {
		/*tessedit_ocr_engine_mode:0,
	  tessedit_pageseg_mode:1,*/
		classify_bln_numeric_mode:1,
		tessedit_char_whitelist:"0123456789",
	  })
		.then(result => {
		var yzcodestr = result.text.replace(/[^0-9]/ig,"");
		$('#code')[0].value = yzcodestr;
	  });
	}
	if (website_host == 'dufile.com')
	{
	}
	else if (website_host == 'www.yimuhe.com')
	{
	  var yzmdiv = $('#yzm')[0];
	  if (yzmdiv != null){
		yzmdiv.style.display = '';
	  }
	  var loaddiv = $('#loading')[0];
	  if (loaddiv != null){
		loaddiv.style.display = 'none';
	  }
	}
  });
  document.putcode = function(id) {
	function mydown_file (id) {
	  var u = document.createElement("iframe");
	  if (website_host == 'dufile.com'){
		u.src = '/dd.php?file_key=' + id + '&p=1';
	  }else if (website_host == 'www.yimuhe.com'){

		u.src = "/n_dd.php?file_id=" + id + "&p=1&types=http&ser=99";// + "&userlogin=" + uploaduser + "&file_name=" + name;  + ser + "&file_key=" + key
	  }
	  u.style.display = "none";
	  var onl = function(){
		//console.log(u.contentWindow.document.getElementById("downs"));
		window.location.href = u.contentWindow.document.getElementById("downs").href;
	  }
	  if (u.attachEvent){
		u.attachEvent("onload", onl);
	  } else {
		u.onload = onl;
	  }
	  document.body.appendChild(u);
	}

	var code = $('#code')[0].value;
	if (code == '') {
	  alert("请填写验证码。");
	  return false
	}
	var url = "";
	if (website_host == 'dufile.com'){
	  url = '/downcode.php';
	}else if (website_host == 'www.yimuhe.com'){
	  url = '/n_downcode.php';
	}
	$.ajax({
	  url: url,
	  type: "post",
	  data: {
		action: "yz",
		id: id,
		code: code
	  },
	  dataType: "text",
	  error: function() {
		alert('提交失败。');
		return false;
	  },
	  success: function(result) {
		if (result == 1) {
		  mydown_file(id, '1', 'http');
		} else {
		  if (result == 0) {
			alert("验证码不正确")
		  } else {
			alert("下载地址已超时，请重新下载。");
			if (website_host == 'dufile.com'){
			  window.location.href = ('/file/' + result + '.html')
			}else if (website_host == 'www.yimuhe.com'){
			  window.location.href = ('/file-' + result + '.html');
			}
		  }
		}
	  }
	})
  }
})();