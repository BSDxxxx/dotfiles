// ==UserScript==
// @name 多吉搜索重定向
// @description 重定向多吉未完成的功能到谷歌搜索
// @namespace Violentmonkey Scripts
// @match https://www.dogedoge.com/results
// @require https://cdn.jsdelivr.net/npm/jquery@3.4.1/dist/jquery.min.js
// @run-at document-body
// @version 0.0.1.20190729044109
// ==/UserScript==
(function(){
  var GoogleRoot='https://www.google.com/search?q=';
  var keyword=window.location.search.split('=')[1];
  $("a[data-zci-link='web']").attr('href',GoogleRoot+keyword).attr('target','_blank');
  $("a[data-zci-link='images']").attr('href',GoogleRoot+keyword+'&tbm=isch').attr('target','_blank');
  $("a[data-zci-link='videos']").attr('href',GoogleRoot+keyword+'&tbm=lnms').attr('target','_blank');
  $("a[data-zci-link='news']").attr('href',GoogleRoot+keyword+'&tbm=nws').attr('target','_blank');
})();