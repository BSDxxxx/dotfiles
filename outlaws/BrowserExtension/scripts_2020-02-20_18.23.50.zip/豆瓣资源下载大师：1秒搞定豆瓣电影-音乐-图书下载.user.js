// ==UserScript==
// @name           豆瓣资源下载大师：1秒搞定豆瓣电影|音乐|图书下载
// @description    【装这一个脚本就够了！可能是你遇到的最好的豆瓣增强脚本】聚合数百家资源网站，通过右侧边栏1秒告诉你哪些网站能下载豆瓣页面上的电影|电视剧|纪录片|综艺|动画|音乐|图书等，有资源的网站显示绿色，没资源的网站显示黄色，就这么直观！所有豆瓣条目均提供在线播放|阅读、字幕|歌词下载及PT|NZB|BT|磁力|百度盘|115网盘等下载链接，加入官网打死也不出的豆列搜索功能，此外还能给豆瓣条目额外添加IMDB评分|IMDB TOP 250|Metascore评分|烂番茄评分|AniDB评分|Bgm评分|MAL评分等更多评分形式。官方电报群：@doubandown，官方QQ群：691023412，验证口令：imdb
// @author         白鸽男孩
// @contributor    Rhilip
// @connect        *
// @grant          GM_xmlhttpRequest
// @grant          GM_setClipboard
// @grant          GM_addStyle
// @grant          GM_setValue
// @grant          GM_getValue
// @grant          GM_listValues
// @grant          GM_deleteValue
// @grant          GM_registerMenuCommand
// @require        http://cdn.bootcss.com/jquery/3.2.1/jquery.min.js
// @require        https://greasyfork.org/scripts/368137-encodeToGb2312/code/encodeToGb2312.js?version=601683
// @include        https://movie.douban.com/*
// @include        https://music.douban.com/*
// @include        https://book.douban.com/*
// @include        https://bangumi.moe/search/title*
// @include        https://www.80s.tw/search*
// @include        http://www.dingzibd.com/q*
// @include        http://www.xzpc6.com/*
// @version        6.8.8
// @icon           https://img3.doubanio.com/favicon.ico
// @run-at         document-start
// @namespace      doveboy_js
// ==/UserScript==

// This Userscirpt can't run under Greasemonkey 4.x platform
if (typeof GM_xmlhttpRequest === "undefined") {
    alert("不支持Greasemonkey 4.x，请换用暴力猴或Tampermonkey");
    return;
}

// 不属于豆瓣的页面
if (!/douban.com/.test(location.host)) {
    function AutoSearch(host, zInputSelector, btnSelector, dict) {
        if (location.host == host) {
            let match = location.href.match(/#search_(.+)/);  // 从url的hash部分获取搜索关键词
            if (match) {
                history.pushState("", document.title, window.location.pathname + window.location.search); // 清空hash
                window.addEventListener("load", function () {  // 等待页面完全加载完成
                    let zInput = $(zInputSelector);
                    zInput.val(decodeURIComponent(match[1])); // 填入搜索值
                    dict = $.extend({}, dict);
                    if (dict.ang) { // 补加Event，防止Angular绑定失效。 From: https://stackoverflow.com/questions/34360739/automate-form-submission-on-an-angularjs-website-using-tampermonkey
                        let changeEvent = document.createEvent("HTMLEvents");
                        changeEvent.initEvent("change", true, true);
                        zInput[0].dispatchEvent(changeEvent);
                    }
                    if (dict.notarget) {  // 取消form的提交跳转
                        $(btnSelector).parents("form").attr("target", "_self");
                    }
                    $(btnSelector).click(); // 模拟点击
                });
            }
        }
    }

    AutoSearch("bangumi.moe", '#filter-tag-list div.torrent-title-search > md-input-group > input', '#filter-tag-list > div.torrent-search > div:nth-child(3) > button:nth-child(4)', { ang: true });
    AutoSearch("www.80s.tw", '#search-box', 'input.search-btn', {});
    AutoSearch("www.dingzibd.com", '#keyword', '#searchBtn', {});
    AutoSearch("www.xzpc6.com", 'input[name="key"]', 'dl.widget.divSouSou input[type="submit"]', { notarget: true });

    return; // 终止脚本运行，防止豆瓣的css以及js片段等污染页面
}

let myScriptStyle = "@charset utf-8;#dale_movie_subject_top_right,#dale_movie_subject_top_right,#dale_movie_subject_top_midle,#dale_movie_subject_middle_right,#dale_movie_subject_bottom_super_banner,#footer,#dale_movie_subject_download_middle,#dale_movie_subject_inner_middle,#movie_home_left_bottom,#dale_movie_home_top_right,#dale_movie_home_side_top,#dale_movie_home_bottom_right,#dale_movie_home_inner_bottom,#dale_movie_home_download_bottom,#dale_movie_home_bottom_right_down,#dale_movie_towhome_explore_right,#dale_movie_chart_top_right,#dale_movie_tags_top_right,#dale_review_best_top_right,.mobile-app-entrance.block5.app-movie,.qrcode-app,.top-nav-doubanapp,.extra,div.gray_ad,p.pl,div.ticket{display:none}.c-aside{margin-bottom:30px}.c-aside-body{*letter-spacing:normal}.c-aside-body a{border-radius:6px;color:#37A;display:inline-block;letter-spacing:normal;margin:0 8px 8px 0;padding:0 8px;text-align:center;width:65px}.c-aside-body a:link,.c-aside-body a:visited{background-color:#f5f5f5;color:#37A}.c-aside-body a:hover,.c-aside-body a:active{background-color:#e8e8e8;color:#37A}.c-aside-body a.disabled{}.c-aside-body a.available{background-color:#5ccccc;color:#006363}.c-aside-body a.available:hover,.c-aside-body a.available:active{background-color:#3cc}.c-aside-body a.sites_r0{text-decoration:line-through}#c_dialog li{margin:10px}#c_dialog{text-align:center}#interest_sectl .rating_imdb{border-top:1px solid #eaeaea;border-bottom:1px solid #eaeaea;padding-bottom:0}#interest_sectl .rating_wrap{padding-top:15px}#interest_sectl .rating_more{border-bottom:1px solid #eaeaea;color:#9b9b9b;margin:0;padding:15px 0;position:relative}#interest_sectl .rating_more a{left:80px;position:absolute}#interest_sectl .rating_more .titleOverviewSprite{background:url(https://coding.net/u/Changhw/p/MyDoubanMovieHelper/git/raw/master/title_overview_sprite.png) no-repeat;display:inline-block;vertical-align:middle}#interest_sectl .rating_more .popularityImageUp{background-position:-14px -478px;height:8px;width:8px}#interest_sectl .rating_more .popularityImageDown{background-position:-34px -478px;height:8px;width:8px}#interest_sectl .rating_more .popularityUpOrFlat{color:#83C40B}#interest_sectl .rating_more .popularityDown{color:#930E02}/*!jQuery UI - v1.12.1 - 2016-09-14 * http://jqueryui.com * Includes:core.css,accordion.css,autocomplete.css,menu.css,button.css,controlgroup.css,checkboxradio.css,datepicker.css,dialog.css,draggable.css,resizable.css,progressbar.css,selectable.css,selectmenu.css,slider.css,sortable.css,spinner.css,tabs.css,tooltip.css,theme.css * To view and modify this theme,visit http://jqueryui.com/themeroller/?bgShadowXPos=&bgOverlayXPos=&bgErrorXPos=&bgHighlightXPos=&bgContentXPos=&bgHeaderXPos=&bgActiveXPos=&bgHoverXPos=&bgDefaultXPos=&bgShadowYPos=&bgOverlayYPos=&bgErrorYPos=&bgHighlightYPos=&bgContentYPos=&bgHeaderYPos=&bgActiveYPos=&bgHoverYPos=&bgDefaultYPos=&bgShadowRepeat=&bgOverlayRepeat=&bgErrorRepeat=&bgHighlightRepeat=&bgContentRepeat=&bgHeaderRepeat=&bgActiveRepeat=&bgHoverRepeat=&bgDefaultRepeat=&iconsHover=url(%22images%2Fui-icons_555555_256x240.png%22)&iconsHighlight=url(%22images%2Fui-icons_777620_256x240.png%22)&iconsHeader=url(%22images%2Fui-icons_444444_256x240.png%22)&iconsError=url(%22images%2Fui-icons_cc0000_256x240.png%22)&iconsDefault=url(%22images%2Fui-icons_777777_256x240.png%22)&iconsContent=url(%22images%2Fui-icons_444444_256x240.png%22)&iconsActive=url(%22images%2Fui-icons_ffffff_256x240.png%22)&bgImgUrlShadow=&bgImgUrlOverlay=&bgImgUrlHover=&bgImgUrlHighlight=&bgImgUrlHeader=&bgImgUrlError=&bgImgUrlDefault=&bgImgUrlContent=&bgImgUrlActive=&opacityFilterShadow=Alpha(Opacity%3D30)&opacityFilterOverlay=Alpha(Opacity%3D30)&opacityShadowPerc=30&opacityOverlayPerc=30&iconColorHover=%23555555&iconColorHighlight=%23777620&iconColorHeader=%23444444&iconColorError=%23cc0000&iconColorDefault=%23777777&iconColorContent=%23444444&iconColorActive=%23ffffff&bgImgOpacityShadow=0&bgImgOpacityOverlay=0&bgImgOpacityError=95&bgImgOpacityHighlight=55&bgImgOpacityContent=75&bgImgOpacityHeader=75&bgImgOpacityActive=65&bgImgOpacityHover=75&bgImgOpacityDefault=75&bgTextureShadow=flat&bgTextureOverlay=flat&bgTextureError=flat&bgTextureHighlight=flat&bgTextureContent=flat&bgTextureHeader=flat&bgTextureActive=flat&bgTextureHover=flat&bgTextureDefault=flat&cornerRadius=3px&fwDefault=normal&ffDefault=Arial%2CHelvetica%2Csans-serif&fsDefault=1em&cornerRadiusShadow=8px&thicknessShadow=5px&offsetLeftShadow=0px&offsetTopShadow=0px&opacityShadow=.3&bgColorShadow=%23666666&opacityOverlay=.3&bgColorOverlay=%23aaaaaa&fcError=%235f3f3f&borderColorError=%23f1a899&bgColorError=%23fddfdf&fcHighlight=%23777620&borderColorHighlight=%23dad55e&bgColorHighlight=%23fffa90&fcContent=%23333333&borderColorContent=%23dddddd&bgColorContent=%23ffffff&fcHeader=%23333333&borderColorHeader=%23dddddd&bgColorHeader=%23e9e9e9&fcActive=%23ffffff&borderColorActive=%23003eff&bgColorActive=%23007fff&fcHover=%232b2b2b&borderColorHover=%23cccccc&bgColorHover=%23ededed&fcDefault=%23454545&borderColorDefault=%23c5c5c5&bgColorDefault=%23f6f6f6 * Copyright jQuery Foundation and other contributors;Licensed MIT */ .ui-helper-hidden{display:none}.ui-helper-hidden-accessible{border:0;clip:rect(0 0 0 0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px}.ui-helper-reset{border:0;font-size:100%;line-height:1.3;list-style:none;margin:0;outline:0;padding:0;text-decoration:none}.ui-helper-clearfix:before,.ui-helper-clearfix:after{border-collapse:collapse;content:'';display:table}.ui-helper-clearfix:after{clear:both}.ui-helper-zfix{height:100%;left:0;opacity:0;position:absolute;top:0;width:100%;filter:Alpha(Opacity=0)}.ui-front{z-index:100}.ui-state-disabled{cursor:default !important;pointer-events:none}.ui-icon{background-repeat:no-repeat;display:inline-block;margin-top:-.25em;overflow:hidden;position:relative;text-indent:-99999px;vertical-align:middle}.ui-widget-icon-block{display:block;left:50%;margin-left:-8px}.ui-widget-overlay{height:100%;left:0;position:fixed;top:0;width:100%}.ui-accordion .ui-accordion-header{cursor:pointer;display:block;font-size:100%;margin:2px 0 0 0;padding:.5em .5em .5em .7em;position:relative}.ui-accordion .ui-accordion-content{border-top:0;overflow:auto;padding:1em 2.2em}.ui-autocomplete{cursor:default;left:0;position:absolute;top:0}.ui-menu{display:block;list-style:none;margin:0;outline:0;padding:0}.ui-menu .ui-menu{position:absolute}.ui-menu .ui-menu-item{cursor:pointer;list-style-image:url(data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7);margin:0}.ui-menu .ui-menu-item-wrapper{padding:3px 1em 3px .4em;position:relative}.ui-menu .ui-menu-divider{border-width:1px 0 0 0;font-size:0;height:0;line-height:0;margin:5px 0}.ui-menu .ui-state-focus,.ui-menu .ui-state-active{margin:-1px}.ui-menu-icons{position:relative}.ui-menu-icons .ui-menu-item-wrapper{padding-left:2em}.ui-menu .ui-icon{bottom:0;left:.2em;margin:auto 0;position:absolute;top:0}.ui-menu .ui-menu-icon{left:auto;right:0}.ui-button{cursor:pointer;display:inline-block;line-height:normal;margin-right:.1em;overflow:visible;padding:.4em 1em;position:relative;text-align:center;vertical-align:middle;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.ui-button,.ui-button:link,.ui-button:visited,.ui-button:hover,.ui-button:active{text-decoration:none}.ui-button-icon-only{box-sizing:border-box;text-indent:-9999px;white-space:nowrap;width:2em}input.ui-button.ui-button-icon-only{text-indent:0}.ui-button-icon-only .ui-icon{left:50%;margin-left:-8px;margin-top:-8px;position:absolute;top:50%}.ui-button.ui-icon-notext .ui-icon{height:2.1em;padding:0;text-indent:-9999px;white-space:nowrap;width:2.1em}input.ui-button.ui-icon-notext .ui-icon{height:auto;padding:.4em 1em;text-indent:0;white-space:normal;width:auto}input.ui-button::-moz-focus-inner,button.ui-button::-moz-focus-inner{border:0;padding:0}.ui-controlgroup{display:inline-block;vertical-align:middle}.ui-controlgroup>.ui-controlgroup-item{float:left;margin-left:0;margin-right:0}.ui-controlgroup>.ui-controlgroup-item:focus,.ui-controlgroup>.ui-controlgroup-item.ui-visual-focus{z-index:9999}.ui-controlgroup-vertical>.ui-controlgroup-item{display:block;float:none;margin-bottom:0;margin-top:0;text-align:left;width:100%}.ui-controlgroup-vertical .ui-controlgroup-item{box-sizing:border-box}.ui-controlgroup .ui-controlgroup-label{padding:.4em 1em}.ui-controlgroup .ui-controlgroup-label span{font-size:80%}.ui-controlgroup-horizontal .ui-controlgroup-label + .ui-controlgroup-item{border-left:none}.ui-controlgroup-vertical .ui-controlgroup-label + .ui-controlgroup-item{border-top:none}.ui-controlgroup-horizontal .ui-controlgroup-label.ui-widget-content{border-right:none}.ui-controlgroup-vertical .ui-controlgroup-label.ui-widget-content{border-bottom:none}.ui-controlgroup-vertical .ui-spinner-input{width:75%;width:calc(100% - 2.4em)}.ui-controlgroup-vertical .ui-spinner .ui-spinner-up{border-top-style:solid}.ui-checkboxradio-label .ui-icon-background{border:0;border-radius:.12em;box-shadow:inset 1px 1px 1px #ccc}.ui-checkboxradio-radio-label .ui-icon-background{border:0;border-radius:1em;height:16px;overflow:visible;width:16px}.ui-checkboxradio-radio-label.ui-checkboxradio-checked .ui-icon,.ui-checkboxradio-radio-label.ui-checkboxradio-checked:hover .ui-icon{background-image:none;border-style:solid;border-width:4px;height:8px;width:8px}.ui-checkboxradio-disabled{pointer-events:none}.ui-datepicker{display:none;padding:.2em .2em 0;width:17em}.ui-datepicker .ui-datepicker-header{padding:.2em 0;position:relative}.ui-datepicker .ui-datepicker-prev,.ui-datepicker .ui-datepicker-next{height:1.8em;position:absolute;top:2px;width:1.8em}.ui-datepicker .ui-datepicker-prev-hover,.ui-datepicker .ui-datepicker-next-hover{top:1px}.ui-datepicker .ui-datepicker-prev{left:2px}.ui-datepicker .ui-datepicker-next{right:2px}.ui-datepicker .ui-datepicker-prev-hover{left:1px}.ui-datepicker .ui-datepicker-next-hover{right:1px}.ui-datepicker .ui-datepicker-prev span,.ui-datepicker .ui-datepicker-next span{display:block;left:50%;margin-left:-8px;margin-top:-8px;position:absolute;top:50%}.ui-datepicker .ui-datepicker-title{line-height:1.8em;margin:0 2.3em;text-align:center}.ui-datepicker .ui-datepicker-title select{font-size:1em;margin:1px 0}.ui-datepicker select.ui-datepicker-month,.ui-datepicker select.ui-datepicker-year{width:45%}.ui-datepicker table{border-collapse:collapse;font-size:.9em;margin:0 0 .4em;width:100%}.ui-datepicker th{border:0;font-weight:bold;padding:.7em .3em;text-align:center}.ui-datepicker td{border:0;padding:1px}.ui-datepicker td span,.ui-datepicker td a{display:block;padding:.2em;text-align:right;text-decoration:none}.ui-datepicker .ui-datepicker-buttonpane{background-image:none;border-bottom:0;border-left:0;border-right:0;margin:.7em 0 0 0;padding:0 .2em}.ui-datepicker .ui-datepicker-buttonpane button{cursor:pointer;float:right;margin:.5em .2em .4em;overflow:visible;padding:.2em .6em .3em .6em;width:auto}.ui-datepicker .ui-datepicker-buttonpane button.ui-datepicker-current{float:left}.ui-datepicker.ui-datepicker-multi{width:auto}.ui-datepicker-multi .ui-datepicker-group{float:left}.ui-datepicker-multi .ui-datepicker-group table{margin:0 auto .4em;width:95%}.ui-datepicker-multi-2 .ui-datepicker-group{width:50%}.ui-datepicker-multi-3 .ui-datepicker-group{width:33.3%}.ui-datepicker-multi-4 .ui-datepicker-group{width:25%}.ui-datepicker-multi .ui-datepicker-group-last .ui-datepicker-header,.ui-datepicker-multi .ui-datepicker-group-middle .ui-datepicker-header{border-left-width:0}.ui-datepicker-multi .ui-datepicker-buttonpane{clear:left}.ui-datepicker-row-break{clear:both;font-size:0;width:100%}.ui-datepicker-rtl{direction:rtl}.ui-datepicker-rtl .ui-datepicker-prev{left:auto;right:2px}.ui-datepicker-rtl .ui-datepicker-next{left:2px;right:auto}.ui-datepicker-rtl .ui-datepicker-prev:hover{left:auto;right:1px}.ui-datepicker-rtl .ui-datepicker-next:hover{left:1px;right:auto}.ui-datepicker-rtl .ui-datepicker-buttonpane{clear:right}.ui-datepicker-rtl .ui-datepicker-buttonpane button{float:left}.ui-datepicker-rtl .ui-datepicker-buttonpane button.ui-datepicker-current,.ui-datepicker-rtl .ui-datepicker-group{float:right}.ui-datepicker-rtl .ui-datepicker-group-last .ui-datepicker-header,.ui-datepicker-rtl .ui-datepicker-group-middle .ui-datepicker-header{border-left-width:1px;border-right-width:0}.ui-datepicker .ui-icon{background-repeat:no-repeat;display:block;left:.5em;overflow:hidden;text-indent:-99999px;top:.3em}.ui-dialog{left:0;outline:0;padding:.2em;position:absolute;top:0}.ui-dialog .ui-dialog-titlebar{padding:.4em 1em;position:relative}.ui-dialog .ui-dialog-title{float:left;margin:.1em 0;overflow:hidden;white-space:nowrap;width:90%;text-overflow:ellipsis}.ui-dialog .ui-dialog-titlebar-close{height:20px;margin:-10px 0 0 0;padding:1px;position:absolute;right:.3em;top:50%;width:20px}.ui-dialog .ui-dialog-content{background:none;border:0;overflow:auto;padding:.5em 1em;position:relative}.ui-dialog .ui-dialog-buttonpane{background-image:none;border-width:1px 0 0 0;margin-top:.5em;padding:.3em 1em .5em .4em;text-align:left}.ui-dialog .ui-dialog-buttonpane .ui-dialog-buttonset{float:right}.ui-dialog .ui-dialog-buttonpane button{cursor:pointer;margin:.5em .4em .5em 0}.ui-dialog .ui-resizable-n{height:2px;top:0}.ui-dialog .ui-resizable-e{right:0;width:2px}.ui-dialog .ui-resizable-s{bottom:0;height:2px}.ui-dialog .ui-resizable-w{left:0;width:2px}.ui-dialog .ui-resizable-se,.ui-dialog .ui-resizable-sw,.ui-dialog .ui-resizable-ne,.ui-dialog .ui-resizable-nw{height:7px;width:7px}.ui-dialog .ui-resizable-se{bottom:0;right:0}.ui-dialog .ui-resizable-sw{bottom:0;left:0}.ui-dialog .ui-resizable-ne{right:0;top:0}.ui-dialog .ui-resizable-nw{left:0;top:0}.ui-draggable .ui-dialog-titlebar{cursor:move}.ui-draggable-handle{-ms-touch-action:none;touch-action:none}.ui-resizable{position:relative}.ui-resizable-handle{display:block;font-size:.1px;position:absolute;-ms-touch-action:none;touch-action:none}.ui-resizable-disabled .ui-resizable-handle,.ui-resizable-autohide .ui-resizable-handle{display:none}.ui-resizable-n{cursor:n-resize;height:7px;left:0;top:-5px;width:100%}.ui-resizable-s{bottom:-5px;cursor:s-resize;height:7px;left:0;width:100%}.ui-resizable-e{cursor:e-resize;height:100%;right:-5px;top:0;width:7px}.ui-resizable-w{cursor:w-resize;height:100%;left:-5px;top:0;width:7px}.ui-resizable-se{bottom:1px;cursor:se-resize;height:12px;right:1px;width:12px}.ui-resizable-sw{bottom:-5px;cursor:sw-resize;height:9px;left:-5px;width:9px}.ui-resizable-nw{cursor:nw-resize;height:9px;left:-5px;top:-5px;width:9px}.ui-resizable-ne{cursor:ne-resize;height:9px;right:-5px;top:-5px;width:9px}.ui-progressbar{height:2em;overflow:hidden;text-align:left}.ui-progressbar .ui-progressbar-value{height:100%;margin:-1px}.ui-progressbar .ui-progressbar-overlay{background:url(data:image/gif;base64,R0lGODlhKAAoAIABAAAAAP///yH/C05FVFNDQVBFMi4wAwEAAAAh+QQJAQABACwAAAAAKAAoAAACkYwNqXrdC52DS06a7MFZI+4FHBCKoDeWKXqymPqGqxvJrXZbMx7Ttc+w9XgU2FB3lOyQRWET2IFGiU9m1frDVpxZZc6bfHwv4c1YXP6k1Vdy292Fb6UkuvFtXpvWSzA+HycXJHUXiGYIiMg2R6W459gnWGfHNdjIqDWVqemH2ekpObkpOlppWUqZiqr6edqqWQAAIfkECQEAAQAsAAAAACgAKAAAApSMgZnGfaqcg1E2uuzDmmHUBR8Qil95hiPKqWn3aqtLsS18y7G1SzNeowWBENtQd+T1JktP05nzPTdJZlR6vUxNWWjV+vUWhWNkWFwxl9VpZRedYcflIOLafaa28XdsH/ynlcc1uPVDZxQIR0K25+cICCmoqCe5mGhZOfeYSUh5yJcJyrkZWWpaR8doJ2o4NYq62lAAACH5BAkBAAEALAAAAAAoACgAAAKVDI4Yy22ZnINRNqosw0Bv7i1gyHUkFj7oSaWlu3ovC8GxNso5fluz3qLVhBVeT/Lz7ZTHyxL5dDalQWPVOsQWtRnuwXaFTj9jVVh8pma9JjZ4zYSj5ZOyma7uuolffh+IR5aW97cHuBUXKGKXlKjn+DiHWMcYJah4N0lYCMlJOXipGRr5qdgoSTrqWSq6WFl2ypoaUAAAIfkECQEAAQAsAAAAACgAKAAAApaEb6HLgd/iO7FNWtcFWe+ufODGjRfoiJ2akShbueb0wtI50zm02pbvwfWEMWBQ1zKGlLIhskiEPm9R6vRXxV4ZzWT2yHOGpWMyorblKlNp8HmHEb/lCXjcW7bmtXP8Xt229OVWR1fod2eWqNfHuMjXCPkIGNileOiImVmCOEmoSfn3yXlJWmoHGhqp6ilYuWYpmTqKUgAAIfkECQEAAQAsAAAAACgAKAAAApiEH6kb58biQ3FNWtMFWW3eNVcojuFGfqnZqSebuS06w5V80/X02pKe8zFwP6EFWOT1lDFk8rGERh1TTNOocQ61Hm4Xm2VexUHpzjymViHrFbiELsefVrn6XKfnt2Q9G/+Xdie499XHd2g4h7ioOGhXGJboGAnXSBnoBwKYyfioubZJ2Hn0RuRZaflZOil56Zp6iioKSXpUAAAh+QQJAQABACwAAAAAKAAoAAACkoQRqRvnxuI7kU1a1UU5bd5tnSeOZXhmn5lWK3qNTWvRdQxP8qvaC+/yaYQzXO7BMvaUEmJRd3TsiMAgswmNYrSgZdYrTX6tSHGZO73ezuAw2uxuQ+BbeZfMxsexY35+/Qe4J1inV0g4x3WHuMhIl2jXOKT2Q+VU5fgoSUI52VfZyfkJGkha6jmY+aaYdirq+lQAACH5BAkBAAEALAAAAAAoACgAAAKWBIKpYe0L3YNKToqswUlvznigd4wiR4KhZrKt9Upqip61i9E3vMvxRdHlbEFiEXfk9YARYxOZZD6VQ2pUunBmtRXo1Lf8hMVVcNl8JafV38aM2/Fu5V16Bn63r6xt97j09+MXSFi4BniGFae3hzbH9+hYBzkpuUh5aZmHuanZOZgIuvbGiNeomCnaxxap2upaCZsq+1kAACH5BAkBAAEALAAAAAAoACgAAAKXjI8By5zf4kOxTVrXNVlv1X0d8IGZGKLnNpYtm8Lr9cqVeuOSvfOW79D9aDHizNhDJidFZhNydEahOaDH6nomtJjp1tutKoNWkvA6JqfRVLHU/QUfau9l2x7G54d1fl995xcIGAdXqMfBNadoYrhH+Mg2KBlpVpbluCiXmMnZ2Sh4GBqJ+ckIOqqJ6LmKSllZmsoq6wpQAAAh+QQJAQABACwAAAAAKAAoAAAClYx/oLvoxuJDkU1a1YUZbJ59nSd2ZXhWqbRa2/gF8Gu2DY3iqs7yrq+xBYEkYvFSM8aSSObE+ZgRl1BHFZNr7pRCavZ5BW2142hY3AN/zWtsmf12p9XxxFl2lpLn1rseztfXZjdIWIf2s5dItwjYKBgo9yg5pHgzJXTEeGlZuenpyPmpGQoKOWkYmSpaSnqKileI2FAAACH5BAkBAAEALAAAAAAoACgAAAKVjB+gu+jG4kORTVrVhRlsnn2dJ3ZleFaptFrb+CXmO9OozeL5VfP99HvAWhpiUdcwkpBH3825AwYdU8xTqlLGhtCosArKMpvfa1mMRae9VvWZfeB2XfPkeLmm18lUcBj+p5dnN8jXZ3YIGEhYuOUn45aoCDkp16hl5IjYJvjWKcnoGQpqyPlpOhr3aElaqrq56Bq7VAAAOw==);height:100%;opacity:.25;filter:alpha(opacity=25)}.ui-progressbar-indeterminate .ui-progressbar-value{background-image:none}.ui-selectable{-ms-touch-action:none;touch-action:none}.ui-selectable-helper{border:1px dotted black;position:absolute;z-index:100}.ui-selectmenu-menu{display:none;left:0;margin:0;padding:0;position:absolute;top:0}.ui-selectmenu-menu .ui-menu{overflow:auto;overflow-x:hidden;padding-bottom:1px}.ui-selectmenu-menu .ui-menu .ui-selectmenu-optgroup{border:0;font-size:1em;font-weight:bold;height:auto;line-height:1.5;margin:.5em 0 0 0;padding:2px .4em}.ui-selectmenu-open{display:block}.ui-selectmenu-text{display:block;margin-right:20px;overflow:hidden;text-overflow:ellipsis}.ui-selectmenu-button.ui-button{text-align:left;white-space:nowrap;width:14em}.ui-selectmenu-icon.ui-icon{float:right;margin-top:0}.ui-slider{position:relative;text-align:left}.ui-slider .ui-slider-handle{cursor:default;height:1.2em;position:absolute;width:1.2em;z-index:2;-ms-touch-action:none;touch-action:none}.ui-slider .ui-slider-range{background-position:0 0;border:0;display:block;font-size:.7em;position:absolute;z-index:1}.ui-slider.ui-state-disabled .ui-slider-handle,.ui-slider.ui-state-disabled .ui-slider-range{filter:inherit}.ui-slider-horizontal{height:.8em}.ui-slider-horizontal .ui-slider-handle{margin-left:-.6em;top:-.3em}.ui-slider-horizontal .ui-slider-range{height:100%;top:0}.ui-slider-horizontal .ui-slider-range-min{left:0}.ui-slider-horizontal .ui-slider-range-max{right:0}.ui-slider-vertical{height:100px;width:.8em}.ui-slider-vertical .ui-slider-handle{left:-.3em;margin-bottom:-.6em;margin-left:0}.ui-slider-vertical .ui-slider-range{left:0;width:100%}.ui-slider-vertical .ui-slider-range-min{bottom:0}.ui-slider-vertical .ui-slider-range-max{top:0}.ui-sortable-handle{-ms-touch-action:none;touch-action:none}.ui-spinner{display:inline-block;overflow:hidden;padding:0;position:relative;vertical-align:middle}.ui-spinner-input{background:none;border:0;color:inherit;margin:.2em 0;margin-left:.4em;margin-right:2em;padding:.222em 0;vertical-align:middle}.ui-spinner-button{cursor:default;display:block;font-size:.5em;height:50%;margin:0;overflow:hidden;padding:0;position:absolute;right:0;text-align:center;width:1.6em}.ui-spinner a.ui-spinner-button{border-bottom-style:none;border-right-style:none;border-top-style:none}.ui-spinner-up{top:0}.ui-spinner-down{bottom:0}.ui-tabs{padding:.2em;position:relative}.ui-tabs .ui-tabs-nav{margin:0;padding:.2em .2em 0}.ui-tabs .ui-tabs-nav li{border-bottom-width:0;float:left;list-style:none;margin:1px .2em 0 0;padding:0;position:relative;top:0;white-space:nowrap}.ui-tabs .ui-tabs-nav .ui-tabs-anchor{float:left;padding:.5em 1em;text-decoration:none}.ui-tabs .ui-tabs-nav li.ui-tabs-active{margin-bottom:-1px;padding-bottom:1px}.ui-tabs .ui-tabs-nav li.ui-tabs-active .ui-tabs-anchor,.ui-tabs .ui-tabs-nav li.ui-state-disabled .ui-tabs-anchor,.ui-tabs .ui-tabs-nav li.ui-tabs-loading .ui-tabs-anchor{cursor:text}.ui-tabs-collapsible .ui-tabs-nav li.ui-tabs-active .ui-tabs-anchor{cursor:pointer}.ui-tabs .ui-tabs-panel{background:none;border-width:0;display:block;padding:1em 1.4em}.ui-tooltip{max-width:300px;padding:8px;position:absolute;z-index:9999}body .ui-tooltip{border-width:2px}.ui-widget{font-family:Arial,Helvetica,sans-serif;font-size:1em}.ui-widget .ui-widget{font-size:1em}.ui-widget input,.ui-widget select,.ui-widget textarea,.ui-widget button{font-family:Arial,Helvetica,sans-serif;font-size:1em}.ui-widget.ui-widget-content{border:1px solid #c5c5c5}.ui-widget-content{background:#fff;border:1px solid #ddd;color:#333}.ui-widget-content a{color:#333}.ui-widget-header{background:#e9e9e9;border:1px solid #ddd;color:#333;font-weight:bold}.ui-widget-header a{color:#333}.ui-state-default,.ui-widget-content .ui-state-default,.ui-widget-header .ui-state-default,.ui-button,html .ui-button.ui-state-disabled:hover,html .ui-button.ui-state-disabled:active{background:#f6f6f6;border:1px solid #c5c5c5;color:#454545;font-weight:normal}.ui-state-default a,.ui-state-default a:link,.ui-state-default a:visited,a.ui-button,a:link.ui-button,a:visited.ui-button,.ui-button{color:#454545;text-decoration:none}.ui-state-hover,.ui-widget-content .ui-state-hover,.ui-widget-header .ui-state-hover,.ui-state-focus,.ui-widget-content .ui-state-focus,.ui-widget-header .ui-state-focus,.ui-button:hover,.ui-button:focus{background:#ededed;border:1px solid #ccc;color:#2b2b2b;font-weight:normal}.ui-state-hover a,.ui-state-hover a:hover,.ui-state-hover a:link,.ui-state-hover a:visited,.ui-state-focus a,.ui-state-focus a:hover,.ui-state-focus a:link,.ui-state-focus a:visited,a.ui-button:hover,a.ui-button:focus{color:#2b2b2b;text-decoration:none}.ui-visual-focus{box-shadow:0 0 3px 1px #5e9ed6}.ui-state-active,.ui-widget-content .ui-state-active,.ui-widget-header .ui-state-active,a.ui-button:active,.ui-button:active,.ui-button.ui-state-active:hover{background:#007fff;border:1px solid #003eff;color:#fff;font-weight:normal}.ui-icon-background,.ui-state-active .ui-icon-background{background-color:#fff;border:#003eff}.ui-state-active a,.ui-state-active a:link,.ui-state-active a:visited{color:#fff;text-decoration:none}.ui-state-highlight,.ui-widget-content .ui-state-highlight,.ui-widget-header .ui-state-highlight{background:#fffa90;border:1px solid #dad55e;color:#777620}.ui-state-checked{background:#fffa90;border:1px solid #dad55e}.ui-state-highlight a,.ui-widget-content .ui-state-highlight a,.ui-widget-header .ui-state-highlight a{color:#777620}.ui-state-error,.ui-widget-content .ui-state-error,.ui-widget-header .ui-state-error{background:#fddfdf;border:1px solid #f1a899;color:#5f3f3f}.ui-state-error a,.ui-widget-content .ui-state-error a,.ui-widget-header .ui-state-error a{color:#5f3f3f}.ui-state-error-text,.ui-widget-content .ui-state-error-text,.ui-widget-header .ui-state-error-text{color:#5f3f3f}.ui-priority-primary,.ui-widget-content .ui-priority-primary,.ui-widget-header .ui-priority-primary{font-weight:bold}.ui-priority-secondary,.ui-widget-content .ui-priority-secondary,.ui-widget-header .ui-priority-secondary{font-weight:normal;opacity:.7;filter:Alpha(Opacity=70)}.ui-state-disabled,.ui-widget-content .ui-state-disabled,.ui-widget-header .ui-state-disabled{background-image:none;opacity:.35;filter:Alpha(Opacity=35)}.ui-state-disabled .ui-icon{filter:Alpha(Opacity=35)}.ui-icon{height:16px;width:16px}.ui-icon,.ui-widget-content .ui-icon{background-image:url(https://cdn.bootcss.com/jqueryui/1.12.1/images/ui-icons_444444_256x240.png)}.ui-widget-header .ui-icon{background-image:url(https://cdn.bootcss.com/jqueryui/1.12.1/images/ui-icons_444444_256x240.png)}.ui-state-hover .ui-icon,.ui-state-focus .ui-icon,.ui-button:hover .ui-icon,.ui-button:focus .ui-icon{background-image:url(https://cdn.bootcss.com/jqueryui/1.12.1/images/ui-icons_555555_256x240.png)}.ui-state-active .ui-icon,.ui-button:active .ui-icon{background-image:url(https://cdn.bootcss.com/jqueryui/1.12.1/images/ui-icons_ffffff_256x240.png)}.ui-state-highlight .ui-icon,.ui-button .ui-state-highlight.ui-icon{background-image:url(https://cdn.bootcss.com/jqueryui/1.12.1/images/ui-icons_777620_256x240.png)}.ui-state-error .ui-icon,.ui-state-error-text .ui-icon{background-image:url(https://cdn.bootcss.com/jqueryui/1.12.1/images/ui-icons_cc0000_256x240.png)}.ui-button .ui-icon{background-image:url(https://cdn.bootcss.com/jqueryui/1.12.1/images/ui-icons_777777_256x240.png)}.ui-icon-blank{background-position:16px 16px}.ui-icon-caret-1-n{background-position:0 0}.ui-icon-caret-1-ne{background-position:-16px 0}.ui-icon-caret-1-e{background-position:-32px 0}.ui-icon-caret-1-se{background-position:-48px 0}.ui-icon-caret-1-s{background-position:-65px 0}.ui-icon-caret-1-sw{background-position:-80px 0}.ui-icon-caret-1-w{background-position:-96px 0}.ui-icon-caret-1-nw{background-position:-112px 0}.ui-icon-caret-2-n-s{background-position:-128px 0}.ui-icon-caret-2-e-w{background-position:-144px 0}.ui-icon-triangle-1-n{background-position:0 -16px}.ui-icon-triangle-1-ne{background-position:-16px -16px}.ui-icon-triangle-1-e{background-position:-32px -16px}.ui-icon-triangle-1-se{background-position:-48px -16px}.ui-icon-triangle-1-s{background-position:-65px -16px}.ui-icon-triangle-1-sw{background-position:-80px -16px}.ui-icon-triangle-1-w{background-position:-96px -16px}.ui-icon-triangle-1-nw{background-position:-112px -16px}.ui-icon-triangle-2-n-s{background-position:-128px -16px}.ui-icon-triangle-2-e-w{background-position:-144px -16px}.ui-icon-arrow-1-n{background-position:0 -32px}.ui-icon-arrow-1-ne{background-position:-16px -32px}.ui-icon-arrow-1-e{background-position:-32px -32px}.ui-icon-arrow-1-se{background-position:-48px -32px}.ui-icon-arrow-1-s{background-position:-65px -32px}.ui-icon-arrow-1-sw{background-position:-80px -32px}.ui-icon-arrow-1-w{background-position:-96px -32px}.ui-icon-arrow-1-nw{background-position:-112px -32px}.ui-icon-arrow-2-n-s{background-position:-128px -32px}.ui-icon-arrow-2-ne-sw{background-position:-144px -32px}.ui-icon-arrow-2-e-w{background-position:-160px -32px}.ui-icon-arrow-2-se-nw{background-position:-176px -32px}.ui-icon-arrowstop-1-n{background-position:-192px -32px}.ui-icon-arrowstop-1-e{background-position:-208px -32px}.ui-icon-arrowstop-1-s{background-position:-224px -32px}.ui-icon-arrowstop-1-w{background-position:-240px -32px}.ui-icon-arrowthick-1-n{background-position:1px -48px}.ui-icon-arrowthick-1-ne{background-position:-16px -48px}.ui-icon-arrowthick-1-e{background-position:-32px -48px}.ui-icon-arrowthick-1-se{background-position:-48px -48px}.ui-icon-arrowthick-1-s{background-position:-64px -48px}.ui-icon-arrowthick-1-sw{background-position:-80px -48px}.ui-icon-arrowthick-1-w{background-position:-96px -48px}.ui-icon-arrowthick-1-nw{background-position:-112px -48px}.ui-icon-arrowthick-2-n-s{background-position:-128px -48px}.ui-icon-arrowthick-2-ne-sw{background-position:-144px -48px}.ui-icon-arrowthick-2-e-w{background-position:-160px -48px}.ui-icon-arrowthick-2-se-nw{background-position:-176px -48px}.ui-icon-arrowthickstop-1-n{background-position:-192px -48px}.ui-icon-arrowthickstop-1-e{background-position:-208px -48px}.ui-icon-arrowthickstop-1-s{background-position:-224px -48px}.ui-icon-arrowthickstop-1-w{background-position:-240px -48px}.ui-icon-arrowreturnthick-1-w{background-position:0 -64px}.ui-icon-arrowreturnthick-1-n{background-position:-16px -64px}.ui-icon-arrowreturnthick-1-e{background-position:-32px -64px}.ui-icon-arrowreturnthick-1-s{background-position:-48px -64px}.ui-icon-arrowreturn-1-w{background-position:-64px -64px}.ui-icon-arrowreturn-1-n{background-position:-80px -64px}.ui-icon-arrowreturn-1-e{background-position:-96px -64px}.ui-icon-arrowreturn-1-s{background-position:-112px -64px}.ui-icon-arrowrefresh-1-w{background-position:-128px -64px}.ui-icon-arrowrefresh-1-n{background-position:-144px -64px}.ui-icon-arrowrefresh-1-e{background-position:-160px -64px}.ui-icon-arrowrefresh-1-s{background-position:-176px -64px}.ui-icon-arrow-4{background-position:0 -80px}.ui-icon-arrow-4-diag{background-position:-16px -80px}.ui-icon-extlink{background-position:-32px -80px}.ui-icon-newwin{background-position:-48px -80px}.ui-icon-refresh{background-position:-64px -80px}.ui-icon-shuffle{background-position:-80px -80px}.ui-icon-transfer-e-w{background-position:-96px -80px}.ui-icon-transferthick-e-w{background-position:-112px -80px}.ui-icon-folder-collapsed{background-position:0 -96px}.ui-icon-folder-open{background-position:-16px -96px}.ui-icon-document{background-position:-32px -96px}.ui-icon-document-b{background-position:-48px -96px}.ui-icon-note{background-position:-64px -96px}.ui-icon-mail-closed{background-position:-80px -96px}.ui-icon-mail-open{background-position:-96px -96px}.ui-icon-suitcase{background-position:-112px -96px}.ui-icon-comment{background-position:-128px -96px}.ui-icon-person{background-position:-144px -96px}.ui-icon-print{background-position:-160px -96px}.ui-icon-trash{background-position:-176px -96px}.ui-icon-locked{background-position:-192px -96px}.ui-icon-unlocked{background-position:-208px -96px}.ui-icon-bookmark{background-position:-224px -96px}.ui-icon-tag{background-position:-240px -96px}.ui-icon-home{background-position:0 -112px}.ui-icon-flag{background-position:-16px -112px}.ui-icon-calendar{background-position:-32px -112px}.ui-icon-cart{background-position:-48px -112px}.ui-icon-pencil{background-position:-64px -112px}.ui-icon-clock{background-position:-80px -112px}.ui-icon-disk{background-position:-96px -112px}.ui-icon-calculator{background-position:-112px -112px}.ui-icon-zoomin{background-position:-128px -112px}.ui-icon-zoomout{background-position:-144px -112px}.ui-icon-search{background-position:-160px -112px}.ui-icon-wrench{background-position:-176px -112px}.ui-icon-gear{background-position:-192px -112px}.ui-icon-heart{background-position:-208px -112px}.ui-icon-star{background-position:-224px -112px}.ui-icon-link{background-position:-240px -112px}.ui-icon-cancel{background-position:0 -128px}.ui-icon-plus{background-position:-16px -128px}.ui-icon-plusthick{background-position:-32px -128px}.ui-icon-minus{background-position:-48px -128px}.ui-icon-minusthick{background-position:-64px -128px}.ui-icon-close{background-position:-80px -128px}.ui-icon-closethick{background-position:-96px -128px}.ui-icon-key{background-position:-112px -128px}.ui-icon-lightbulb{background-position:-128px -128px}.ui-icon-scissors{background-position:-144px -128px}.ui-icon-clipboard{background-position:-160px -128px}.ui-icon-copy{background-position:-176px -128px}.ui-icon-contact{background-position:-192px -128px}.ui-icon-image{background-position:-208px -128px}.ui-icon-video{background-position:-224px -128px}.ui-icon-script{background-position:-240px -128px}.ui-icon-alert{background-position:0 -144px}.ui-icon-info{background-position:-16px -144px}.ui-icon-notice{background-position:-32px -144px}.ui-icon-help{background-position:-48px -144px}.ui-icon-check{background-position:-64px -144px}.ui-icon-bullet{background-position:-80px -144px}.ui-icon-radio-on{background-position:-96px -144px}.ui-icon-radio-off{background-position:-112px -144px}.ui-icon-pin-w{background-position:-128px -144px}.ui-icon-pin-s{background-position:-144px -144px}.ui-icon-play{background-position:0 -160px}.ui-icon-pause{background-position:-16px -160px}.ui-icon-seek-next{background-position:-32px -160px}.ui-icon-seek-prev{background-position:-48px -160px}.ui-icon-seek-end{background-position:-64px -160px}.ui-icon-seek-start{background-position:-80px -160px}.ui-icon-seek-first{background-position:-80px -160px}.ui-icon-stop{background-position:-96px -160px}.ui-icon-eject{background-position:-112px -160px}.ui-icon-volume-off{background-position:-128px -160px}.ui-icon-volume-on{background-position:-144px -160px}.ui-icon-power{background-position:0 -176px}.ui-icon-signal-diag{background-position:-16px -176px}.ui-icon-signal{background-position:-32px -176px}.ui-icon-battery-0{background-position:-48px -176px}.ui-icon-battery-1{background-position:-64px -176px}.ui-icon-battery-2{background-position:-80px -176px}.ui-icon-battery-3{background-position:-96px -176px}.ui-icon-circle-plus{background-position:0 -192px}.ui-icon-circle-minus{background-position:-16px -192px}.ui-icon-circle-close{background-position:-32px -192px}.ui-icon-circle-triangle-e{background-position:-48px -192px}.ui-icon-circle-triangle-s{background-position:-64px -192px}.ui-icon-circle-triangle-w{background-position:-80px -192px}.ui-icon-circle-triangle-n{background-position:-96px -192px}.ui-icon-circle-arrow-e{background-position:-112px -192px}.ui-icon-circle-arrow-s{background-position:-128px -192px}.ui-icon-circle-arrow-w{background-position:-144px -192px}.ui-icon-circle-arrow-n{background-position:-160px -192px}.ui-icon-circle-zoomin{background-position:-176px -192px}.ui-icon-circle-zoomout{background-position:-192px -192px}.ui-icon-circle-check{background-position:-208px -192px}.ui-icon-circlesmall-plus{background-position:0 -208px}.ui-icon-circlesmall-minus{background-position:-16px -208px}.ui-icon-circlesmall-close{background-position:-32px -208px}.ui-icon-squaresmall-plus{background-position:-48px -208px}.ui-icon-squaresmall-minus{background-position:-64px -208px}.ui-icon-squaresmall-close{background-position:-80px -208px}.ui-icon-grip-dotted-vertical{background-position:0 -224px}.ui-icon-grip-dotted-horizontal{background-position:-16px -224px}.ui-icon-grip-solid-vertical{background-position:-32px -224px}.ui-icon-grip-solid-horizontal{background-position:-48px -224px}.ui-icon-gripsmall-diagonal-se{background-position:-64px -224px}.ui-icon-grip-diagonal-se{background-position:-80px -224px}.ui-corner-all,.ui-corner-top,.ui-corner-left,.ui-corner-tl{border-top-left-radius:3px}.ui-corner-all,.ui-corner-top,.ui-corner-right,.ui-corner-tr{border-top-right-radius:3px}.ui-corner-all,.ui-corner-bottom,.ui-corner-left,.ui-corner-bl{border-bottom-left-radius:3px}.ui-corner-all,.ui-corner-bottom,.ui-corner-right,.ui-corner-br{border-bottom-right-radius:3px}.ui-widget-overlay{background:#aaa;opacity:.003;filter:Alpha(Opacity=.3)}.ui-widget-shadow{-webkit-box-shadow:0 0 5px #666;box-shadow:0 0 5px #666}";
GM_addStyle(myScriptStyle);

// 定义基础方法
function getDoc(url, meta, callback) {
    GM_xmlhttpRequest({
        method: 'GET',
        url: url,
        headers: {
            'User-agent': window.navigator.userAgent,
            'Content-type': null
        },
        onload: function (responseDetail) {
            if (responseDetail.status === 200) {
                let doc = (new DOMParser).parseFromString(responseDetail.responseText, 'text/html');
                callback(doc, responseDetail, meta);
            }
        }
    });
}
function getJSON(url, callback) {
    GM_xmlhttpRequest({
        method: 'GET',
        url: url,
        headers: {
            'Accept': 'application/json'
        },
        onload: function (response) {
            if (response.status >= 200 && response.status < 400) {
                callback(JSON.parse(response.responseText), url);
            } else {
                callback(false, url);
            }
        }
    });
}

let cache_prefix = "cache_";

function GM_deletedCacheValue(name) {
    GM_deleteValue(name);
    GM_deleteValue(cache_prefix + name);
}

function GM_setCacheValue(name, value, expire) {
    GM_setValue(name, value);
    GM_setValue(cache_prefix + name, Date.now() + expire);
}

function GM_getCacheValue(name, defaultValue) {
    let expire_timestamp = parseInt(GM_getValue(cache_prefix + name));
    if (expire_timestamp < Date.now()) {
        GM_deletedCacheValue(name);
    }

    return GM_getValue(name, defaultValue);
}

function GM_clearExpiredCacheValue(force) {
    let cache_key = GM_listValues().filter(function (key) {
        return key.includes(cache_prefix)
    });
    for (let i = 0; i < cache_key.length; i++) {
        let name = cache_key[i].slice(cache_prefix.length);
        let expired_timestamp = GM_getValue(cache_prefix + name);
        if (force || expired_timestamp < Date.now()) {
            GM_deletedCacheValue(name);
        }
    }
}

GM_clearExpiredCacheValue(false);

let _version = GM_getValue("version", "轻量版");
let delete_site_prefix = "delete_site_";

if (typeof GM_registerMenuCommand !== "undefined") {

    function changeVersionConfirm() {
        if (confirm(`你当前版本是 ${_version}，是否进行切换？`)) {
            GM_setValue("version", _version === "完整版" ? "轻量版" : "完整版");
        }
    }
    GM_registerMenuCommand("脚本功能切换", changeVersionConfirm);

    function deleteSitePrompt() {
        let name = prompt("请输入你不想看到的分类/站点名称，多站点请以英文逗号分割。请注意，除非重装脚本，否则该操作不可撤销", "");
        if (name != null && name !== "") {
            let delete_list = name.split(",");
            for (let i = 0; i < delete_list.length; i++) {
                let name = delete_list[i];
                if (GM_getValue(delete_site_prefix + name, false)) { // 二次输入恢复
                    GM_deleteValue(delete_site_prefix + name);
                } else {
                    GM_setValue(delete_site_prefix + name, true);
                }
            }
        }
    }
    GM_registerMenuCommand("删除不想显示的站", deleteSitePrompt);

    function changeTagBColor() {
        let now_bcolor_list = [GM_getValue("tag_bcolor_exist", "#e3f1ed"), GM_getValue("tag_bcolor_not_exist", "#f4eac2"), GM_getValue("tag_bcolor_need_login", ""), GM_getValue("tag_bcolor_error", "")];
        let name = prompt("请依次输入代表'资源存在','资源不存在','站点需要登陆','站点解析错误'颜色的Hex值，并用英文逗号分割。当前值为：", `${now_bcolor_list.join(',')}`);
        if (name != null && name !== "") {
            try {
                let bcolor_list = name.split(",");
                GM_setValue("tag_bcolor_exist", bcolor_list[0] || "#e3f1ed");
                GM_setValue("tag_bcolor_not_exist", bcolor_list[1] || "#f4eac2");
                GM_setValue("tag_bcolor_need_login", bcolor_list[2] || "");
                GM_setValue("tag_bcolor_error", bcolor_list[3] || "");
            } catch (e) {
                alert("解析输入出错");
            }
        }
    }
    GM_registerMenuCommand("更改标签背景色", changeTagBColor);

    function changeTagFColor() {
        let now_fcolor_list = [GM_getValue("tag_fcolor_exist", "#3377aa"), GM_getValue("tag_fcolor_not_exist", "#3377aa"), GM_getValue("tag_fcolor_need_login", "#3377aa"), GM_getValue("tag_fcolor_error", "#3377aa")];
        let name = prompt("请依次输入代表'资源存在','资源不存在','站点需要登陆','站点解析错误'颜色的Hex值，并用英文逗号分割。当前值为：", `${now_fcolor_list.join(',')}`);
        if (name != null && name !== "") {
            try {
                let fcolor_list = name.split(",");
                GM_setValue("tag_fcolor_exist", fcolor_list[0] || "#3377aa");
                GM_setValue("tag_fcolor_not_exist", fcolor_list[1] || "#3377aa");
                GM_setValue("tag_fcolor_need_login", fcolor_list[2] || "#3377aa");
                GM_setValue("tag_fcolor_error", fcolor_list[3] || "#3377aa");
            } catch (e) {
                alert("解析输入出错");
            }
        }
    }
    GM_registerMenuCommand("更改标签文字色", changeTagFColor);

    function forceCacheClear() {
        if (confirm("清空所有缓存信息（包括资源存在情况、登陆情况、imdb250等）")) {
            GM_clearExpiredCacheValue(true);
        }
    }
    GM_registerMenuCommand("清空脚本缓存", forceCacheClear);

}


let fetch_anchor = function (anchor) {
    return anchor[0].nextSibling.nodeValue.trim();
};

$(document).ready(function () {
    let douban_link, douban_id;

    douban_link = 'https://' + location.href.match(/movie.douban.com\/subject\/\d+\//);  //豆瓣链接
    douban_id = location.href.match(/(\d{7,8})/g);

    let site_map = [];

    /** label对象键值说明：
     * name:          String  站点名称，请注意该站点名称在不同的site_map中也应该唯一，以免脚本后续判断出错
     * method：       String  搜索请求方式，默认值为 "GET"
     * link：         String  构造好的请求页面链接，作为label的href属性填入，用户应该能直接点开这个页面。
     * ajax：         String  如果站点使用ajax的形式加载页面，则需要传入该值作为实际请求的链接，即优先级比link更高。
     * type：         String  返回结果类型，脚本默认按html页面解析；只有当传入值为"json"时，脚本按JSON格式解析
     * selector：     String  搜索成功判断结果，默认值为 "table.torrents:last > tbody > tr:gt(0)" (适用于国内多数NexusPHP构架的站点)
     *                        如果type为"page"（默认）时，为一个（jQuery）CSS选择器，
     *                        如果type为"json"或"jsonp"时，为一个具体的判断式。
     * selector_need_login    搜索需要登录的选择器，仅在type为默认时有用，其余用法同Selector一致。
     * data：         String  作为请求的主体发送的内容，默认为空即可
     * headers：      Object  修改默认请求头，（防止某些站点有referrer等请求头检查
     * rewrite_href:  Boolean 如果站点最终搜索显示的页面与实际使用搜索页面（特别是使用post进行交互的站点）不一致，
     *                        设置为true能让脚本存储最终url，并改写label使用的href属性
     * csrf:          Object  一个类似这样的字典 { name: "_csrf", update: "link"}
     *                        其中key为站点csrf防护的名称，update为需要更新的字段（一般为link或data）
     *
     * 注意： 1. 如果某键有默认值，则传入值均会覆盖默认值
     *        2. 关于请求方法请参考：https://github.com/scriptish/scriptish/wiki/GM_xmlhttpRequest
     * */

    // 脚本页面切换方法
    function wrapper_change(id, html, css, callback) {
        if ($(`div#wrapper > div#${id}`).length === 0) {
            GM_addStyle(css);
            $('div#wrapper').append(html);
            if (typeof callback === "function") {
                callback();
            }
        }
        let ele_inst = $(`div#wrapper > div#${id}`);
        ele_inst.siblings("div").hide();
        ele_inst.show();
    }

    // 加载豆列搜索
    $('div.nav-items ul').append('<li><a id="search_dlist" href="javascript:void(0);">豆列搜索</a></li>');
    $("#search_dlist").click(function () {
        let int_html = `<div id='drdm_doulist'><h1>豆列搜索</h1><div class="grid-16-8 clearfix"><div class="article"><div class="indent"><div class="movie-list"></div><a class="more" href="javascript:;" style="display:none">加载更多</a></div></div><div class="aside"><div><h2>豆列搜索 · · · · · ·</h2><div><span><p><div id="form-doulist"><input class="doulist" id="input-doulist" placeholder="Criterion, 46534919, ..." value=""</input><input type="submit" id="doulist-submit" value="search" /input></div></p></span><span style="" class="search_result c-aside-body"></span></div></div><div class="doulist_intro"><h2>豆列搜索说明 · · · · · ·</h2><p>输入你想搜的关键词，点击搜索。就这么简单。</p></div></div></div></div>`;
        let int_css = ".more {display: block;height: 34px;line-height: 34px;text-align: center;font-size: 14px;background: #f7f7f7;}";
        wrapper_change("drdm_doulist", int_html, int_css, function () {
            let load_more = $("#drdm_doulist a.more");
            $('#doulist-submit').click(function () {
                let doulist = $("#input-doulist").val();
                $('div.movie-list').html("");
                let get_doulist = function (doulist, page) {
                    load_more.text("加载中......").show();
                    getDoc('https://cn.bing.com/search?q=site%3awww.douban.com%2fdoulist+' + doulist + '&first=' + page, null, function (doc, res, meta) {
                        let result = $('ol#b_results .b_algo', doc);
                        result = result.filter(function () {
                            return $("a[href^='https://www.douban.com/doulist/']", this).length > 0;
                        });
                        if (result.length == 0) {
                            load_more.text('没有找到相关豆列');
                        }
                        else {
                            result.each(function () {
                                let title = $(this).find("a[href^='https://www.douban.com/doulist/']");
                                let caption = $(this).find("div.b_caption");

                                let id = title.attr("href").match(/doulist\/(\d+)/)[1];
                                let title_clean = title.text().replace(/(\(豆瓣\)|\s-\s豆瓣电影|\s-\s豆瓣)/, '').replace(/ - douban.com/, '');
                                caption.find("div.b_attribution").remove();
                                let detail = caption.html();

                                if ($(`div.movie-list > div[data-dlist=${id}]`).length == 0) {  // 重复的不再插入
                                    $('div.movie-list').append(`<div data-dlist="${id}"><div><h2 style="font-size:13px;"><a href="https://www.douban.com/doulist/${id}" target="_blank">${title_clean}</a></h2><div></div></div><div class="tags">${detail}<p class="ul"></p></div></div>`);
                                }
                            });

                            // 更新加载信息
                            let load_id = page + 10;
                            load_more.text('加载更多');
                            load_more.one("click", function () {
                                get_doulist(doulist, load_id);
                            });
                        }
                    });
                }
                get_doulist(doulist, 1);
            });
        });
    });

    $("#content div.aside").prepend(`<p id="drdm_dep_notice" style="color: #C65E24;display:none;">脚本未完全加载，部分站点将受影响。请确保网络稳定或尝试重新刷新页面。</p><div id='adv-sites'></div>`);

    function _encodeToGb2312(str, opt) {
        let ret = "";
        try {
            ret = encodeToGb2312(str, opt);
        } catch (e) {
            ret = Math.random() * 1e6;
            $("#drdm_dep_notice").show();
        }
        return ret;
    }

    if (location.host === "movie.douban.com") {
        // 查看原图
        if ($('#mainpic p.gact').length === 0) {  // 在未登录的情况下添加空白元素以方便查看原图交互按钮的定位
            $("#mainpic").append("<p class=\"gact\"></p>");
        }
        let posterAnchor = document.querySelector('#mainpic > a > img');
        if (posterAnchor) {
            let postersUrl = posterAnchor.getAttribute("src");
            let rawUrl = postersUrl.replace(/photo\/s_ratio_poster\/public\/(p\d+).+$/, "photo/raw/public/$1.jpg");
            $('#mainpic p.gact').after(`<a target="_blank" rel="nofollow" href="${rawUrl}">查看原图</a>`);
        }

        // 调整底下剧情简介的位置
        let interest_sectl_selector = $('#interest_sectl');
        interest_sectl_selector.after($('div.grid-16-8 div.related-info'));
        interest_sectl_selector.attr('style', 'float:right');
        $('div.related-info').attr('style', 'width:480px;float:left');

        // Movieinfo信息生成相关
        let poster;
        let this_title, trans_title, aka;
        let year, region, genre, language, playdate;
        let imdb_link, imdb_id, imdb_average_rating, imdb_votes, imdb_rating;
        let douban_average_rating, douban_votes, douban_rating;
        let episodes, duration;
        let director, writer, cast;
        let tags, introduction, awards;

        // 增加Mediainfo的交互按钮与监听
        $("div#info").append("<span class=\"pl\">生成信息: </span><a id='movieinfogen' href='javascript:void(0);'>movieinfo</a>");
        $("div.related-info").before("<div class='c-aside' style='float:left;margin-top:20px;width: 470px;display: none' id='movieinfo_div'><h2><i>电影简介</i>· · · · · · </h2><a href='javascript:void(0);' id='copy_movieinfo'>点击复制</a><div class=\"c-aside-body\" style=\"padding: 0 12px;\" id='movieinfo'></div></div>");
        $("a#movieinfogen").click(function () {
            let descr = "";
            descr += poster ? `[img]${poster}[/img]\n\n` : "";
            descr += trans_title ? `◎译　　名　${trans_title}\n` : "";
            descr += this_title ? `◎片　　名　${this_title}\n` : "";
            descr += year ? `◎年　　代　${year.trim()}\n` : "";
            descr += region ? `◎产　　地　${region}\n` : "";
            descr += genre ? `◎类　　别　${genre}\n` : "";
            descr += language ? `◎语　　言　${language}\n` : "";
            descr += playdate ? `◎上映日期　${playdate}\n` : "";
            descr += imdb_rating ? `◎IMDb评分  ${imdb_rating}\n` : "";  // 注意如果长时间没能请求完成imdb信息，则该条不显示
            descr += imdb_link ? `◎IMDb链接  ${imdb_link}\n` : "";
            descr += douban_rating ? `◎豆瓣评分　${douban_rating}\n` : "";
            descr += douban_link ? `◎豆瓣链接　${douban_link}\n` : "";
            descr += episodes ? `◎集　　数　${episodes}\n` : "";
            descr += duration ? `◎片　　长　${duration}\n` : "";
            descr += director ? `◎导　　演　${director}\n` : "";
            descr += writer ? `◎编　　剧　${writer}\n` : "";
            descr += cast ? `◎主　　演　${cast.replace(/\n/g, '\n' + '　'.repeat(4) + '  　').trim()}\n` : "";
            descr += tags ? `\n◎标　　签　${tags}\n` : "";
            descr += introduction ? `\n◎简　　介\n\n　　${introduction.replace(/\n/g, '\n' + '　'.repeat(2))}\n` : "";
            descr += awards ? `\n◎获奖情况\n\n　　${awards.replace(/\n/g, '\n' + '　'.repeat(2))}\n` : "";
            $("div#movieinfo").html(descr.replace(/\n/ig, "<br>"));
            $("#movieinfo_div").toggle();
        });
        $("a#copy_movieinfo").click(function () {
            let movieclip = $("#movieinfo").html().replace(/<br>/ig, "\n").replace(/<a [^>]*>/g, "").replace(/<\/a>/g, "");
            GM_setClipboard(movieclip);
            $(this).text("复制成功");
        });

        // 先对一些关键信息进行判断
        let aka_anchor = $('#info span.pl:contains("又名")');
        let has_aka = aka_anchor.length > 0;
        let has_imdb = $('div#info a[href^=\'http://www.imdb.com/title/tt\']').length > 0;
        let is_movie = $("a.bn-sharing[data-type='电影']").length > 0;
        let is_series = $("a.bn-sharing[data-type='电视剧']").length > 0;
        let is_anime = $("a[href='/tag/动画'], a[href='/tag/动漫']").length > 0;
        let is_document = $('span[property="v:genre"]:contains("纪录片")').length > 0;

        // 页面元素定位
        let regions_anchor = $('#info span.pl:contains("制片国家/地区")');  //产地
        let language_anchor = $('#info span.pl:contains("语言")');  //语言
        let episodes_anchor = $('#info span.pl:contains("集数")');  //集数
        let duration_anchor = $('#info span.pl:contains("单集片长")');  //片长

        // 基础Movieinfo信息
        let chinese_title = document.title.replace('(豆瓣)', '').trim();
        let foreign_title = $('#content h1>span[property="v:itemreviewed"]').text().replace(chinese_title, '').trim();

        if (has_aka) {
            aka = fetch_anchor(aka_anchor).split(' / ').sort(function (a, b) {//首字(母)排序
                return a.localeCompare(b);
            }).join('/');
        }

        if (foreign_title) {
            trans_title = chinese_title + (aka ? ('/' + aka) : '');
            this_title = foreign_title;
        } else {
            trans_title = aka ? aka : '';
            this_title = chinese_title;
        }

        playdate = $('#info span[property="v:initialReleaseDate"]').map(function () {   //上映日期
            return $(this).text().trim();
        }).toArray().sort(function (a, b) {//按上映日期升序排列
            return new Date(a) - new Date(b);
        }).join('/');

        year = ' ' + $('#content > h1 > span.year').text().substr(1, 4);
        region = regions_anchor[0] ? fetch_anchor(regions_anchor).split(' / ').join('/') : null;
        language = language_anchor[0] ? fetch_anchor(language_anchor).split(' / ').join('/') : '';
        episodes = episodes_anchor[0] ? fetch_anchor(episodes_anchor) : null;
        duration = duration_anchor[0] ? fetch_anchor(duration_anchor) : $('#info span[property="v:runtime"]').text().trim();

        let is_europe = region.match(/美国|英国|丹麦/);
        let is_japan = region.match(/日本/);
        let is_korea = region.match(/韩国/);
        let is_thai = region.match(/泰国/);
        let is_mainland = region.match(/中国大陆/);

        genre = $('#info span[property="v:genre"]').map(function () {  //类别
            return $(this).text().trim();
        }).toArray().join('/');

        // Add top rank tag
        function addRankTag(rank_json) {
            if (document.getElementsByClassName('top250').length === 0) {
                let style = '.top250{background:url(https://s.doubanio.com/f/movie/f8a7b5e23d00edee6b42c6424989ce6683aa2fff/pics/movie/top250_bg.png) no-repeat;width:150px;margin-right:5px;font:12px Helvetica,Arial,sans-serif;margin:5px 0;color:#744900}.top250 span{display:inline-block;text-align:center;height:18px;line-height:18px}.top250 a,.top250 a:link,.top250 a:hover,.top250 a:active,.top250 a:visited{color:#744900;text-decoration:none;background:none}.top250-no{width:34%}.top250-link{width:66%}';
                GM_addStyle(style);
            }
            let insert_html_list = [];
            for (let i in rank_json) {
                let top_list = rank_json[i];
                let list_num = top_list.list[douban_id];
                if (list_num) {
                    let list_name = i;
                    let list_order = top_list.top;
                    insert_html_list[list_order] = `<div class="top250"><span class="top250-no">${top_list.prefix ? top_list.prefix : "No."}${list_num}</span><span class="top250-link"><a href="${top_list.href}" title="${top_list.title}">${top_list.short_title}</a></span></div>`;
                }
            }
            if (insert_html_list) {
                let after = document.getElementById('dale_movie_subject_top_icon');
                if (!after) after = document.querySelector('h1');
                after.insertAdjacentHTML('beforebegin', insert_html_list.join(' '));
                [].forEach.call(document.getElementsByClassName('top250'), function (e) {
                    e.style.display = 'inline-block';
                });
            }
        }

        let rank_list = GM_getCacheValue("collection_list");
        if (rank_list) {
            addRankTag(rank_list);
        } else {
            GM_xmlhttpRequest({
                method: 'GET',
                url: "https://github.com/bimzcy/rank4douban/raw/master/data.json",
                onload: function (response) {
                    let json_data = JSON.parse(response.responseText);
                    GM_setCacheValue("collection_list", json_data, 86400 * 1e3);
                    addRankTag(json_data);
                }
            });
        }

        // 请求IMDb信息（最慢，最先且单独请求）
        if (has_imdb) {
            let imdb_link_anchor = $('#info span.pl:contains("IMDb链接")');
            imdb_link = imdb_link_anchor.next().attr('href').replace(/(\/)?$/, '/').replace("http://", "https://");
            imdb_id = imdb_link.match(/tt\d+/)[0];

            $("div#interest_sectl").append(`
<div class='rating_wrap clearbox' id='loading_more_rate'>加载第三方评价信息中.......</div>
<div class="rating_wrap clearbox rating_imdb" rel="v:rating" style="display:none"></div>
<div class="rating_more" style="display:none"></div>
<div class="rating_wrap clearbox rating_rott" style="display:none"></div>
`); // 修复部分情况$("div.rating_betterthan")不存在情况

            getDoc(imdb_link, null, function (doc) {
                // 评分，Metascore，烂番茄
                imdb_average_rating = $('div.ratingValue strong span', doc).text();
                imdb_votes = $('div.imdbRating a span', doc).text();
                imdb_rating = imdb_votes ? imdb_average_rating + '/10 from ' + imdb_votes + ' users' : '';  // MovieinfoGen 相关

                let starValue = parseFloat(imdb_average_rating) / 2;
                starValue = starValue % 1 > 0.5 ? Math.floor(starValue) + 0.5 : Math.floor(starValue);
                starValue *= 10;

                $('#interest_sectl div.rating_imdb').html(`<div class=rating_logo >IMDB 评分</div> <div class="rating_self clearfix" typeof="v:Rating"> <strong class="ll rating_num" property="v:average">${imdb_average_rating}</strong><span property="v:best" content=10.0 ></span> <div class="rating_right "> <div class="ll bigstar ${'bigstar' + starValue}"></div> <div class="rating_sum"> <a href=${imdb_link + 'ratings?ref_=tt_ov_rt'}  class=rating_people ><span property="v:votes">${imdb_votes}</span>人评价</a> </div> </div> </div>`).show();

                // put on more ratings
                let rating_more = $('#interest_sectl .rating_more');
                let titleReviewBarItem = $('.titleReviewBar div.titleReviewBarItem', doc);
                for (let i = 0; i < titleReviewBarItem.length; i++) {
                    let item = titleReviewBarItem[i];
                    let text = $(item).text();
                    if (text.indexOf('Metascore') !== -1) {
                        if ($("div.txt-block:contains('Motion Picture Rating')",doc).text().length > 0) {
                        let mpaa = $("div.txt-block:contains('Motion Picture Rating')", doc).text().trim().replace(/\n/g,'').replace(/^.*Rated /,'').replace(/ .*$/,'').replace(/^G$/,'大众级 | 全年龄').replace(/^PG$/,'指导级 | ≥6岁').replace(/^PG-13$/,'特指级 | ≥13岁').replace(/^NC-17$/,'限定级 | ≥17岁').replace(/^R$/,'限制级 | ≥18岁');
                        rating_more.append(`<div>MPAA<a href='${imdb_link + 'parentalguide?ref_=tt_stry_pg#certification'}' style="margin-left:-35px" target="_blank">${mpaa}</a></div>`);
                        }
                        if ($("div.txt-block:contains('Budget:')", doc).text().length > 0) {
                        let budget = $("div.txt-block:contains('Budget:')", doc).text().trim().replace(/\n/g,'').replace(/ .*$/,'').replace(/^Budget:/,'').replace(/CNY./,'¥');
                        rating_more.append(`<div>总成本<a href='${imdb_link + '?rf=cons_tt_bo_tt&ref_=cons_tt_bo_tt'}' style="margin-left:-35px" target="_blank">${budget}</a></div>`);        
                        }
                        if ($("div.txt-block:contains('Opening Weekend:'):not(:contains('USA:'))", doc).text().length > 0) {
                        let opening = $("div.txt-block:contains('Opening Weekend:'):not(:contains('USA:'))", doc).text().trim().replace(/\n/g,'').replace(/^Opening Weekend:/,'').replace(/ \(.*$/,'').replace(/CNY./,'¥');
                        rating_more.append(`<div>本首周<a href='${imdb_link + '?rf=cons_tt_bo_tt&ref_=cons_tt_bo_tt'}' style="margin-left:-35px" target="_blank">${opening}</a></div>`);
                        }
                        if ($("div.txt-block:contains('Opening Weekend USA:')", doc).text().length > 0) {
                        let openingusa = $("div.txt-block:contains('Opening Weekend USA:')", doc).text().trim().replace(/\n/g,'').replace(/^Opening Weekend USA:/,'').replace(/\,\d+ .*$/,'');
                        rating_more.append(`<div>美首周<a href='${imdb_link + '?rf=cons_tt_bo_tt&ref_=cons_tt_bo_tt'}' style="margin-left:-35px" target="_blank">${openingusa}</a></div>`);
                        }
                        if ($("div.txt-block:contains('Gross USA:')", doc).text().length > 0) {
                        let gross = $("div.txt-block:contains('Gross USA:')", doc).text().trim().replace(/\n/g,'').replace(/^Gross USA:/,'').replace(/\, \d+ .*$/,'');
                        rating_more.append(`<div>美票房<a href='${imdb_link + '?rf=cons_tt_bo_tt&ref_=cons_tt_bo_tt'}' style="margin-left:-35px" target="_blank">${gross}</a></div>`);
                        }
                        if ($("div.txt-block:contains('Cumulative Worldwide Gross:')", doc).text().length > 0) {
                        let cumulative = $("div.txt-block:contains('Cumulative Worldwide Gross:')", doc).text().trim().replace(/\n/g,'').replace(/^Cumulative Worldwide Gross:/,'').replace(/\, \d+ .*$/,'');
                        rating_more.append(`<div>总票房<a href='${imdb_link + '?rf=cons_tt_bo_tt&ref_=cons_tt_bo_tt'}' style="margin-left:-35px" target="_blank">${cumulative}</a></div>`);
                        }
                        if ($("div.txt-block:contains('Aspect Ratio:')", doc).text().length > 0) {
                        let aspect = $("div.txt-block:contains('Aspect Ratio:')", doc).text().trim().replace(/\n/g,'').replace(/^Aspect Ratio:/,'');
                        rating_more.append(`<div>宽高比<a href='${imdb_link + 'technical?ref_=tt_dt_spec'}' style="margin-left:-35px" target="_blank">${aspect}</a></div>`);
                        }
                        let metascore = $(item).find('a[href^=criticreviews] span').text();
                        rating_more.append(`<div>Metascore<a href='${imdb_link + 'criticreviews?ref_=tt_ov_rt'}' target="_blank">${metascore}</a></div>`);
                    } else if (text.indexOf('Popularity') !== -1) {
                        if ($("div.txt-block:contains('Certificate:')",doc).text().length > 0) {
                            let tvpg = $("div.txt-block:contains('Certificate:')", doc).text().trim().replace(/\n/g,'').replace(/^Certificate:/,'').replace(/ \|.*$/,'').replace(/^( )+TV-Y( )+$/,'推荐级 | 全年龄').replace(/^( )+TV-G( )+$/,'大众级 | 全年龄').replace(/^( )+TV-Y7( )+$/,'指导级 | ≥7岁').replace(/^( )+TV-PG( )+$/,'特指级 | ≥8岁').replace(/^( )+TV-14( )+$/,'限定级 | ≥14岁').replace(/^( )+TV-MA( )+$/,'限制级 | ≥17岁').replace(/Not Rated/,'未分级');
                            rating_more.append(`<div>TVPG<a href='${imdb_link + 'parentalguide?ref_=tt_stry_pg#certification'}' style="margin-left:-35px" target="_blank">${tvpg}</a></div>`);
                            }    
                        let popularity = $(item).find('span.subText').html();
                        popularity = `<div>流行度&nbsp;&nbsp;${popularity}<br><div>`;
                        rating_more.append(popularity);
                    } else if (text.indexOf('Reviews') !== -1) {
                        // TODO let reviews;
                    }
                }
                if (rating_more.html()) {
                    rating_more.show();
                }

                // add rottentomatoes block
                $('#titleYear', doc).remove();
                let movieTitle = $.trim($('div.title_wrapper h1', doc).text());
                let rottURL = 'https://www.rottentomatoes.com/m/' + movieTitle.replace(/\s+/g, "_").replace(/\W+/g, "").toLowerCase();
                getDoc(rottURL, null, function (rotdoc) {
                    $('#interest_sectl div.rating_rott').html(`<span class="rating_logo ll">烂番茄新鲜度</span><br><div id="rottValue" class="rating_self clearfix"></div></div>`).show();
                    if (!rotdoc.title) {
                        $('#interest_sectl div.rating_rott').append(`<br>搜索rotta: <a target='_blank' href='${'https://www.rottentomatoes.com/search/?search=' + encodeURI(movieTitle)}'>${movieTitle}</a>`);
                    } else if ($('#tomato_meter_link', rotdoc).length > 0) {
                        let rating_rott_value = $('#tomato_meter_link .meter-value.superPageFontColor', rotdoc).html();
                        $('#scoreStats .subtle.superPageFontColor', rotdoc).remove();
                        let fresh_rott_value = $('#scoreStats .superPageFontColor:eq(2)', rotdoc).text();
                        let rotten_rott_value = $('#scoreStats .superPageFontColor:eq(3)', rotdoc).text();
                        $('#interest_sectl .rating_rott #rottValue').append(`<strong class="ll rating_num"><a target="_blank" href="${rottURL}">${rating_rott_value}</a></strong><div class="rating_right" style="line-height: 16px;"><span>鲜:&nbsp;&nbsp;${fresh_rott_value}</span><br><span>烂:&nbsp;&nbsp;${rotten_rott_value}</span></div>`);
                    }
                });
                $("#loading_more_rate").hide();
            });
        }

        // 如果是动漫，请求anydb的anidb、bgm、mal信息
        if (is_anime) {
            $("div#interest_sectl").append(`<div class="rating_wrap clearbox rating_anidb" rel="v:rating" style="border-top: 1px solid #eaeaea; display:none"></div>`);

            getJSON("https://anydb.depar.cc/anime/query?_cf_cache=1&douban=" + douban_id, function (data1) {
                let _anydb_html = "";
                if (data1.success) {
                    let source_list = ["AniDB", "Bgm", "MAL"];
                    for (let i = 0; i < source_list.length; i++) {
                        let source = source_list[i];
                        let _data = data1.matched[source.toLowerCase()];
                        if (_data) {
                            let _group = _data.rate.match(/([\d.]+?) \((\d+)\)/);
                            let _rating = _group[1];
                            let _vote = _group[2];
                            let starValue = parseFloat(_rating) / 2;
                            starValue = starValue % 1 > 0.5 ? Math.floor(starValue) + 0.5 : Math.floor(starValue);
                            starValue *= 10;
                            _anydb_html += `<div class=rating_logo >${source} 评分</div><div class="rating_self clearfix" typeof="v:Rating"><strong class="ll rating_num" property="v:average">${parseFloat(_rating).toFixed(1)}</strong><span property="v:best" content=10.0 ></span><div class="rating_right "><div class="ll bigstar ${'bigstar' + starValue}"></div><div class="rating_sum"> <a href=${_data.url}  class=rating_people target="_blank"><span property="v:votes">${_vote}</span>人${source === "MAL" ? "观看" : "评价"}</a> </div> </div> </div>`;
                        }
                    }
                    if (_anydb_html.trim().length > 0) {
                        $('#interest_sectl > div.rating_anidb').html(_anydb_html).show();
                    }
                }
                $("#loading_more_rate").hide();
            });
        }

        // 请求豆瓣附属信息
        getDoc(douban_link + 'awards/', null, function (doc) {
            awards = $('#content>div>div.article', doc).html()
                .replace(/[ \n]/g, '')
                .replace(/<\/li><li>/g, '</li> <li>')
                .replace(/<\/a><span/g, '</a> <span')
                .replace(/<(div|ul)[^>]*>/g, '\n')
                .replace(/<[^>]+>/g, '')
                .replace(/&nbsp;/g, ' ')
                .replace(/ +\n/g, '\n')
                .trim();
        });    // 该影片的评奖信息
        getJSON('https://api.douban.com/v2/movie/' + douban_id, function (data1) {
            douban_average_rating = data1.rating.average || 0;
            douban_votes = data1.rating.numRaters.toLocaleString() || 0;
            douban_rating = douban_average_rating + '/10 from ' + douban_votes + ' users';
            introduction = data1.summary.replace(/^None$/g, '暂无相关剧情介绍');
            poster = data1.image.replace(/s(_ratio_poster|pic)/g, 'l');
            director = data1.attrs.director ? data1.attrs.director.join(' / ') : '';
            writer = data1.attrs.writer ? data1.attrs.writer.join(' / ') : '';
            cast = data1.attrs.cast ? data1.attrs.cast.join('\n') : '';
            tags = data1.tags.map(function (member) {
                return member.name;
            }).join(' | ');
        });  //豆瓣评分，简介，海报，导演，编剧，演员，标签

        // 获取电影名
        let title = $('#content > h1 > span')[0].textContent.split(' ').shift().replace(/[，]/g, " ").replace(/：.*$/, "");
        let eng_title = [this_title, trans_title].join("/").split("/").filter(function (arr) {
            return /([a-zA-Z]){2,}/.test(arr);
        })[0] || "";

        // 剧集修正季数名
        eng_title = eng_title.match(/Season\s\d\d/) ? eng_title.replace(/Season\s/, "S") : eng_title.replace(/Season\s/, "S0");
        eng_title = eng_title.replace(/[:,!\-]/g, "").replace(/ [^a-z0-9]+$/, "");
        let eng_title_clean = eng_title.replace(/ S\d\d*$/, "");

        // 日剧春夏秋冬解析
        let playdate_pro = new Date(playdate.split('/')[0]);
        let release_year = playdate.replace(/-.*$/, "").replace(/^\d{2}/, "");
        let release_month = playdate_pro.getMonth() + 1;
        let drama_season;
        if ([4, 5, 6].includes(release_month)) { drama_season = "spring"; }
        else if ([7, 8, 9].includes(release_month)) { drama_season = "summer"; }
        else if ([10, 11, 12].includes(release_month)) { drama_season = "autumn"; }
        else { drama_season = "winter"; }

        // 电影+年份 (只有电影才搜索并赋值年份)
        let encode_year = is_movie ? year.replace(/ /, "_") : "";
        let nian = is_movie ? year : "";
        let encode_this_title = (this_title || "").replace(/:/, "").replace(/ /g, "_");
        let ptzimu = encode_this_title + encode_year;
        chinese_title = chinese_title.replace(/[：，]/, " ");
        let gtitle = _encodeToGb2312(title, true);
        let ptitle = encodeURI(title).replace(/%/g, "%25");
        let utitle = encodeURI(title).replace(/%/g, "_");
        let ywm = eng_title + nian;
        let zwm = chinese_title + nian;
        let gongwang = has_imdb ? imdb_id : douban_id;
        let dbzw = has_imdb ? imdb_id : title;

        if (_version === "完整版") {
            let neizhan = has_imdb ? imdb_id : ('/subject/' + douban_id);  // PT内站 智能判定是用IMDB ID还是豆瓣ID
            let npid = has_imdb ? ('imdb=' + imdb_id) : ('douban=' + douban_id);  // NPUBITS 智能判定是用IMDB ID还是豆瓣ID
            let ttgid = has_imdb ? ('IMDB' + imdb_id.slice(2)) : zwm; // TTG 智能判定是用IMDB ID还是中文名
            let zxid = has_imdb ? imdb_id : zwm;  // ZX 智能判定是用IMDB ID还是中文名

            site_map.push({
                name: "PT影视顶配",
                label: [
                    { name: "CHDBits", link: 'https://chdbits.co/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, },
                    { name: "CMCT", link: 'https://hdcmct.org/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, },
                    { name: "HDChina", link: 'https://hdchina.org/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, selector: "table.torrent_list:last > tbody > tr:gt(0)" },
                    { name: "HDSky", link: 'https://hdsky.me/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, },
                    { name: "MTeam", link: 'https://tp.m-team.cc/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, },
                    { name: "TTG", link: 'https://totheglory.im/browse.php?c=M&notnewword=1&search_field=' + ttgid, selector: "table#torrent_table:last > tbody > tr:gt(0)" },
                ]
            });
            site_map.push({
                name: "PT影视标配",
                label: [
                    { name: "AIPT", link: 'http://pt.aipt123.org/table_list.php?search_area=1&notnewword=1&search=' + neizhan, },
                    { name: "BTSchool", link: 'http://pt.btschool.net/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan,/* selector: "table.torrents:last > tbody > tr:gt(0)"}, */ },
                    { name: "CCFBits", link: 'http://www.ccfbits.org/browse.php?fullsearch=1&notnewword=1&search=' + neizhan, selector: 'td[style="border:none;text-align:left"] a[title]' },
                    { name: "GZTown", link: 'https://pt.gztown.net/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, },
                    { name: "FRDS", link: 'http://pt.keepfrds.com/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, },
                    { name: "HDCity", link: 'https://hdcity.city/pt?incldead=1&search_area=1&notnewword=1&iwannaseethis=' + neizhan, selector: "center > div > div > div.text" },
                    // { name: "HDFANS", link: 'https://pt.hd4fans.org/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, },
                    { name: "HDHome", link: 'https://hdhome.org/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, },
                    { name: "HDStreet", link:   'https://hdstreet.club/torrents.php?incldead=1&search_area=4&notnewword=1&search=' + douban_id, },
                    { name: "HDTime", link: 'https://hdtime.org/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, },
                    { name: "HDU", link: 'http://pt.upxin.net/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, },
                    { name: "Hyperay", link: 'https://hyperay.org/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, selector: "table.torrents > tbody > tr.nonstick_outer_bg" },
                    { name: "JoyHD", link: 'https://www.joyhd.net/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, },
                    { name: "MHZ", link: 'https://pt.meihezi.com/torrents.php?incldead=1&search_area=4&notnewword=1&search=' + douban_id, },
                    { name: "MINE", type: "json", link: 'https://mine.pt/torrents/aggregate?keys=' + this_title + nian, ajax: "https://mine.pt/api/torrents?keys=" + this_title + nian, selector: "total > 0", selector_need_login: "#password" },
                    { name: "OurBits", link: 'https://ourbits.club/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, },
                    { name: "OurDiSC", link: 'http://bt.ourdisc.net/browse.php?incldead=0&notnewword=1&search=' + title, selector: "table[width='100%'][border='0'][cellspacing='0'][cellpadding='10'] i" },
                    { name: "TCCF", link: 'https://et8.org/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, },
                    { name: "TLFBits", link: 'http://pt.eastgame.org/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, },
                ]
            });
            if (is_anime) {
                site_map.push({
                    name: "PT动漫游戏",
                    label: [
                        { name: "AB", link: 'https://animebytes.tv/torrents.php?searchstr=' + ywm, selector: "div.thin > div.group_cont" },
                        { name: "AT", link: 'https://animetorrents.me/torrents.php?search=' + eng_title, ajax: 'https://animetorrents.me/ajax/torrents_data.php?total=1&search=' + eng_title + '&SearchSubmit=&page=1', headers: { "x-requested-with": "XMLHttpRequest" }, rewrite_href: false, selector: 'table.dataTable > tbody > tr:nth-child(2)', selector_need_login: "h1.headline strong:contains('Access Denied!')" },
                        { name: "BakaBT", link: 'https://bakabt.me/browse.php?q=' + ywm, selector: "table.torrents > tbody > tr:gt(0)", selector_need_login: "#loginForm" },
                        { name: "CC", link: 'http://www.cartoonchaos.org/index.php?page=torrents&options=0&active=1&search=' + ywm, selector: "table > tbody > tr:nth-child(2) > td > table > tbody > tr:nth-child(2) > td > table > tbody > tr:gt(0)", selector_need_login: "table[style='border-color:#E70000']" },
                        { name: "SkySnow", link: 'https://skyeysnow.com/forum.php?mod=torrents&notnewword=1&search=' + title + nian, selector: "table.torrents > tbody > tr:gt(0)" },
                        { name: "SolaGS", link: 'https://solags.org/torrents.php?incldead=1&search_area=0&notnewword=1&search=' + this_title + nian, },
                        { name: "U2", link: 'https://u2.dmhy.org/torrents.php?incldead=1&search_area=0&notnewword=1&search=' + this_title + nian, },
                    ]
                });
            }
            site_map.push({
                name: "PT影视IPV4",
                label: [
                    { name: "GHTT", link: 'https://pt.ghtt.net/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, selector: "table.torrents table.torrentname" },
                    { name: "NPUBITS", link: 'https://npupt.com/torrents.php?incldead=1&search_area=1&notnewword=1&' + npid, selector: "#torrents_table > tbody > tr:gt(0)" },
                    { name: "NYPT", link: 'https://nanyangpt.com/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, selector: "table.torrents:last > tbody > tr" },
                    { name: "SJTU", link: 'https://pt.sjtu.edu.cn/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, selector: "table.torrents:last > tbody > tr" },
                    { name: "TJUPT", link: 'https://www.tjupt.org/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, selector: "table.torrents:last > tbody > tr" },
                    { name: "WHUPT", link: 'https://whu.pt/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, selector: "table.torrents:last > tbody > tr" },
                ]
            });
            site_map.push({
                name: "PT影视IPV6",
                label: [
                    { name: "BYRBT", link: 'https://bt.byr.cn/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, },
                    { name: "HUDBT", link: 'https://hudbt.hust.edu.cn/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, },
                    { name: "NWSUAF", link: 'https://pt.nwsuaf6.edu.cn/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + neizhan, },
                    { name: "ZX", link: 'http://pt.zhixing.bjtu.edu.cn/search/x' + zxid + '-notnewword=1/', selector: "table.torrenttable > tbody > tr:gt(1)" },
                ]
            });
            site_map.push({
                name: "影视论坛资源",
                label: [
                    { name: "BT首发坛", link: 'http://www.btshoufa.net/search.php?mod=forum&searchsubmit=yes&srchtxt=' + gtitle, selector: "div.tl li.pbw" },
                    { name: "CHINAV影", link: 'http://www.159937.com/search-index-keyword-' + title + '.htm', selector: "#threadlist table.thread" },
                    { name: 'VIPHD', link: 'http://www.viphd.co/search-s-run?keyword=' + title, csrf: { name: 'csrf_token', update: "link" }, selector:'div.search_content dl', selector_need_login: 'div.header_login' },
                    { name: "爱拷电影", link: 'http://www.ikkao.com/?search-' + utitle + '-1.htm', selector: "div.row div.subject" },
                    { name: "久久MP4", link: 'http://www.99mp4.net/search.php?mod=forum&searchsubmit=yes&srchtxt=' + gtitle, selector: "div.tl li.pbw" },
                    { name: "蚂蚁高清", link: 'http://www.hdmayi.com/search.php?mod=forum&searchsubmit=yes&srchtxt=' + gtitle, selector: "div.tl li.pbw" },
                    { name: "深影论坛", link: 'http://www.shinybbs.info/search.php?mod=forum&searchsubmit=yes&srchtxt=' + gtitle, selector: "div.tl li.pbw" },
                    { name: "圣城家园", link: 'http://www.cnscg.com/search.php?mod=forum&searchsubmit=yes&srchtxt=' + gtitle, selector: "div.tl li.pbw" },
                    { name: "中国高清", link: 'http://www.87lou.com/search.php?mod=forum&searchsubmit=yes&srchtxt=' + gtitle, selector: "div.tl li.pbw" },
                ]
            });
            if (has_imdb) {
                site_map.push({
                    name: "PT影视外站",
                    label: [
                        { name: "4THD", link: 'https://4thd.xyz/torrents.php?searchtext=' + ywm, selector: "#torrent_table tr.torrent.rowb" },
                        { name: "ADC", link: 'http://asiandvdclub.org/browse.php?descr=1&btnSubmit=Search%21&search=' + imdb_id, selector: "table.torrenttable:last > tbody > tr" },
                        { name: "AOX", link: 'https://aox.to/index.php?page=torrents&options=4&search=' + imdb_id, selector: "table.table.table-bordered:last > tbody > tr:gt(0)" },
                        { name: "AR", link: 'https://alpharatio.cc/torrents.php?searchstr=' + ywm, selector: "#torrent_table > tbody > tr:gt(0)" },
                        { name: "AVZ", link: 'https://avistaz.to/torrents?in=1&search=' + ywm, selector: "table.table-condensed.table-striped.table-bordered:last > tbody > tr:gt(0)" },
                        { name: "BHD", link: 'https://beyond-hd.me/browse.php?incldead=0&search=' + imdb_id, selector: "table.tb_detail.grey.torrenttable:last > tbody > tr:gt(0)" },
                        { name: "Classix", link: 'http://classix-unlimited.co.uk/torrents-search.php?incldead=0&search=' + eng_title, selector: "table.ttable_headinner tr.t-row" },
                        { name: "FileList", link: 'https://filelist.ro/browse.php?searchin=3&search=' + imdb_id, selector: "div.torrentrow a[data-html='true']" },
                        { name: "HDF", link: 'https://hdf.world/torrents.php?searchstr=' + ywm, selector: "#torrent_table > tbody > tr:gt(0)" },
                        { name: "HDME", link: 'http://hdme.eu/browse.php?incldead=1&blah=1&search=' + imdb_id, selector: "table:nth-child(13) > tbody > tr" },
                        { name: "HDMonkey", link: 'https://hdmonkey.org/torrents-search.php?incldead=0&search=' + ywm, selector: "table.ttable_headinner > tbody > tr:gt(0)" },
                        { name: "HDS", link: 'https://hd-space.org/index.php?page=torrents&active=1&options=2&search=' + imdb_id, selector: "table.lista:last > tbody > tr:gt(0)", selector_need_login: "form[name='login']" },
                        { name: "HDT", link: 'https://hd-torrents.org/torrents.php?active=1&options=2&search=' + imdb_id, selector: "table.mainblockcontenttt b", selector_need_login: "form[name='login']" },
                        { name: "ILC", link: 'http://www.iloveclassics.com/browse.php?searchin=2&search=' + imdb_id, selector: "#hover-over > tbody > tr.table_col1:gt(0)" },
                        { name: "IPT", link: 'https://iptorrents.com/t?qf=all&q=' + imdb_id, selector: "#torrents td.ac" },
                        { name: "PHD", link: 'https://privatehd.to/torrents?in=1&search=' + ywm, selector: "table.table-condensed.table-striped.table-bordered:first > tbody > tr:gt(0)" },
                        { name: "PTF", link: 'http://ptfiles.net/browse.php?incldead=0&title=0&search=' + ywm, selector: "#tortable > tbody > tr.rowhead:gt(0)" },
                        { name: "PTP", link: 'https://passthepopcorn.me/torrents.php?searchstr=' + imdb_id, selector: '#torrent-table tr.group_torrent.group_torrent_header:gt(0)', selector_need_login: "#loginform" },
                        { name: "SC", link: 'https://secret-cinema.pw/torrents.php?cataloguenumber=' + imdb_id, selector: "div.torrent_card" },
                        { name: "Speed", link: 'https://speed.cd/browse.php?d=on&search=' + imdb_id, selector: "div.boxContent > table:first >tbody > tr:gt(0)" },
                        { name: "TD", link: 'https://www.torrentday.com/t?q=' + imdb_id, selector: "#torrentTable td.torrentNameInfo" },
                        { name: "TS", link: 'https://www.torrentseeds.org/browse.php?searchin=title&incldead=0&search=%22' + eng_title + year + '%22', selector: "table.table.table-bordered > tbody > tr.browse_color:gt(0)" },
                        { name: "TT", link: 'https://revolutiontt.me/browse.php?search=' + imdb_id, selector: "table#torrents-table > tbody > tr:gt(0)" },
                        { name: "TL", type: "json", link: "https://www.torrentleech.org/torrents/browse/index/query/" + eng_title + nian, ajax: "https://www.torrentleech.org/torrents/browse/list/query/" + eng_title + year, selector: "numFound > 0" },
                        { name: "UHD", link: 'https://uhdbits.org/torrents.php?searchstr=' + imdb_id, selector: "table.torrent_table > tbody > tr.group" },
                        { name: "WOP", link: 'http://worldofp2p.net/browse.php?incldead=0&searchin=descr&search=' + imdb_id, selector: "table.yenitorrenttable:last > tbody > tr:gt(0)" },
                        { name: "X264", link: 'http://x264.me/browse.php?incldead=0&stype=3&search=' + imdb_id, selector: "td a.index" },
                    ]
                });
                site_map.push({
                    name: "PT影视原声",
                    label: [
                        { name: "OpenCD", link: 'https://open.cd/torrents.php?incldead=1&search_area=0&notnewword=1&search=' + title, selector: "table.torrents:last > tbody > tr:gt(0)" },
                        { name: "Apollo", link: 'https://apollo.rip/torrents.php?searchstr=' + eng_title, selector: "#torrent_table:last > tbody > tr.group_torrent:gt(0)" },
                        { name: "JPOP", link: 'https://jpopsuki.eu/torrents.php?searchstr=' + eng_title, selector: "#torrent_table > tbody > tr:gt(0)" },
                        { name: "Red", link: 'https://redacted.ch/torrents.php?searchstr=' + eng_title, selector: "#torrent_table > tbody > tr.group_torrent:gt(0)" },
                        { name: "Waffles", link: 'https://waffles.ch/browse.php?q=' + eng_title, selector: "#browsetable:last > tbody > tr:gt(0)" },
                    ]
                });
                site_map.push({
                    name: "NZB影视资源",
                    label: [
                        { name: "DOGnzb", link: 'https://dognzb.cr/search?q=' + ywm, selector: "#featurebox > table > tbody > tr > td > table > tbody > tr.odd:gt(0)" },
                        { name: "LuluNZB", link: 'https://lulunzb.com/search/' + ywm, selector: "#browsetable > tbody > tr:gt(0)", selector_need_login: "div.login-box" },
                        { name: "Miatrix", link: 'https://www.miatrix.com/search/' + ywm, selector: "#browsetable > tbody > tr:gt(0)" },
                        { name: "NewzTown", link: 'https://newztown.co.za/search/' + ywm, selector: "#browsetable > tbody > tr:gt(0)" },
                        { name: "NZBCat", link: 'https://nzb.cat/search/' + ywm, selector: "#browsetable > tbody > tr:gt(0)" },
                        { name: "NZBgeek", link: 'https://nzbgeek.info/geekseek.php?moviesgeekseek=1&browsecategory=&browseincludewords=' + ywm, selector: "table > tbody > tr.HighlightTVRow2:gt(0)", selector_need_login: "input[value='do_login']" },
                        { name: "NZBP", link: 'https://nzbplanet.net/search/' + ywm, selector: "#browsetable > tbody > tr:gt(0)" },
                        { name: "Oznzb", link: 'https://www.oznzb.com/search/' + ywm, selector: "#browsetable > tbody > tr.ratingReportContainer:gt(0)", selector_need_login: "#login" },
                        { name: "SNZB", link: 'https://simplynzbs.com/search/' + ywm, selector: "#browsetable > tbody > tr:gt(0)" },
                    ]
                });
            }
            if (!is_mainland) {
                site_map.push({
                    name: "PT影视字幕",
                    label: [
                        { name: "AIPT®", link: "http://pt.aipt123.org/subtitles.php?notnewword=1&search=" + ptzimu, selector: "table[width='100%'][border='1'][cellspacing='0'][cellpadding='5'] > tbody > tr:nth-child(2)" },
                        { name: "CHDBits®", link: "https://chdbits.co/subtitles.php?notnewword=1&search=" + ptzimu, selector: "table:last > tbody > tr:gt(1)" },
                        { name: "CMCT®", link: "https://hdcmct.org/subtitles.php?notnewword=1&search=" + ptzimu, selector: "table:last > tbody > tr:gt(1)" },
                        { name: "FRDS®", link: "http://pt.keepfrds.com/subtitles.php?notnewword=1&search=" + ptzimu, selector: "table[width='940'][border='1'][cellspacing='0'][cellpadding='5'] > tbody > tr:nth-child(2)" },
                        { name: "GHTT®", link: 'https://pt.ghtt.net/subtitles.php?notnewword=1&search=' + ptzimu, selector: "table[width='940'][border='1'][cellspacing='0'][cellpadding='5'] > tbody > tr:nth-child(2)" },
                        { name: "HDChina®", link: "https://hdchina.org/subtitles.php?notnewword=1&search=" + ptzimu, selector: "table.uploaded_sub_list > tbody > tr:gt(1)" },
                        { name: "HDCity®", link: "https://hdcity.city/subtitles?notnewword=1&search=" + ptzimu, selector: "center > div:nth-child(1) > table > tbody > tr:nth-child(2)" },
                        { name: "HDHome®", link: "https://hdhome.org/subtitles.php?notnewword=1&search=" + ptzimu, selector: "table:last > tbody > tr:gt(1)" },
                        { name: "HDSky®", link: "https://hdsky.me/subtitles.php?notnewword=1&search=" + ptzimu, selector: "table:last > tbody > tr:gt(1)" },
                        { name: "HDTime®", link: "https://hdtime.org/subtitles.php?notnewword=1&search=" + ptzimu, selector: "table[width='100%'][border='1'][cellspacing='0'][cellpadding='5'] > tbody > tr" },
                        { name: "HDU®", link: "http://pt.upxin.net/subtitles.php?notnewword=1&search=" + ptzimu, selector: "table[width='940'][border='1'][cellspacing='0'][cellpadding='5'] > tbody > tr:nth-child(2)" },
                        { name: "Hyperay®", link: "https://hyperay.org/subtitles.php?notnewword=1&search=" + ptzimu, selector: "table[width='940'][border='1'][cellspacing='0'][cellpadding='5'] > tbody > tr:nth-child(2)" },
                        { name: "JoyHD®", link: "https://www.joyhd.net/subtitles.php?notnewword=1&search=" + ptzimu, selector: "table[width='940'][border='1'][cellspacing='0'][cellpadding='5'] > tbody > tr:nth-child(2)" },
                        { name: "MTeam®", link: "https://tp.m-team.cc/subtitles.php?notnewword=1&search=" + ptzimu, selector: "table.table-subtitle-list:last > tbody > tr" },
                        { name: "NPUBITS®", link: "https://npupt.com/subtitles.php?notnewword=1&search=" + ptzimu, selector: "#main > table > tbody > tr:nth-child(2)" },
                        { name: "NYPT®", link: "https://nanyangpt.com/subtitles.php?notnewword=1&search=" + ptzimu, selector: "table[width='940'][border='1'][cellspacing='0'][cellpadding='5'] > tbody > tr:nth-child(2)" },
                        { name: "OurBits®", link: "https://ourbits.club/subtitles.php?notnewword=1&search=" + ptzimu, selector: "table[width='940'][border='1'][cellspacing='0'][cellpadding='5'] > tbody > tr:nth-child(2)" },
                        { name: "SJTU®", link: "https://pt.sjtu.edu.cn/subtitles.php?notnewword=1&search=" + ptzimu, selector: "table[width='940'][border='1'][cellspacing='0'][cellpadding='5'] > tbody > tr:nth-child(2)" },
                        { name: "TCCF®", link: "https://et8.org/subtitles.php?notnewword=1&search=" + ptzimu, selector: "table[width='940'][border='1'][cellspacing='0'][cellpadding='5'] > tbody > tr:nth-child(2)" },
                        { name: "TJUPT®", link: "https://www.tjupt.org/subtitles.php?notnewword=1&search=" + ptzimu, selector: "table[width='940'][border='1'][cellspacing='0'][cellpadding='5'] > tbody > tr:nth-child(2)" },
                        { name: "TLFBits®", link: "http://pt.eastgame.org/subtitles.php?notnewword=1&search=" + ptzimu, selector: "table[width='940'][border='1'][cellspacing='0'][cellpadding='5'] > tbody > tr:nth-child(2)" },
                        { name: "U2®", link: "https://u2.dmhy.org/subtitles.php?notnewword=1&search=" + ptzimu, selector: "table[width='940'][border='1'][cellspacing='0'][cellpadding='5'] > tbody > tr:nth-child(2)" },
                        { name: "WHUPT®", link: "https://pt.whu.edu.cn/subtitles.php?notnewword=1&search=" + ptzimu, selector: "table.no-vertical-line:last > tbody > tr" },
                    ]
                });
            }
        }
        if (!is_mainland) {
            site_map.push({
                name: "中文影视字幕",
                label: [
                    { name: '字幕仓', method: "post", link: 'http://www.zimucang.com/e/search/index.php', data: `show=title&keyboard=${title}&Submit22=%E6%90%9C%E7%B4%A2`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: "table.box h2.r" },
                    { name: '字幕库', link: 'http://www.zimuku.cn/search?q=' + title, selector: 'div.box.clearfix div.item.prel.clearfix' },
                    { name: '字幕天堂', method: "post", link: 'http://www.zmtiantang.com/e/search/', data: `keyboard=${title}&show=title&classid=1,3&tempid=1`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: 'table.data > tbody > tr:nth-child(2)' },
                    { name: '字幕组', link: 'http://www.zimuzu.tv/search/index?type=subtitle&keyword=' + title, selector: ".search-result li" },
                    { name: 'sub HD', link: 'http://subhd.com/search/' + title, selector: "div.col-md-9 div.box" },
                    { name: '伪射手', link: 'http://assrt.net/sub/?searchword=' + title, selector: "#resultsdiv a.introtitle" },
                    { name: '163字幕', link: 'http://www.163sub.com/Search?id=' + title, selector: "#main_narrow_bd div.subs_list" },
                    { name: '电波字幕', link: 'http://dbfansub.com/?s=' + title, selector: "div.panel-body article.panel.panel-default.archive" },
                    { name: '字幕社', link: 'https://www.zimushe.com/search.php?keywords=' + title, selector: "div.wrap-l li" },
                    { name: '中文字幕网', link: 'http://www.zimuzimu.com/so_zimu.php?title=' + title, selector: "table.sublist a.othersub" },
                    { name: 'r3sub', link: 'https://r3sub.com/search.php?s=' + title, selector: "div.col-sm-8.col-md-9.col-lg-8 div.movie.movie--preview.ddd" },
                    { name: 'HDZIMU', link: 'http://www.hdzimu.com/?s=' + title, selector: 'div.post-warp div.post-box' },
                    { name: 'M1080', link: 'http://zimu.m1080.com/search.asp?a=&s=' + title, selector: "table td" },
                    { name: 'OpenSub', link: 'https://www.opensubtitles.org/zh/search/sublanguageid-chi,zht,zhe,eng/imdbid-' + imdb_id, selector: "#search_results tr.change" },
                ]
            });
        }
        if (has_imdb) {
            site_map.push({
                name: "英文影视字幕",
                label: [
                    { name: 'Addic7ed', link: 'http://www.addic7ed.com/search.php?search=' + eng_title_clean + year, selector: "table.tabel tr" },
                    { name: 'Podnapisi', link: 'https://www.podnapisi.net/zh/subtitles/search/?language=zh&language=en&keywords=' + eng_title_clean + '&' + year + '-' + year, selector: "table tr.subtitle-entry" },
                    { name: 'Subscene', link: 'https://subscene.com/subtitles/release?r=true&q=' + ywm, selector: "table td.a1" },
                    { name: 'TVsubs', link: 'http://tvsubs.net/search.php?q=' + eng_title_clean, selector: "div.cont li" },
                    { name: 'TVsubtitles', link: 'http://www.tvsubtitles.net/search.php?q=' + eng_title_clean, selector: "div.left_articles li" },
                    { name: 'YIFY', link: 'http://www.yifysubtitles.com/search?q=' + eng_title_clean, selector: "div.col-sm-12 div.col-xs-12" },
                ]
            });
        }
        site_map.push({
            name: "影视精准匹配",
            label: [
                { name: 'BT人人', link: 'http://www.btrenren.com/index.php/Search/index.html?search=' + dbzw, selector: 'div.ml p.des' },
                { name: 'BT天堂', link: 'http://www.bttt.la/s.php?q=' + gongwang, selector: 'div.ml div.title' },
                { name: 'PianHD', link: 'http://www.pianhd.com/so/' + gongwang, selector: 'table.table.table-condensed.table-hover.table-objects div.mov_info' },
                { name: 'RARBT', link: 'http://www.rarbt.com/index.php/search/index.html?search=' + dbzw, selector: 'div.ml div.title' },
                { name: '爱笑聚', link: 'http://www.aixiaoju.com/app-index-run?app=search&keywords=' + dbzw, /*csrf: { name: 'csrf_token', update: "link" },*/ selector: 'div.search_content div.text' },
                { name: '电影传送门', link: 'http://www.dycsm.com/Mov/so/' + gongwang, selector: 'div.movieList div.info' },
                { name: '胖鸟电影', link: 'http://www.pniao.com/Mov/so/' + gongwang, selector: `div.title a:contains(${title})` },
                { name: '一起看电影', link: 'http://www.17kys.com/Search.jsp?q=' + gongwang, selector: `h5 a:contains(${title})` },
                { name: '追高清', link: 'http://www.zhuihd.com/?s=' + gongwang, selector: '#main li.entry-title' },
            ]
        });
        site_map.push({
            name: "在线正版影视",
            label: [
                { name: '爱奇艺视频', link: 'https://so.iqiyi.com/so/q_' + title, selector: "div.mod_result span.play_source" },
                { name: '哔哩哔哩', link: 'https://search.bilibili.com/all?keyword=' + title, ajax: "https://search.bilibili.com/api/search?search_type=all&keyword=" + title, type: "json", selector: 'result.media_bangumi.length > 0 || par.result.media_ft.length > 0' },
                { name: '乐视视频', link: 'http://so.le.com/s?wd=' + title, selector: `h1 > a.j-baidu-a[title*='${title}']` },
                { name: '搜狐视频', link: 'https://so.tv.sohu.com/mts?wd=' + title, selector: 'div.wrap.cfix div.cfix.resource' },
                { name: '腾讯视频', link: 'https://v.qq.com/x/search/?q=' + title, selector: 'div.wrapper_main div._infos' },
                { name: '优酷视频', link: 'http://so.youku.com/search_video/q_' + title, ajax: 'http://www.soku.com/m/y/video?q=' + title, selector: 'div.yk_dir div.card_info' },
            ]
        });
        site_map.push({
            name: "在线影视视频",
            label: [
                { name: '4K屋', link: 'http://www.4kwu.cc/?m=vod-search&wd=' + title, selector: 'div.tv-bd.search-list div.item_txt' },
                { name: 'AAQQS', link: 'http://aaxxy.com/vod-search-pg-1-wd-' + title + '.html', selector: '#find-focus li' },
                { name: 'Neets', link: 'http://neets.cc/search?key=' + title, selector: '#search_li_box div.search_li.clearfix' },
                { name: 'Q2电影网', link: 'http://www.q2002.com/search?wd=' + title, selector: 'div.container div.movie-item' },
                { name: '霸气村', link: 'http://www.baqicun.co/search.php?searchword=' + title, selector: 'div.k_sou div.k_sou-4' },
                { name: '电影盒子', method: "post", link: 'http://www.5iwanyouxi.com/index.php?s=vod-search-name&wd=' + title, data: `wd=${title}`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: 'div.v_tb div.v_txt' },
                { name: '嗨哆咪影视', link: 'http://www.haiduomi.com/index.php?m=vod-search-wd-' + title, selector: 'div.fed-layouts.fed-bgc-whits.fed-margin-right h3.fed-elip' },
                { name: '魔力电影网', link: 'http://www.magbt.net/search.php?searchword=' + title, selector: '#content li.listfl' },
                { name: '新论语', link: 'http://www.honggujiu.com/index.php?m=vod-search&wd=' + title, selector: 'div.col-xs-12 div.meta' },
                { name: '左手吃斋', link: 'https://www.zsczys.com/index.php?m=vod-search&wd=' + title, selector: 'div.col-xs-12 div.meta' },
            ]
        });
        if (is_anime) {
            site_map.push({
                name: "在线动漫视频",
                label: [
                    { name: '9ANIME', link: 'https://www4.9anime.is/search?keyword=' + eng_title, selector: "div.film-list a.name" },
                    { name: '爱看番', link: 'http://www.ikanfan.com/search/?wd=' + title, selector: '#listvod div.d-info' },
                    { name: '次元壁', link: 'http://www.ciyuan.bi/Search?keyword=' + title, selector: 'div.search_left_container div.search_list_box_right' },
                    { name: '嘀哩嘀哩', link: 'http://zhannei.baidu.com/cse/search?wt=1&ht=1&pn=10&s=4514337681231489739&q=' + title, selector: '#results h3.c-title' },
                    { name: '新世界动漫', link: 'http://www.x4jdm.com/index.php?m=vod-search&wd=' + title, selector: 'div.oh div.dhp' },
                ]
            });
        }
        if (is_anime) {
            site_map.push({
                name: "动漫国内网站",
                label: [
                    { name: 'ACG.RIP', link: 'https://acg.rip/?term=' + title, selector: 'tbody tr' },
                    { name: 'ACG狗狗', link: 'http://bt.acg.gg/search.php?keyword=' + title, selector: 'tbody p.original.download' },
                    { name: 'ACG搜', link: 'http://www.acgsou.com/search.php?keyword=' + title, selector: 'tbody span.bts_1' },
                    { name: 'D动漫', link: 'http://dm1080p.com/?s=' + title, selector: `h1.entry-title a:contains(${title})` },
                    { name: 'Mikan', link: 'https://mikanani.me/Home/Search?searchstr=' + title, selector: 'table.table.table-striped.tbl-border.fadeIn a.magnet-link-wrap' },
                    { name: 'OneAnime', link: 'https://anime.rhilip.info/', selector: `ul.mdui-list li[data-sort-name*='${title}']` },
                    { name: 'VCB-S', link: 'https://vcb-s.com/?s=' + title, selector: '#article-list div.title-article' },
                    { name: '爱恋动漫', link: 'http://www.kisssub.org/search.php?keyword=' + title, selector: 'tbody span.bts_1' },
                    { name: '稻田装尸', link: 'https://www.dm2046.com/?s=' + title, selector: 'div.mi_cont h3.dytit' },
                    { name: '动漫花园', link: 'https://share.dmhy.org/topics/list?keyword=' + title, selector: 'tbody span.btl_1' },
                    { name: '漫喵动漫', link: 'http://www.comicat.org/search.php?keyword=' + title, selector: '#data_list tr' },
                    { name: "萌番组", method: "post", type: "json", link: "https://bangumi.moe/search/title#search_" + title, ajax: "https://bangumi.moe/api/v2/torrent/search", data: `{"query":"${title}"}`, headers: { "Content-Type": "text/plain;charset=UTF-8" }, selector: "count > 0" },
                    { name: '喵搜', link: 'https://nyaso.com/dong/' + title + '.html', selector: 'tbody a.down' },
                    { name: '魔法少女', link: 'https://www.mahou-shoujo.moe/?s=' + this_title, selector: '#main div.entry-summary' },
                    { name: '旋风动漫', link: 'http://share.xfsub.com:88/search.php?keyword=' + title, selector: '#listTable span.bts_1' },
                    { name: '怡萱动漫', link: 'http://www.yxdm.tv/search.html?title=' + title, selector: 'div.main p.stars1' },
                ]
            });
        }

        if (is_anime && eng_title.trim().length > 0) {
            site_map.push({
                name: "动漫国外网站",
                label: [
                    { name: 'AniDex', link: 'https://anidex.info/?q=' + eng_title, selector: 'div.table-responsive tr' },
                    { name: 'AniRena', link: 'https://www.anirena.com/?s=' + eng_title, selector: '#content table' },
                    { name: 'AniTosho', link: 'https://animetosho.org/search?q=' + eng_title, selector: '#content div.home_list_entry' },
                    { name: 'Nyaa', link: 'https://nyaa.si/?q=' + eng_title, selector: 'div.table-responsive tr.default' },
                    { name: 'ニャパンツ', link: 'https://nyaa.pantsu.cat/search?c=_&q=' + eng_title, selector: '#torrentListResults tr.torrent-info' },
                    { name: '东京図书馆', link: 'https://www.tokyotosho.info/search.php?terms=' + eng_title, selector: 'table.listing td.desc-top' },
                ]
            });
        }
        if (is_series && is_europe) {
            site_map.push({
                name: "欧美剧集下载",
                label: [
                    { name: '58美剧', link: 'http://www.58meiju.com/index.php?m=vod-search&wd=' + title, selector: 'div.channel.b div.l' },
                    { name: '592美剧', method: "post", link: 'http://www.592meiju.com/search--1.html?wd=' + title, data: `wd=${title}`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: 'div.serach-box div.info' },
                    { name: 'BT美剧', link: 'http://www.btmeiju.com/ustv_search.htm?title=' + title, selector: '#_container div.comm_box' },
                    { name: 'EZTV', link: 'https://eztv.ag/search/' + ywm.replace(/S\d+$/g,''), selector: `td.forum_thread_post > a[title*='${ywm.replace(/S\d+$/g,'')}']` },
                    { name: 'KPPT', link: 'http://www.kppt.cc/search.php?q=' + title, selector: 'div.search span.SearchAlias' },
                    { name: '爱美剧', link: 'https://22v.net/search/' + title, selector: 'div.movie span' },
                    { name: '每日美剧', link: 'http://www.meirimeiju.com/search?words=' + title, selector: 'div.container div.movie-title' },
                    { name: '美剧吧', link: 'http://www.meiju8.cc/search.php?kw=' + title, selector: 'div.box_bg_r ul.list_20' },
                    { name: '美剧粉', link: 'http://www.itvfans.com/?s=' + title, selector: '#main-wrap-left div.home-blog-entry-text' },
                    { name: '美剧迷', link: 'http://www.meijumi.vip/index.php?s=' + title + ' 下载', selector: `h2.entry-title > a:contains(${title})` },
                    { name: '美剧天堂', method: "post", link: 'http://www.meijutt.com/search.asp?searchword=' + gtitle, ajax: 'http://www.meijutt.com/search.asp', data: `searchword=${gtitle}`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, selector: 'div.list3_cn_box ul.list_20' },
                    { name: '人人影视', link: 'http://www.zimuzu.tv/search?type=resource&keyword=' + title, selector: "div.search-result > ul > li" },
                    { name: '人人美剧', link: 'http://www.yyetss.com/Search/index/s_keys/' + title, selector: 'div.row div.col-xs-3' },
                    { name: '天天看美剧', link: 'http://www.msj1.com/?s=' + title, selector: 'div.cat_list div.art_show_top' },
                    { name: '天天美剧', link: 'http://www.ttmeiju.vip/index.php/search/index.html?keyword=' + title, selector: 'table.latesttable tr.Scontent1' },
                ]
            });
        }
        if (is_series && is_japan && !is_anime) {
            site_map.push({
                name: "日剧资源下载",
                label: [
                    { name: '91日剧', link: 'http://www.91riju.com/?s=' + title, selector: `h2.entry-title > a:contains(${title})` },
                    { name: '搬运自留地', link: 'https://blog.aipanpan.com/?s=' + title, selector: `h2.entry-title > a:contains(${title})` },
                    { name: "东京不够热", method: "post", link: "http://www.tokyonothot.com/search.php?mod=portal", data: `srchtxt=${gtitle}&searchsubmit=yes`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: "div.tl li.pbw" },
                    { name: '光合社', link: 'http://pssclub.com/search.php?mod=forum&srchuname=&srchfilter=all&srchfrom=0&before=&orderby=lastpost&ascdesc=desc&srchfid%5B%5D=2&srchfid%5B%5D=36&searchsubmit=yes&srchtxt=' + title, selector: '#threadlist li.pbw' },
                    { name: '花泽工坊', link: 'https://discuss.huayiwork.com/?q=' + title, ajax: "https://discuss.huayiwork.com/api/discussions?include=startUser%2ClastUser%2CrelevantPosts%2CrelevantPosts.discussion%2CrelevantPosts.user%2CstartPost%2Ctags&filter%5Bq%5D=" + title + "&", type: "json", selector: 'data.length > 0' },
                    { name: '隐社', link: 'http://www.hideystudio.com/drama/' + release_year + drama_season + '.html', selector: `td > span.titles:contains(${title})` },
                    { name: '猪猪日部落', link: 'http://www.zzrbl.com/?s=' + title, selector: 'div.section_body li' },
                    { name: '追新番', method: "post", link: 'http://www.zhuixinfan.com/search.php?searchsubmit=yes', data: `mod=tvplay&formhash=453fc7da&srchtype=title&srhfid=0&srhlocality=main%3A%3Aindex&srchtxt=${title}&searchsubmit=true`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: '#wp td.td2' },
                ]
            });
        }
        if (is_series && is_korea && !is_anime) {
            site_map.push({
                name: "韩剧资源下载",
                label: [
                    { name: '韩饭网', link: 'http://www.hanfan.cc/?s=下载 ' + title, selector: 'div.content p.meta' },
                    { name: '韩迷', method: "post", link: "http://www.hanmi520.com/search.php?mod=forum", data: `srchtxt=${gtitle}&seltableid=0&srchuname=&srchfilter=all&srchfrom=0&before=&orderby=lastpost&ascdesc=desc&srchfid%5B%5D=8&srchfid%5B%5D=185&srchfid%5B%5D=23&srchfid%5B%5D=24&srchfid%5B%5D=101&srchfid%5B%5D=186&srchfid%5B%5D=9&srchfid%5B%5D=25&srchfid%5B%5D=26&searchsubmit=yes`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: "div.tl li.pbw" },
                ]
            });
        }
        if (is_series && is_thai && !is_anime) {
            site_map.push({
                name: "泰剧资源下载",
                label: [
                    { name: '97泰剧网', link: 'http://www.97taiju.com/index.php?s=vod-search&wd=' + title, selector: '#vodlist dd.title' },
                    { name: '泰剧资料馆', link: 'http://www.taijuzlg.com/?s=泰剧下载 ' + title, selector: '#main li.entry-title' },
                ]
            });
        }
        if (is_document) {
            site_map.push({
                name: "纪录片下载站",
                label: [
                    { name: '纪录片天地', link: 'https://www.bing.com/search?q=site%3Awww.jlpcn.net+intitle%3A' + title, selector: '#b_content div.b_title' },
                    { name: '老纪录', link: 'https://www.laojilu.com/?s=' + title, selector: '#content li' },
                    { name: '熊猫盘纪录', link: 'http://xiongmaopan.com/search/' + title, selector: `h2 > a[title*='${title}']` },
                ]
            });
        }
        site_map.push({
            name: "电影资源下载",
            label: [
                { name: '2TU影院', link: 'http://www.82tu.cc/search.php?submit=%E6%90%9C+%E7%B4%A2&searchword=' + title, selector: 'ul.mlist div.info' },
                { name: '52 Movie', link: 'http://www.52movieba.com/search.htm?keyword=' + title, selector: 'table.table.table-hover.threadlist tr.thread.tap' },
                { name: '592美剧', link: 'http://www.592meiju.com/search/?wd=' + title, selector: 'ul.serach-ul div.info' },
                { name: '66影视网', method: "post", link: 'https://www.66ys.tv/e/search/index.php', data: `show=title%2Csmalltext&tempid=1&tbname=Article&keyboard=${gtitle}&Submit22=%E6%90%9C%E7%B4%A2`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: "div.listBox li" },
                { name: '6V电影网', method: "post", link: 'http://www.6vhao.tv/e/search/index.php', data: `show=title%2Csmalltext&tempid=1&tbname=Article&keyboard=${gtitle}&Submit22=%E6%90%9C%E7%B4%A2`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: "div.listBox li" },
                { name: '8V电影网', link: 'http://www.8vdy.com/search.asp?searchword=' + gtitle, selector: '#div_2 div.listInfo' },
                { name: '80s手机', method: "post", link: 'https://www.80s.tw/search#search_' + title, data: `keyword=${title}`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, selector: '#block3 i.fa.fa-film' },
                { name: '962电影网', link: 'http://www.fx962.com/search.asp?searchword=' + gtitle, selector: '#contents li' },
                { name: '97电影网', link: 'http://www.id97.com/search?q=' + title, selector: 'div.container div.col-xs-7' },
                { name: '9去这里', link: 'http://9qzl.com/index.php?s=/video/search/wd/' + title, selector: "ul.mov_list li" },
                { name: 'BD影视', link: 'http://www.bd-film.co/search.jspx?q=' + title, selector: 'div.dfg-video-list div.title' },
                { name: 'CK电影', link: 'http://www.ck180.net/search.html?q=' + title, selector: 'ul.serach-ul div.info' },
                { name: 'LOL电影', link: 'http://www.993dy.com/index.php?m=vod-search&wd=' + title, selector: 'div.movielist a.play-img' },
                { name: 'MP4Vv', link: 'http://www.mp4pa.com/search.php?searchword=' + title, selector: 'ul.list-unstyled h4.weixin' },
                { name: 'MP4电影', link: 'http://www.domp4.com/search/' + title + '-1.html', selector: 'div.vodlist_l.box div.play_info' },
                { name: 'TKing', link: 'https://torrentking.to/search?mk=' + eng_title, selector: '#slider-runningshows div.slide-item' },
                { name: 'TL95', link: 'http://www.tl95.com/?s=' + title, selector: `li.entry-title > a:contains(${title})` },
                { name: '爱下电影网', link: 'http://www.aixia.cc/plus/search.php?searchtype=titlekeyword&q=' + title, selector: 'div.con li' },
                { name: '比特大雄', link: 'https://www.btdx8.com/?s=' + title, selector: '#content div.post.clearfix' },
                { name: '比特影视', link: 'https://www.bteye.com/search/' + title, selector: '#main div.item' },
                { name: '创世影院', link: 'http://www.cuangs.com/so/' + title, selector: 'div.box span' },
                { name: '第一电影网', link: 'https://www.001d.com/?s=' + title, selector: 'div.mainleft div.info' },
                { name: '电影港', method: "post", link: 'http://so.dygang.net/e/search/index.php', data: `tempid=1&tbname=article&keyboard=${gtitle}&show=title%2Csmalltext&Submit=%CB%D1%CB%F7`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: "table[width='100%'][border='0'][cellspacing='0'][cellpadding='0'] a.classlinkclass" },
                { name: '电影日志', link: 'http://www.dyrizhi.com/search?s=' + title, selector: 'div.pure-g div.item' },
                { name: '电影首发站', link: 'http://www.dysfz.cc/key/' + title + '/', selector: '.movie-list li' },
                { name: '电影天堂', method: "post", link: 'https://www.dy2018.com/e/search/index.php', data: `show=title%2Csmalltext&tempid=1&keyboard=${gtitle}&Submit=%C1%A2%BC%B4%CB%D1%CB%F7`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: 'div.co_content8 table' },
                { name: '钉子电影', method: "post", link: 'http://www.dingzibd.com/q#search_' + title, data: `keyword=${title}`, csrf: { name: "_csrf", update: "data" }, headers: { "Content-Type": "application/x-www-form-urlencoded" }, selector: `h4 > a:contains(${title})` },
                { name: '嘎嘎影视', link: 'http://www.gagays.xyz/movie/search?req%5Bkw%5D=' + title, selector: '#movie-sub-cont-db div.large-movie-detail' },
                { name: '高清888', link: 'https://www.gaoqing888.com/search?kw=' + title, selector: 'div.wp-content div.video-row' },
                { name: '高清MP4', link: 'http://www.99tvs.com/?s=' + title, selector: '#post_container li' },
                { name: '高清电台', link: 'https://gaoqing.fm/s.php?q=' + title, selector: '#result1 div.row' },
                { name: '高清控', link: 'http://www.gaoqingkong.com/?s=' + title, selector: '#post_container div.post_hover' },
                { name: '户户盘', method: "post", link: 'http://huhupan.com/e/search/index.php', data: `keyboard=${title}&show=title&tempid=1&tbname=news&mid=1&depost=search`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: 'div.main h2' },
                { name: '界绍部', link: 'http://www.jsb456.com/?s=' + title, selector: '#content h2.title' },
                { name: '就爱那片', method: "post", link: 'http://www.inapian.com/index.php?s=vod-search&wd=' + title, data: `wd=${title}`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: 'div.sortcon div.minfo' },
                { name: '看美剧', link: 'http://www.kanmeiju.net/index.php?s=/video/search/wd/' + title, selector: 'div.listri p.t' },
                { name: '蓝光网', link: 'http://www.languang.co/?s=' + title, selector: 'div.mi_cont li' },
                { name: '老司机电影', link: 'http://www.lsjdyw.net/search/?s=' + title, selector: 'div.row div.row.list.shadow' },
                { name: "乐赏电影", link: 'https://www.gscq.me/search.htm?keyword=' + title, selector: 'div.media-body div.subject.break-all' },
                { name: '美剧仓库', method: "post", link: 'http://www.meijuck.com/e/search/index.php', data: `show=title&tempid=1&tbname=news&mid=1&dopost=search&keyboard=${title}&submit=`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: "div.content-wrap p.note" },
                { name: "美剧汇", link: 'http://www.meijuhui.net/search.php?q=' + title, selector: 'article.excerpt li.focus' },
                { name: '美剧鸟', link: 'http://www.meijuniao.com/index.php?s=vod-search-wd-' + title + '.html', headers: { "X-Requested-With": "XMLHttpRequest" }, ajax: "http://www.meijuniao.com/index.php?s=vod-search-wd-" + title + "-1-ajax", type: "json", selector: 'data.count > 0' },
                { name: '迷你MP4', link: 'http://www.minimp4.com/search?q=' + title, selector: 'div.container div.col-xs-7' },
                { name: '泡饭影视', link: 'http://www.chapaofan.com/search/' + title, selector: `li a[title*='${title}']` },
                { name: '片吧', link: 'http://so.pianbar.com/search.aspx?q=' + title, selector: `h4.media-heading + span:contains(${title})` },
                { name: '片源网', link: 'http://pianyuan.net/search?q=' + title, selector: 'div.row ul.detail' },
                { name: '飘花资源网', link: 'https://www.piaohua.com/plus/search.php?kwtype=0&keyword=' + title, selector: 'div.container div.txt' },
                { name: '且听风吟', link: 'http://www.iqtfy.com/index.php?m=vod-search&wd=' + title, selector: 'div.channel.b li' },
                { name: '趣味源', link: 'http://quweiyuan.cc/?s=' + title, selector: `h2.post-entry-headline a:contains(${title})` },
                { name: '人生05', link: 'http://www.rs05.com/search.php?s=' + title, selector: '#movielist li' },
                { name: '贪玩影视', link: 'http://www.tanwanyingshi.com/movie/search?keyword=' + title, selector: 'div.col-md-8 div.service-content' },
                { name: '新6V电影', method: "post", link: 'https://www.66s.cc/e/search/index.php', data: `show=title&tempid=1&tbname=article&mid=1&dopost=search&submit=&keyboard=${title}`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: '#post_container div.entry_post' },
                { name: '新片网', link: 'http://www.91xinpian.com/index.php?m=vod-search&wd=' + title, selector: 'div.search span.name' },
                { name: '迅雷影天堂', link: 'https://www.xl720.com/?s=' + title, selector: `h3 a[title*='${title}']` },
                { name: '迅影网', link: 'http://www.xunyingwang.com/search?q=' + title, selector: 'div.row p.movie-name' },
                { name: '阳光电影', link: 'http://s.ygdy8.com/plus/so.php?kwtype=0&searchtype=title&keyword=' + gtitle, selector: "div.co_area2 table[border='0'][width='100%']" },
                { name: '扬天影视', link: 'https://www.mcyt.cn/?s=' + title, selector: 'div.mainleft div.info' },
                { name: '一只大榴莲', link: 'http://www.llduang.com/?s=' + title, selector: 'div.mainleft div.info' },
                { name: '音范丝', link: 'http://www.yinfans.com/?s=' + title, selector: `div.thumbnail a[title*='${title}']` },
                { name: '影海', link: 'http://www.yinghub.com/search/list.html?keyword=' + title, selector: 'div.row div.info' },
                { name: '影视看看', link: 'http://www.yskk.tv/index.php?m=vod-search&wd=' + title, selector: 'div.movielist li' },
                { name: '云播网', link: 'http://www.yunbowang.cn/index.php?m=vod-search&wd=' + title, selector: 'div.container div.col-xs-7' },
                { name: '中国高清网', link: 'http://gaoqing.la/?s=' + title, selector: 'div.mainleft div.thumbnail' },
                { name: '宅腐资源站', link: 'http://www.zhaifu.cc/plus/search.php?kwtype=0&q=' + gtitle, selector: 'div.content a.focus' },
                { name: '宅客', link: 'https://www.zhaiiker.com/?post_type=post&s=' + title + ' 下载', selector: '#main h2.entry-title' },
                { name: '最新影视站', link: 'http://www.zxysz.com/?s=' + title, selector: '#content li.p-item' },
            ]
        });


        site_map.push({
            name: "BT国内网站",
            label: [
                { name: 'BT@烧包', link: 'http://bt.f-fans.club/search-' + utitle + '.htm', selector: 'div.row div.media-body' },
                { name: 'BT吧', link: 'http://www.btba.cc/search?keyword=' + title, selector: 'div.left li' },
                { name: 'BT部落', link: 'http://www.btbuluo.com/s/' + title + '.html', selector: `h2 a:contains(${title})` },
                { name: 'BT下吧', link: 'http://www.btxiaba.com/index.php?m=vod-search&wd=' + title, selector: '#content p.pl' },
                { name: 'BT之家', link: 'http://www.btbtt.co/search-index-keyword-' + title + '.htm', selector: '#threadlist table' },
                { name: '不太灵', method: "post", link: 'http://bt0.com/e/search/', data: `keyboard=${gongwang}&show=title%2Cbtname%2Cimdb%2Cdouban_id%2Cmvtitle&tbname=torrent&tempid=3&orderby=onclick`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: "div.row div.col-sm-3" },
                { name: '查片源', link: 'https://www.chapianyuan.com/?keyword=' + title, selector: 'div.block li' },
                { name: '磁力猫', link: 'http://www.cilimao.me/search?word=' + title, selector: '#Search__content_left___2MajJ div.MovieCard__content___3kv1W' },   // TODO check
                { name: '磁力站', link: 'http://oabt004.com/index/index?c=&k=' + title, selector: 'div.link-list-wrapper ul.link-list' },
                { name: '飞客BT', link: 'http://feikebt.com/s/' + title + '.html', selector: 'div.ppwrapper div.categorybar' },
                { name: '光影资源', link: 'http://www.etdown.net/index.php?keyword=' + title, selector: 'tbody.list_4 tr' },
                { name: '小浣熊下载', link: `https://www.xiaohx.org/search?key=${title}`, selector: `div.result_p a[title*='${title}']` },
                { name: '一站搜', link: 'http://v.yizhansou.com/search?kw=' + title, selector: 'table td.st' },
                { name: '榆木林', link: 'http://www.yumuli.com/cili/s/' + title, selector: `h2.search-title a[title*='${title}']` },
            ]
        });
        if (has_imdb) {
            site_map.push({
                name: "BT国外网站",
                label: [
                    { name: '1337X', link: 'https://1337x.to/search/' + ywm + '/1/', selector: 'table.table-list.table.table-responsive.table-striped td.coll-1.name' },
                    { name: 'iDope', link: 'https://idope.se/torrent-list/' + ywm, selector: '#div2child div.resultdiv' },
                    { name: 'ISOHunt', link: 'https://isohunt2.net/torrent/?ihq=' + ywm, selector: '#serps td.title-row' },
                    { name: 'KickAss', link: 'https://katcr.co/katsearch/page/1/' + ywm, selector: 'div.table--responsive_vertical div.torrents_table__torrent_name' },
                    { name: 'Lime', link: 'https://www.limetorrents.info/search/all/' + ywm, selector: 'table.table2 div.tt-name' },
                    { name: 'Monova', link: 'https://monova.org/search?term=' + eng_title, selector: 'table.bordered.main-table td.torrent_name' },
                    { name: 'RARBG', link: 'http://rarbg.is/torrents.php?search=' + imdb_id, selector: 'table.lista2t tr.lista2' },
                    { name: 'TorLock', link: 'https://www.torlock2.com/all/torrents/' + ywm.replace(/ /g, "-") + '.html', selector: 'table.table.table-striped.table-bordered.table-hover.table-condensed td.td' },
                    { name: 'WorldWide', link: 'https://worldwidetorrents.me/torrents-search.php?search=' + ywm, selector: 'div.w3-responsive td.w3-jose' },
                    { name: 'YTS', link: 'https://yts.am/browse-movies/' + eng_title, selector: 'div.row div.browse-movie-bottom' },
                    { name: 'Zooqle', link: 'https://zooqle.com/search?q=' + ywm, selector: 'div.panel-body a.small' },
                    { name: '海盗湾', link: 'https://thepiratebay.org/search/' + ywm, selector: '#searchResult div.detName' },
                ]
            });
        }
        site_map.push({
            name: "影视网盘搜索",
            label: [
                { name: '56网盘影', link: 'http://www.56wangpan.com/search/o2kw' + title, selector: `div.title > a[title*='${title}']` },
                { name: 'Kikibt影', method: "post", link: 'http://kikibt.cc/', data: `keyword=${title}`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: 'div.list-area dl.item' },
                { name: '盘多多影视', link: 'http://www.panduoduo.net/s/comb/n-' + title + '&f-f4', selector: `h3 > a[title*='${title}']` },
                { name: '小白盘影视', link: 'http://www.xiaobaipan.com/list-p0-' + title + '.html?order=size', selector: 'h4.job-title a' },
                // { name: '茶杯狐', method: "post", type: "json", link: 'https://www.cupfox.com/?type=video&key=' + title, ajax: "https://www.cupfox.com/search", data: `search_type=video&key=${title}`, csrf: { name: "_xsrf", update: "data" },headers: {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}, selector: 'title.length > 0' },
            ]
        });
    } else if (location.host === "book.douban.com") {
        let title = $('#wrapper > h1 > span')[0].textContent.replace(/[:\(].*$/, "");
        let original_anchor = $('#info span.pl:contains("原作名: ")');
        let original = original_anchor[0] ? fetch_anchor(original_anchor) : '';
        let title_eng = title.match(/([a-zA-Z :,\(\)])+/);
        let original_eng = original.match(/([a-zA-Z :,\(\)])+/);
        let ywm = "";
        if (title_eng) {
            ywm = title;
        } else if (original_eng) {
            ywm = original.replace(/[:\(].*$/, "");
        }
        let has_ywm = title_eng + original_eng;
        let stitle = ywm.toLowerCase().replace(/ /g, "-");
        let writer_anchor = $('#info span.pl:contains("作者: ")');
        let writer = writer_anchor[0] ? ' ' + fetch_anchor(writer_anchor).replace(/\[[^\]]+\]/g, '').replace(/（[^）]+）/g, '').replace(/^\s{1,}/g, '') : ' ';
        let gtitle = _encodeToGb2312(title, true);
        let ptitle = encodeURI(title).replace(/%/g, "%25");
        let isbn_anchor = $('#info span.pl:contains("ISBN")');
        let isbn = isbn_anchor[0] ? fetch_anchor(isbn_anchor) : '';

        if (_version === "完整版") {
            site_map.push({
                name: "图书会员网站",
                label: [
                    { name: "Kindle178", link: "http://www.kindle178.com/search.aspx?book=" + title, selector: "div.search-list div.book" },
                    { name: "Kindle88", link: "http://www.kindle88.com/?s=" + title + writer, selector: "div.widget-content li.archive-thumb" },
                    { name: 'iamtxt', method: "post", link: 'http://www.iamtxt.com/e/search/index.php', data: `keyboard=${title}&show=title&tempid=2`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: 'div.row div.title' },
                    { name: "mLook", link: "http://plugin.mlook.mobi/search?q=" + title, selector: "div.books div.fl.meta" },
                    { name: "Readfree", link: "http://readfree.me/search/?q=" + douban_id, selector: "#container li.book-item" },
                    { name: "So-Kindle", link: "https://www.so-kindle.com/q?type=1&keyword=" + title, selector: "div.col-md-12 a.book-tip" },
                    { name: "Vol.moe", link: "https://vol.moe/list.php?s=" + title.replace(/\d+$/, ''), selector: "table.book_list img.img_book" },
                    { name: "拜读", link: "http://orzbook.com/?s=" + title + writer, selector: "#main li.entry-title" },
                    { name: "必看网", link: "https://www.biikan.com/home/book/search.shtml?k=" + title, selector: "div.bookList.clearfix a.bookListImg" },
                    { name: "缤闹", method: "post", link: "http://www.binnao.com/search.php?mod=forum", data: `srchtxt=${title}${writer}&searchsubmit=yes`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: "#threadlist li.pbw" },
                    { name: "点书网", method: "post", link: "http://dianbook.cc/search.php?mod=forum", data: `srchtxt=${title}${writer}&searchsubmit=yes`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: "div.tl li.pbw" },
                    { name: "集思会", link: "http://kindlepush.com/search/?sKey=%22" + title + "%22", selector: "div.m-search.j-area a.title" },
                    { name: "万千合集站", link: "http://www.hejizhan.com/bbs/?kw=" + title, selector: "ul.tpt-list h2.tpt-tip" },
                    { name: "我的书屋", method: "post", link: "http://www.wode5.com/e/search/index.php", data: `tbname=book&tempid=1&show=title%2Csoftwriter%2Csoftsay&ecmsfrom=9&keyboard=${title}&submit=`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: "div.am-u-sm-9.search-content div.item_info.am-fl", selector_need_login: "div[align='center'] > b:contains('权限')" },
                    { name: "易读", link: "http://www.yidukindle.com/ebook.php?search=" + title, selector: "div.col-lg-12 strong" },
                    { name: "走读派", link: "http://www.zoudupai.com/book/share?kw=" + title, selector: "#content p.contentsms" },
                ]
            });
        }
        site_map.push({
            name: "图书在线试读",
            label: [
                { name: '豆瓣阅读', link: 'https://read.douban.com/search?q=' + title + writer, selector: 'article.col li.item.store-item' },
                { name: '多看阅读', link: `http://www.duokan.com/search/${title}${writer}`, selector: `div.wrap > a:contains(${title}) ~ div.u-author > span:contains(${writer.trim()})` },
                { name: '京东数字', link: `https://s-e.jd.com/Search?enc=utf-8&key=${title}${writer}`, selector: `div.p-name > a[title='${title}']` },
                { name: '亚马逊商店', link: 'https://www.amazon.cn/s/?url=search-alias%3Ddigital-text&field-keywords=' + title + writer, selector: '#centerMinus div.a-fixed-left-grid' },
            ]
        });
        site_map.push({
            name: "图书精准匹配",
            label: [
                { name: 'B-OK', link: 'http://b-ok.xyz/s/?e=1&q=' + isbn, selector: `#searchResultBox h3.color1:contains(${title})` },
                { name: "EBH", link: "http://ebookhunter.ch/search/?keyword=" + isbn, selector: "#mains_left div.index_box_title.list_title" },
                { name: "LibGen", link: "http://gen.lib.rus.ec/search.php?column=title&req=" + isbn, selector: "table[rules='rows'] td[width='500']" },
            ]
        });
        site_map.push({
            name: "图书免费网站",
            label: [
                { name: 'Bookset', link: 'https://bookset.me/search/' + title + writer, selector: `h3 > a[title='${title}']` },
                { name: "ePUBee", method: "post", type: "json", link: "http://cn.epubee.com/books/?s=" + title, ajax: "http://cn.epubee.com/keys/get_ebook_list_search.asmx/getSearchList", data: `{skey:'${title}'}`, headers: { "Content-Type": "application/json; charset=UTF-8" }, selector: "d.length > 0" },
                { name: 'N资源', method: "post", link: 'http://www.nziyuan.com/e/search/index.php', data: `keyboard=${gtitle}&show=title&tempid=1&tbname=download`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: 'table.box h2.r' },
                { name: 'SaltTiger', link: 'https://salttiger.com/?s=' + title, selector: `h1.entry-title > a:contains(${title})` },
                { name: 'SoBooks', link: 'https://sobooks.cc/search/' + title + writer, selector: `h3 > a[title*='${title}']` },
                { name: 'XZPC图书', method: "post", link: 'http://www.xzpc6.com/#search_' + title, ajax: 'http://www.xzpc6.com/sou.php', data: `key=${title}`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, selector: 'p a' },
                { name: '读书小站', link: 'http://ibooks.org.cn/?s=下载 ' + title + writer, selector: '#main h2.entry-title' },
                { name: '高清PDF', link: 'https://hdpdf.blog/?s=' + title, selector: '#main h1.entry-title' },
                { name: "苦瓜书盘", method: "post", link: "https://kgbook.com/e/search/index.php", data: `keyboard=${title}&show=title%2Cbooksay%2Cbookwriter&tbname=download&tempid=1&submit=%E6%90%9C%E7%B4%A2`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: "div.small-12.columns span.text" },
                { name: '内酷网', link: 'http://neikuw.com/?s=' + title, selector: 'div.content p.note' },
                { name: '书语者', link: 'https://www.shuyuzhe.com/?s=' + title + writer, selector: `h2.entry-title > a:contains(${title})` },
                { name: '我的小书屋', link: 'http://mebook.cc/?s=' + title + writer, selector: '#primary div.content' },
                { name: '小浣熊图书', link: `https://www.xiaohx.org/search?cat=9&key=${title}`, selector: `div.result_p a[title*='${title}']` },
                { name: '醒客读书', link: 'http://www.xkreading.com/?s=' + title + writer, selector: '#content h3.entry-title' },
                { name: '雅书', link: 'https://www.yabook.org/search.php?q=' + title, selector: 'div.main div.postinfo' },
                { name: '云海图书馆', link: 'http://www.pdfbook.cn/?s=' + title, selector: '#main a.out' },
                { name: '子乌书简', link: 'http://book.zi5.me/?s=' + title, selector: `div.thumb-holder div.thumbtitle:contains(${title})` },
                { name: '周读', link: 'http://www.ireadweek.com/index.php/Index/bookList.html?keyword=' + title, selector: 'ul.hanghang-list a' },
            ]
        });
        if (has_ywm) {
            site_map.push({
                name: "图书国外网站",
                label: [
                    { name: 'BookFl', link: 'http://en.bookfi.net/s/?e=1&q=' + ywm, selector: `#searchResultBox h3.color1:contains(${title})` },
                    { name: 'Booksee', link: 'http://en.booksee.org/s/?e=1&q=' + ywm, selector: `#searchResultBox h3.color1:contains(${title})` },
                    { name: 'Ebookee', link: 'https://ebookee.org/search.php?q=' + ywm, selector: `#booklist li:contains(${title})` },
                    { name: 'PDFDrive', link: 'https://www.pdfdrive.net/search?q=' + ywm, selector: `div.file-right a[href*='${stitle}']` },
                ]
            });
        }
        site_map.push({
            name: "图书搜索引擎",
            label: [
                { name: '56网盘书', link: 'http://www.56wangpan.com/search/o2kw' + title, selector: `div.title > a[title*='${title}']` },
                { name: 'Kikibt书', method: "post", link: 'http://kikibt.cc/', data: `keyword=${title}`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: 'div.list-area dl.item' },
                { name: 'Kindleshare', link: 'https://sk.kindleshare.cn/?submit=Search&name=' + title, selector: '#jieguo a.button' },
                { name: '爱问资料', link: `http://ishare.iask.sina.com.cn/search/0-0-all-1-default?cond=${ptitle}`, selector: `p.text.cf > a.fl.fl-title[title*='${title}']` },
                { name: '盘多多图书', link: 'http://www.panduoduo.net/s/comb/n-' + title + '&f-f2', selector: `h3 > a[title*='${title}']` },
                { name: '盘搜搜微盘', link: 'http://www.pansoso.com/vdisk/' + title, selector: `a > em:contains(${title})` },
                { name: '书语者搜书', link: 'https://book.shuyuzhe.com/search/' + title, selector: 'table.table.table-hover b' },
                { name: '小白盘图书', link: 'http://www.xiaobaipan.com/list-p0-' + title + '.html?order=size', selector: 'h4.job-title a' },
            ]
        });
        site_map.push({
            name: "有声在线试听",
            label: [
                { name: '懒人听书', link: 'http://www.lrts.me/search/book/' + title, selector: 'ul li.book-item' },
                { name: '我听评书', link: 'http://www.psttt.com/so.asp?keyword=' + gtitle, selector: 'div.toolbox li' },
                { name: '评书吧', link: 'http://www.pingshu8.com/search/1.asp?keyword=' + gtitle, selector: "table.TableLine div[align='left']" },
                { name: '天方听书网', link: 'http://www.tingbook.com/Book/SearchResult.aspx?keyword=' + title, selector: 'ul.search_result_list h4.clearfix' },
                { name: '听中国', link: 'http://www.tingchina.com/search1.asp?mainlei=0&lei=0&keyword=' + gtitle, selector: 'dl.singerlist1 li' },
                { name: '喜马有声', link: 'https://www.ximalaya.com/search/' + title + '/', selector: `div.xm-album-cover__wrapper + a[title*='${title}']` },
                { name: '有声听书吧', link: 'http://www.ysts8.com/Ys_so.asp?stype=1&keyword=' + gtitle, selector: 'div.toolbox li' },
            ]
        });
        site_map.push({
            name: "图书有声网站",
            label: [
                { name: 'ABB', link: 'http://audiobookbay.nl/?s=' + title, selector: '#content div.postTitle' },
                { name: '趣听书', link: 'http://qutingshu.com/?s=' + title, selector: 'ul.books-list li' },
                { name: '小浣熊有声', link: `https://www.xiaohx.org/search?cat=5&key=${title}`, selector: `div.result_p a[title*='${title}']` },
            ]
        });
    } else if (location.host === "music.douban.com") {
        // 页面元素定位
        let album_anchor = $('#info span.pl:contains("专辑类型")');  //专辑类型
        let medium_anchor = $('#info span.pl:contains("介质")');  //介质
        let album = album_anchor[0] ? fetch_anchor(album_anchor) : '';
        let is_single = album.match(/单曲/);
        let title = $('#wrapper > h1 > span')[0].textContent.split(' ').shift().replace(/[，]/g, " ").replace(/：.*$/, "");
        let gtitle = _encodeToGb2312(title, true);
        let ptitle = encodeURI(title).replace(/%/g, "%25");
        let singer = ' ' + $('#info > span > span.pl > a')[0].textContent;
        let gsinger = _encodeToGb2312(singer, true);
        if (_version === "完整版") {
            site_map.push({
                name: "PT音乐顶配",
                label: [
                    { name: "CHDBits♬", link: 'https://chdbits.co/torrents.php?cat406=1&cat408=1&incldead=1&search_area=1&notnewword=1&search=' + title + singer, },
                    { name: "CMCT♬", link: "https://hdcmct.org/torrents.php?cat508=1&incldead=1&search_area=1&notnewword=1&search=" + title + singer, },
                    { name: "HDChina♬", link: 'https://hdchina.org/torrents.php?cat408=1&incldead=1&search_area=1&notnewword=1&search=' + title + singer, selector: "table.torrent_list:last > tbody > tr:gt(0)" },
                    { name: "HDSky♬", link: 'https://hdsky.me/torrents.php?cat408=1&incldead=1&search_area=1&notnewword=1&search=' + title + singer, },
                    { name: "MTeam♬", link: 'https://tp.m-team.cc/torrents.php?cat408=1&cat434=1&incldead=1&search_area=1&notnewword=1&search=' + title + singer, },
                    { name: "OpenCD♬", link: 'https://open.cd/torrents.php?incldead=1&search_area=0&notnewword=1&search=' + title + singer, selector: "table.torrents:last > tbody > tr:gt(0)" },
                    { name: "OurBits♬", link: 'https://ourbits.club/torrents.php?cat=416&incldead=1&search_area=1&notnewword=1&search=' + title + singer, },
                    { name: "TTG♬", link: 'https://totheglory.im/browse.php?c=M&notnewword=1&search_field=分类%3A%60无损音乐FLAC%26APE%60+分类%3A%60%28电影原声%26Game%29OST%60 ' + title + singer, selector: "table#torrent_table:last > tbody > tr:gt(0)" },
                    { name: "U2♬", link: 'https://u2.dmhy.org/torrents.php?cat30=1&incldead=1&search_area=0&notnewword=1&search=' + title.split(' ')[0], },
                ]
            });
            site_map.push({
                name: "PT音乐标配",
                label: [
                    { name: "AIPT♬", link: 'http://pt.aipt123.org/table_list.php?search_area=1&notnewword=1&search=' + title + singer, },
                    { name: "HDCity♬", link: 'https://hdcity.city/pt?cat408=1&incldead=1&search_area=1&notnewword=1&iwannaseethis=' + title + singer, selector: "center > div > div > div.text" },
                    { name: "HDHome♬", link: 'https://hdhome.org/torrents.php?cat439=1&cat440=1&incldead=1&search_area=1&notnewword=1&search=' + title + singer, },
                    { name: "HDTime♬", link: 'https://hdtime.org/torrents.php?cat=408&incldead=1&search_area=1&notnewword=1&search=' + title + singer, },
                    { name: "Hyperay♬", link: 'https://hyperay.org/torrents.php?cat411=1&incldead=1&search_area=1&notnewword=1&search=' + title + singer, selector: "table.torrents > tbody > tr.nonstick_outer_bg" },
                    { name: "JoyHD♬", link: 'https://www.joyhd.net/torrents.php?cat=414&incldead=1&search_area=1&notnewword=1&search=' + title + singer, },
                ]
            });
            site_map.push({
                name: "PT音乐教育",
                label: [
                    { name: "BYRBT♬", link: 'https://bt.byr.cn/torrents.php?cat=402&incldead=1&search_area=1&notnewword=1&search=' + title + singer, },
                    { name: "NPUBITS♬", link: 'https://npupt.com/torrents.php?cat=414&incldead=1&search_area=1&notnewword=1&search=' + title + singer, selector: "#torrents_table > tbody > tr:gt(0)" },
                    { name: "NYPT♬", link: 'https://nanyangpt.com/torrents.php?cat407=1&incldead=1&search_area=1&notnewword=1&search=' + title + singer, selector: "table.torrents:last > tbody > tr" },
                    { name: "SJTU♬", link: 'https://pt.sjtu.edu.cn/torrents.php?cat420=1&cat421=1&cat422=1&cat423=1&cat425=1&cat426=1&incldead=1&search_area=1&notnewword=1&search=' + title + singer, selector: "table.torrents:last > tbody > tr" },
                    { name: "WHUPT♬", link: 'https://whu.pt/torrents.php?incldead=1&search_area=1&notnewword=1&search=' + title + singer, selector: "table.torrents:last > tbody > tr" },
                    { name: "ZX♬", link: 'http://pt.zhixing.bjtu.edu.cn/search/music/x' + title + singer + '-notnewword=1/', selector: "table.torrenttable > tbody > tr:gt(1)" },
                ]
            });
            site_map.push({
                name: "音乐论坛资源",
                label: [
                    { name: "捌零音乐", link: 'http://zhannei.baidu.com/cse/search?s=7126057724754327244&entry=1&q=' + title + singer, selector: "#results h3.c-title" },
                    { name: "乐赏音乐", link: 'https://www.gscq.me/search.htm?keyword=' + title, selector: 'div.media-body div.subject.break-all' },
                    { name: "磨坊", method: "post", link: "http://www.moofeel.com/search.php?mod=forum", data: `srchtxt=${gtitle}${gsinger}&searchsubmit=yes`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: "div.tl li.pbw" },
                    { name: "无损音乐网", link: 'https://www.so.com/s?q=site%3Awusunyinyue.cn+intitle:' + title + '%26%26' + singer.trim(), selector: 'ul.result li.res-list' },
                    { name: "炫音音乐", link: `http://so.musicool.cn/cse/search?s=10523158750213826925&q=${title}${singer}`, selector: "#results h3.c-title" },
                ]
            });
        }
        site_map.push({
            name: "在线音乐播放",
            label: [
                { name: 'QQ音乐', link: 'https://y.qq.com/portal/search.html#page=1&searchid=1&remoteplace=txt.yqq.top&t=album&w=' + title + singer, ajax: "https://c.y.qq.com/soso/fcgi-bin/client_search_cp?t=8&format=json&w=" + title + singer, type: "json", selector: 'data.album.totalnum > 0' },
                { name: '百度音乐', link: 'http://music.baidu.com/search/album?key=' + title + singer, selector: '#album_list div.album-info' },
                { name: '酷我音乐', link: 'http://sou.kuwo.cn/ws/NSearch?type=album&key=' + title + singer, selector: 'div.album p.musicName' },
                { name: '咪咕音乐', link: `http://music.migu.cn/v2/search?type=album&keyword=${title}${singer}`, selector: `div.album-name font:contains(${title})` },
                { name: '虾米音乐', link: `https://www.xiami.com/search/album/?key=${title}${singer}`, selector: `p.name > a[title='${title}'] + a[title='${singer.trim()}']` },
                { name: '网易云音乐', link: 'https://music.163.com/#/search/m/?type=10&s=' + title + singer, ajax: "https://api.imjad.cn/cloudmusic/?type=search&s=" + title + singer, type: "json", selector: 'result.songCount > 0' },
            ]
        });
        if (is_single) {
            site_map.push({
                name: "单曲无损网站",
                label: [
                    { name: '51Ape', link: 'https://www.bing.com/search?q=site%3Awww.51ape.com+intitle%3A' + title + '+intitle%3A' + singer, selector: '#b_content div.b_caption' },
                    { name: '刘明野QQ', method: "post", type: "json", link: 'https://tool.liumingye.cn/qqws/?name=' + title + singer, ajax: "https://tool.liumingye.cn/qqws/ajax.php", data: `text=${title}+${singer}&page=1`, headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", "X-Requested-With": "XMLHttpRequest" }, selector: "code > 0" },
                    { name: '搜你妹QQ', method: "post", type: "json", link: 'http://music.sonimei.cn/?type=qq&name=' + title + singer, ajax: "http://music.sonimei.cn/", data: `input=${title}+${singer}&filter=name&type=qq&page=1`, headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", "X-Requested-With": "XMLHttpRequest" }, selector: "data.length > 0" },
                    { name: '搜你妹百度', method: "post", type: "json", link: 'http://music.sonimei.cn/?type=baidu&name=' + title + singer, ajax: "http://music.sonimei.cn/", data: `input=${title}+${singer}&filter=name&type=baidu&page=1`, headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", "X-Requested-With": "XMLHttpRequest" }, selector: "data.length > 0" },
                    { name: '搜你妹酷狗', method: "post", type: "json", link: 'http://music.sonimei.cn/?type=kugou&name=' + title + singer, ajax: "http://music.sonimei.cn/", data: `input=${title}+${singer}&filter=name&type=kugou&page=1`, headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", "X-Requested-With": "XMLHttpRequest" }, selector: "data.length > 0" },
                    { name: '搜你妹酷我', method: "post", type: "json", link: 'http://music.sonimei.cn/?type=kuwo&name=' + title + singer, ajax: "http://music.sonimei.cn/", data: `input=${title}+${singer}&filter=name&type=kuwo&page=1`, headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", "X-Requested-With": "XMLHttpRequest" }, selector: "data.length > 0" },
                    { name: '搜你妹咪咕', method: "post", type: "json", link: 'http://music.sonimei.cn/?type=migu&name=' + title + singer, ajax: "http://music.sonimei.cn/", data: `input=${title}+${singer}&filter=name&type=migu&page=1`, headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", "X-Requested-With": "XMLHttpRequest" }, selector: "data.length > 0" },
                    { name: '搜你妹蜻蜓', method: "post", type: "json", link: 'http://music.sonimei.cn/?type=qingting&name=' + title + singer, ajax: "http://music.sonimei.cn/", data: `input=${title}+${singer}&filter=name&type=qingting&page=1`, headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", "X-Requested-With": "XMLHttpRequest" }, selector: "data.length > 0" },
                    { name: '搜你妹网易', method: "post", type: "json", link: 'http://music.sonimei.cn/?type=netease&name=' + title + singer, ajax: "http://music.sonimei.cn/", data: `input=${title}+${singer}&filter=name&type=netease&page=1`, headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", "X-Requested-With": "XMLHttpRequest" }, selector: "data.length > 0" },
                    { name: '搜你妹喜马', method: "post", type: "json", link: 'http://music.sonimei.cn/?type=ximalaya&name=' + title + singer, ajax: "http://music.sonimei.cn/", data: `input=${title}+${singer}&filter=name&type=ximalaya&page=1`, headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", "X-Requested-With": "XMLHttpRequest" }, selector: "data.length > 0" },
                    { name: '搜你妹一听', method: "post", type: "json", link: 'http://music.sonimei.cn/?type=1ting&name=' + title + singer, ajax: "http://music.sonimei.cn/", data: `input=${title}+${singer}&filter=name&type=1ting&page=1`, headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", "X-Requested-With": "XMLHttpRequest" }, selector: "data.length > 0" },
                    { name: '自由音QQ', link: 'https://www.tikitiki.cn/search.do?page=1&type=1&keyword=' + title + singer, selector: 'div.mdui-panel-item div.mdui-panel-item-header' },
                    { name: '自由音网易', link: 'https://www.tikitiki.cn/search.do?page=1&type=2&keyword=' + title + singer, selector: 'div.mdui-panel-item div.mdui-panel-item-header' },
                    { name: '自由音酷狗', link: 'https://www.tikitiki.cn/search.do?page=1&type=3&keyword=' + title + singer, selector: 'div.mdui-panel-item div.mdui-panel-item-header' },
                ]
            });
        }
        site_map.push({
            name: "音乐免费网站",
            label: [
                { name: "CHINAV音", link: 'http://www.159937.com/search-index-fid-4-orderby-timedesc-daterange-0-keyword-' + title + '.htm', selector: "#threadlist table.thread" },
                { name: 'DTShot', link: 'http://www.dtshot.com/search/' + title + singer + '/', selector: `div.case_info div.meta-title:contains(${title})` },
                { name: 'XiCXi', method: "post", link: 'http://www.xicxi.com/search.php?mod=forum', data: `srchtxt=${title}${singer}&searchsubmit=yes`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: '#ct li.pbw' },
                { name: 'XZPC音乐', method: "post", link: 'http://www.xzpc6.com/#search_' + title, ajax: 'http://www.xzpc6.com/sou.php', data: `key=${title}`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, selector: 'p a' },
                { name: '爱无损', link: 'http://www.lovewusun.com/?s=' + title + singer, selector: '#main h2.entry-title' },
                { name: '小浣熊音乐', link: `https://www.xiaohx.org/search?cat=5&key=${title}${singer}`, selector: `div.result_p a[title*='${title}']` },
            ]
        });
        site_map.push({
            name: "音乐国内网盘",
            label: [
                { name: '56网盘音', link: 'http://www.56wangpan.com/search/o2kw' + title + singer, selector: `div.title > a[title*='${title}']` },
                { name: 'Kikibt音', method: "post", link: 'http://kikibt.cc/', data: `keyword=${title}${singer}`, headers: { "Content-Type": "application/x-www-form-urlencoded" }, rewrite_href: true, selector: 'div.list-area dl.item' },
                { name: '磁力猫音乐', link: 'http://www.cilimao.me/search?sortProperties=content_size&resourceType=6&word=' + title + singer, selector: '#Search__container___UVm4k a.Search__result_title___24kb_' },
                { name: '盘多多音乐', link: 'http://www.panduoduo.net/s/comb/n-' + title + singer + '&f-f13', selector: `h3 > a[title*='${singer.trim()}']` },
                { name: '小白盘音乐', link: 'http://www.xiaobaipan.com/list-p0-' + title + '.html?order=size', selector: 'h4.job-title a' },
            ]
        });
        site_map.push({
            name: "音乐国外网盘",
            label: [
                { name: 'AvaxHome♬', link: 'https://rapu.rocks/search/?category_slug=music&query=' + title + singer, selector: 'div.col-xs-12.col-sm-8.col-md-8.col-lg-8 div.panel-heading' },
            ]
        });
    }

    function Exist_check(label) {
        let site = label.name;
        let psite = $(`a[data-name="${site}"]`);

        function TagExist(link) {
            $(psite).css("background-color", GM_getValue("tag_bcolor_exist", "#e3f1ed"));
            $(psite).css("color", GM_getValue("tag_fcolor_exist", "#3377aa"));
            $(psite).attr("title", "资源存在");
            let storage_data = true;
            if (label.rewrite_href && label.rewrite_href === true) {   // 重写链接
                storage_data = GM_getCacheValue(`${douban_id}_${site}`, link || $(psite).attr("href"));
                $(psite).attr("href", storage_data);
            }
            GM_setCacheValue(`${douban_id}_${site}`, storage_data, 86400 * 7 * 1e3);
        }

        function TagNotExist() {
            $(psite).css("background-color", GM_getValue("tag_bcolor_not_exist", "#f4eac2"));
            $(psite).css("color", GM_getValue("tag_fcolor_not_exist", "#3377aa"));
            $(psite).attr("title", "资源不存在");
        }

        function TagNeedLogin() {
            $(psite).css("background-color", GM_getValue("tag_bcolor_need_login", ""));
            $(psite).css("color", GM_getValue("tag_fcolor_need_login", "#3377aa"));
            GM_setCacheValue(`need_login_${site}`, true, 86400 * 1e3);
            $(psite).click(function () {
                GM_deletedCacheValue(`need_login_${site}`);
            });
            $(psite).attr("title", "站点需要登陆");
        }

        function TagError() {
            $(psite).css("background-color", GM_getValue("tag_bcolor_error", ""));
            $(psite).css("color", GM_getValue("tag_fcolor_error", "#3377aa"));
            $(psite).attr("title", "遇到问题");
        }


        function login_check (res) {
            let need_login = false;
            if (/login|verify|checkpoint|returnto/ig.test(res.finalUrl)) {
                need_login = true;  // 检查最终的URL看是不是需要登陆
            } else if (/refresh: \d+; url=.+login.+/ig.test(res.responseHeaders)) {
                need_login = true;  // 检查responseHeader有没有重定向
            } else {
                let responseText = res.responseText;
                if (typeof responseText === "undefined") {
                    need_login = true;  // 检查最终的Text，如果什么都没有也可能说明需要登陆
                } else if (responseText.length < 800 && /login|not authorized/.test(responseText)) {
                    need_login = true;  // 对Text进行检查，断言“过短，且中间出现login字段”即说明可能需要登陆
                }
            }
            if (need_login) {
                TagNeedLogin();
            }
            return need_login;
        }

        function check_core (label) {
            GM_xmlhttpRequest({
                method: label.method || "GET",
                url: label.ajax || label.link,
                data: label.data,
                headers: label.headers,
                onload: function (res) {
                    if (!login_check(res)) {
                        try {// 开始解析返回信息
                            TagNotExist();  // 先断言不存在
                            let responseText = res.responseText;
                            if (label.type && ["json", "jsonp"].includes(label.type)) { // 如果前面定义了返回类型是"json'或者"jsonp"
                                if (label.type === "jsonp") {
                                    responseText = responseText.match(/[^(]+\((.+)\)/)[1];
                                }
                                let par = JSON.parse(responseText);
                                if (eval("par." + label.selector)) {
                                    TagExist();
                                }
                            } else {  // 否则默认label.type的默认值为 html
                                let doc = (new DOMParser()).parseFromString(res.responseText, 'text/html');
                                let body = doc.querySelector("body");
                                // 因为jQuery的选择器丰富，故这里不用 dom.querySelector() 而用 jQuery.find()
                                if (label.selector_need_login && $(body).find(label.selector_need_login).length) {
                                    TagNeedLogin(); // 如果存在selector_need_login选择器，则先判断是否存在以确定是否需要登录
                                } else if ($(body).find(label.selector || "table.torrents:last > tbody > tr:gt(0)").length) {
                                    TagExist(res.finalUrl);  // 最后使用selector选择器判断资源是否存在
                                }
                            }
                        } catch (e) {
                            TagError();
                        }
                    }
                },
                onerror: function () {
                    TagError();
                }
            });
        }


        // 这里假定有这个资源的就一直都有，直接使用第一次请求成功的时候缓存信息
        if (GM_getCacheValue(`${douban_id}_${site}`)) {
            TagExist();
            return;
        }

        // 如果前次检查到这个站点需要登陆
        if (GM_getCacheValue(`need_login_${site}`)) {
            TagNeedLogin();
            return;
        }


         //if (typeof label.data === "object") {
        //    let myData = new FormData();
        //    for (let k in label.data) {
        //        myData.append(k,label.data.k);
        //    }
        //    label.data = myData;
        //}

        // 不然，则请求相关信息
        $(psite).attr("title", "正在请求信息中");
        if (label.csrf) {  // 对某些启用了csrf的站点，先使用正常方式请求一次获取csrf值
            GM_xmlhttpRequest({
                method: "GET",
                url: label.link,
                onload: function (res) {
                    if (!login_check(res)) {
                        try {
                            let doc = (new DOMParser()).parseFromString(res.responseText, 'text/html');
                            let csrf_ = $(`input[name='${label.csrf.name}'`, doc);
                            let csrf_key = csrf_.attr("value");  // 获取csrf值
                            label[label.csrf.update] += `&${label.csrf.name}=${csrf_key}`;   // 更新对应选项
                            check_core(label);
                        }  catch (e) {
                            TagError();
                        }
                    }
                },
                onerror: function () {
                    TagError();
                }
            });
        } else {
            check_core(label);
        }
    }

    function site_exist_status() {
        for (let i = 0; i < site_map.length; i++) {
            let map_dic = site_map[i];
            if (GM_getValue(delete_site_prefix + map_dic.name, false)) {
                continue;
            }
            $('#adv-sites').append(`<div class="c-aside name-offline" data-id="${i}"><h2><i>${map_dic.name}</i>· · · · · ·</h2><div class=c-aside-body style="padding: 0 12px;"> <ul class=bs > </ul> </div> </div>`);

            let in_site_html = $(`div[data-id='${i}'] ul.bs`);
            for (let j = 0; j < map_dic.label.length; j++) {
                let label = map_dic.label[j];
                if (GM_getValue(delete_site_prefix + label.name, false)) {
                    continue;
                }
                in_site_html.append(`<a href="${label.link}" data-name="${label.name}" target="_blank" rel="nofollow" class="name-offline">${label.name}</a>`);
                Exist_check(label);
            }
        }
    }
    site_exist_status();

    // 脚本设置
    $("#db-global-nav > div > div.top-nav-info").append(`<a href="javascript:;" id="drdm_setting_btn">脚本设置</a>`);
    $("#drdm_setting_btn").click(function () {
        let int_html = `<div id='drdm_setting'><h2>脚本设置界面正在开发中，请等待完善......</h2></div>`;
        let int_css = "div#drdm_setting input[type=checkbox]{display:none}div#drdm_setting input[type=checkbox]+label{display:inline-block;width:40px;height:20px;position:relative;transition:.3s;margin:0 20px;box-sizing:border-box;background:#ddd;border-radius:20px;box-shadow:1px 1px 3px #aaa}div#drdm_setting input[type=checkbox]+label:after,div#drdm_setting input[type=checkbox]+label:before{content:'';display:block;position:absolute;left:0;top:0;width:20px;height:20px;transition:.3s;cursor:pointer}div#drdm_setting input[type=checkbox]+label:after{background:#fff;border-radius:50%;box-shadow:1px 1px 3px #aaa}div#drdm_setting input[type=checkbox]:checked+label{background:#aedcae}div#drdm_setting input[type=checkbox]:checked+label:after{background:#5cb85c;left:calc(100% - 20px)}";
        wrapper_change("drdm_setting", int_html, int_css, function () {
            // TODO 评分信息，豆列搜索等杂项功能启用情况

            // 构造站点启用信息
            let setting_site = "<h1>搜索站点启用情况(在当前页面条件下)</h1>";
            for (let i = 0; i < site_map.length; i++) {
                let map_dic = site_map[i];
                setting_site += `<div><h2>${map_dic.name} <input type="checkbox" id="${'config_site_' + map_dic.name}" ${GM_getValue(delete_site_prefix + map_dic.name, false) ? '' : 'checked'} data-config="${delete_site_prefix + map_dic.name}" data-par="${map_dic.name}" data-type="map"><label for="${'config_site_' + map_dic.name}"></label></h2><table><tbody><tr>`;
                for (let j = 0; j < map_dic.label.length; j++) {
                    let label = map_dic.label[j];
                    setting_site += `<td style="text-align:right;"><span>${label.name}</span><input type="checkbox" id="${'config_site_' + label.name}" ${GM_getValue(delete_site_prefix + map_dic.name, false) || GM_getValue(delete_site_prefix + label.name, false) ? '' : 'checked'} ${GM_getValue(delete_site_prefix + map_dic.name, false) ? 'disabled' : ''} data-config="${delete_site_prefix + label.name}" data-par="${map_dic.name}" data-type="site"><label for="${'config_site_' + label.name}"></label></td>`;
                    if ((j + 1) % 7 === 0) {
                        setting_site += '</tr><tr>';
                    }
                }
                setting_site += "</tbody></table></div><hr>";
            }
            $("#drdm_setting").append(setting_site);
            $("input[id^='config_site_']").click(function () {
                let that = $(this);
                GM_setValue(that.attr("data-config"), !that.prop("checked"));
                if (that.attr("data-type") === "map") {
                    let par = that.attr("data-par");
                    $(`input[id^='config_site_'][data-type='site'][data-par=${par}]`).prop("disabled", !that.prop("checked")).prop("checked", that.prop("checked"));
                }
            });
        });
    });
});