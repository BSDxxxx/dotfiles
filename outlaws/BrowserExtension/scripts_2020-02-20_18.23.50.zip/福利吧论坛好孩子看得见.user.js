// ==UserScript==
// @name                福利吧论坛好孩子看得见
// @name:zh-CN          福利吧论坛 - 好孩子看得见
// @name:zh-TW          福利吧論壇 - 好孩子看得見
// @namespace           https://greasyfork.org/zh-CN/users/193133-pana
// @homepage            https://www.sailboatweb.com
// @version             6.16.3
// @description         好孩子才看得见，支持移动端
// @description:zh-CN   好孩子才看得见，论坛小助手
// @description:zh-TW   好孩子才看得見，論壇小助手
// @author              pana
// @include             http*://www.wnflb19.com/*
// @include             http*://www.wnflb66.com/*
// @exclude             http*://*/member.php?mod=register
// @require             https://cdn.bootcss.com/jquery/3.3.1/jquery.min.js
// @require             https://cdn.bootcss.com/crypto-js/3.1.9-1/core.min.js
// @require             https://cdn.bootcss.com/crypto-js/3.1.9-1/enc-base64.min.js
// @require             https://cdnjs.cloudflare.com/ajax/libs/arrive/2.4.1/arrive.min.js
// @connect             keyfc.net
// @connect             search.pandown.cn
// @connect             www.gsi8.com
// @grant               GM_info
// @grant               GM_setClipboard
// @grant               GM_getValue
// @grant               GM_setValue
// @grant               GM_registerMenuCommand
// @grant               GM_xmlhttpRequest
// ==/UserScript==

(function() {
	'use strict';
	const SETTING_VALUE = {
		WRAP_DIV: ['settingWrapDiv', ''],
		MAIN_FIELDSET: ['mainFieldset', ''],
		HEADLINE_LEGEND: ['headlineLegend', ''],
		HEADLINE_LINK: ['headlineLink', '好孩子看得见-设置 ver.' + GM_info.script.version, '脚本详细信息', 'https://greasyfork.org/zh-CN/scripts/381494'],
		TAG_UL: ['tagUl', ''],
		HIGHLIGHT_CHECKBOX: ['highlightCheckbox', '启用热帖高亮功能'],
		AGREE_NUMBER_TEXT: ['agreeNumberText', '--> 分享高亮的阈值: '],
		AGREE_NUMBER_INPUT: ['agreeNumberInput', '(推荐: 20)'],
		AGREE_COLOR_TEXT: ['agreeColorText', '--> 分享高亮的颜色: '],
		AGREE_COLOR_INPUT: ['agreeColorInput', '(推荐: #EE1B2E)'],
		AGREE_COLOR_EG: ['agreeColorEg', '颜色示例'],
		REPLY_NUMBER_TEXT: ['replyNumberText', '--> 回复高亮的阈值: '],
		REPLY_NUMBER_INPUT: ['replyNumberInput', '(推荐: 50)'],
		REPLY_COLOR_TEXT: ['replyColorText', '--> 回复高亮的颜色: '],
		REPLY_COLOR_INPUT: ['replyColorInput', '(推荐: #2B65B7)'],
		REPLY_COLOR_EG: ['replyColorEg', '颜色示例'],
		COPY_CHECKBOX: ['copyCheckbox', '显示复制按钮 (在提取到的链接后)'],
		TEXT_COLOR_TEXT: ['textColorText', '隐藏文字的高亮颜色: '],
		TEXT_COLOR_INPUT: ['textColorInput', '(推荐: #FF33CC)'],
		TEXT_COLOR_EG: ['textColorEg', '颜色示例'],
		LINK_COLOR_TEXT: ['linkColorText', '提取链接的文字颜色: '],
		LINK_COLOR_INPUT: ['linkColorInput', '(推荐: #369)'],
		LINK_COLOR_EG: ['linkColorEg', '颜色示例'],
		SAVE_BUTTON: ['saveButton', '保存', '保存设置'],
		CANCEL_BUTTON: ['cancelButton', '取消', '关闭设置'],
		FLOAT_CHECKBOX: ['floatCheckbox', '启用浮动模式'],
		EXTRACT_CHECKBOX: ['extractCheckbox', '识别并提取文字中的链接 (空心圆标记)'],
		PANDOWNLOAD_CHECKBOX: ['pandownloadCheckbox', '显示跳转到 PanDownload 网页版的按钮'],
		QUERY_CHECKBOX: ['queryCheckbox', '显示查询百度网盘提取码的按钮'],
		CODE_CHECKBOX: ['codeCheckbox', '显示编码解码工具图标'],
		BT_CHECKBOX: ['btCheckbox', '显示磁力链接搜索工具图标'],
		CLICK_CHECKBOX: ['clickCheckbox', '自动点击张国立'],
	};
	const TOOL_VALUE = {
		WRAP_DIV: ['toolWrapDiv', ''],
		MAIN_FIELDSET: ['toolMainFieldest', ''],
		HEADLINE_LEGEND: ['toolHeadlineLegend', '编码、解码工具'],
		LEFT_BAR: ['leftBar', ''],
		LEFT_TITLE: ['leftTitle', '内容：'],
		LEFT_TEXTAREA: ['leftTextarea', '(请输入内容)'],
		OPERATE_BAR: ['operateBar', ''],
		RIGHT_BAR: ['rightBar', ''],
		RIGHT_TITLE: ['rightTitle', '结果：'],
		RIGHT_TEXTAREA: ['rightTextarea', '(此处显示结果)'],
		COPY_BUTTON: ['toolCopyButton', '复制结果', '复制右侧方框中的内容'],
		CLOSE_BUTTON: ['toolCloseButton', '关闭', '关闭工具界面'],
		BJX_ENCODE: ['BJXEncode', '百家姓 编码 >>> ', '使用"百家姓"进行编码'],
		BJX_DECODE: ['BJXDecode', '解码 百家姓 >>> ', '对"百家姓"的编码进行解码'],
		JZG_ENCODE: ['JZGEncode', '价值观 编码 >>> ', '使用"社会主义核心价值观"进行编码'],
		JZG_DECODE: ['JZGDecode', '解码 价值观 >>> ', '对"社会主义核心价值观"的编码进行解码'],
		YFLC_ENCODE: ['YFLCEncode', '与佛论禅 编码 >>> ', '使用"与佛论禅"进行编码'],
		YFLC_DECODE: ['YFLCDecode', '解码 与佛论禅 >>> ', '对"与佛论禅"的编码进行解码'],
		BASE64_ENCODE: ['BASE64Encode', 'BASE64 编码 >>> ', '使用"BASE64"进行编码'],
		BASE64_DECODE: ['BASE64Decode', '解码 BASE64 >>> ', '对"BASE64"的编码进行解码'],
		BAIDU_QUERY: ['BAIDUQuery', '查询提取码 >>> ', '查询百度网盘的提取码'],
		STATUS_BAR: ['toolStatusBar', '等待操作中...'],
	};
	const BT_VALUE = {
		WRAP_DIV: ['btWrapDiv', ''],
		MAIN_FIELDSET: ['btMainFieldset', ''],
		HEADLINE_LEGEND: ['btHeadlineLegend', ''],
		HEADLINE_LINK: ['btHeadlineLink', '磁力链接搜索工具', '源站地址', 'http://www.gsi8.com/'],
		TOP_BAR: ['btTopBar', ''],
		SEARCH_INPUT: ['btSearchInput', '(请输入内容)'],
		SEARCH_BUTTON: ['btSearchButton', '搜索', '搜索磁力链接'],
		MIDDLE_BAR: ['btMiddleBar', ''],
		TABLE_HEADER_DIV: ['btTableHeaderDiv', ''],
		TABLE_HEADER: ['btTableHeader', ''],
		TH: ['btTh_', ''],
		TABLE_BODY_DIV: ['btTableBodyDiv', ''],
		TABLE_BODY: ['btTableBody', ''],
		TBODY: ['btTbody', ''],
		BOTTOM_BAR: ['btBottomBar', ''],
		STATUS_BAR: ['btStatusBar', '等待操作中...', '搜索中，请等候...', '搜索完成!'],
		CLOSE_BUTTON: ['btCloseButton', '关闭', '关闭工具界面'],
		PAGE_TEXT: ['btPageText', '当前页数: '],
		PREV_PAGE_BUTTON: ['btPrevPageButton', '上一页'],
		NEXT_PAGE_BUTTON: ['btNextPageButton', '下一页'],
	};
	const TOOL_ICON = {
		GRAY: 'url(data:image/svg+xml;base64,PHN2ZyByb2xlPSJpbWciIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgd2lkdGg9IjQ4cHgiIGhlaWdodD0iNDhweCIgdmlld0JveD0iMCAwIDI0IDI0IiBhcmlhLWxhYmVsbGVkYnk9InRvb2xJY29uVGl0bGUgdG9vbEljb25EZXNjIiBzdHJva2U9IiNCMkIyQjIiIHN0cm9rZS13aWR0aD0iMSIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLWxpbmVqb2luPSJtaXRlciIgZmlsbD0iI0IyQjJCMiIgY29sb3I9IiNCMkIyQjIiPiA8dGl0bGUgaWQ9InRvb2xJY29uVGl0bGUiPlRvb2w8L3RpdGxlPiA8ZGVzYyBpZD0idG9vbEljb25EZXNjIj5JY29uIG9mIGEgd3JlbmNoPC9kZXNjPiA8cGF0aCBkPSJNOS43NDI5MjkzOSwxMy43NDI5Mjk0IEM5LjE5MTM1MDE5LDEzLjkxMDEwODggOC42MDYxNzI3MSwxNCA4LDE0IEM0LjY4NjI5MTUsMTQgMiwxMS4zMTM3MDg1IDIsOCBDMiw3LjA3MzcwNjkzIDIuMjA5OTA0MzEsNi4xOTY0Mzk2NCAyLjU4NDc0MTk3LDUuNDEzMTY5MSBMNi45NDk3NDc0Nyw5Ljc3ODE3NDU5IEw5Ljc3ODE3NDU5LDYuOTQ5NzQ3NDcgTDUuNDEzMTY5MSwyLjU4NDc0MTk3IEM2LjE5NjQzOTY0LDIuMjA5OTA0MzEgNy4wNzM3MDY5MywyIDgsMiBDMTEuMzEzNzA4NSwyIDE0LDQuNjg2MjkxNSAxNCw4IEMxNCw4Ljg4MDQwNzcyIDEzLjgxMDM3NjUsOS43MTY1MjY0OCAxMy40Njk3NDI5LDEwLjQ2OTc0MjkgTDIwLjU4NTg2MzYsMTcuNTg1ODYzNiBDMjEuMzY2OTEyMiwxOC4zNjY5MTIyIDIxLjM2NjkxMjIsMTkuNjMzMjQyMiAyMC41ODU4NjM2LDIwLjQxNDI5MDcgTDE5LjkxNDI5MDcsMjEuMDg1ODYzNiBDMTkuMTMzMjQyMiwyMS44NjY5MTIyIDE3Ljg2NjkxMjIsMjEuODY2OTEyMiAxNy4wODU4NjM2LDIxLjA4NTg2MzYgTDkuNzQyOTI5MzksMTMuNzQyOTI5NCBaIi8+IDwvc3ZnPg==)',
		BLUE: 'url(data:image/svg+xml;base64,PHN2ZyByb2xlPSJpbWciIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgd2lkdGg9IjQ4cHgiIGhlaWdodD0iNDhweCIgdmlld0JveD0iMCAwIDI0IDI0IiBhcmlhLWxhYmVsbGVkYnk9InRvb2xJY29uVGl0bGUgdG9vbEljb25EZXNjIiBzdHJva2U9IiM3OUE0Q0YiIHN0cm9rZS13aWR0aD0iMSIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSIgc3Ryb2tlLWxpbmVqb2luPSJtaXRlciIgZmlsbD0iIzc5QTRDRiIgY29sb3I9IiM3OUE0Q0YiPiA8dGl0bGUgaWQ9InRvb2xJY29uVGl0bGUiPlRvb2w8L3RpdGxlPiA8ZGVzYyBpZD0idG9vbEljb25EZXNjIj5JY29uIG9mIGEgd3JlbmNoPC9kZXNjPiA8cGF0aCBkPSJNOS43NDI5MjkzOSwxMy43NDI5Mjk0IEM5LjE5MTM1MDE5LDEzLjkxMDEwODggOC42MDYxNzI3MSwxNCA4LDE0IEM0LjY4NjI5MTUsMTQgMiwxMS4zMTM3MDg1IDIsOCBDMiw3LjA3MzcwNjkzIDIuMjA5OTA0MzEsNi4xOTY0Mzk2NCAyLjU4NDc0MTk3LDUuNDEzMTY5MSBMNi45NDk3NDc0Nyw5Ljc3ODE3NDU5IEw5Ljc3ODE3NDU5LDYuOTQ5NzQ3NDcgTDUuNDEzMTY5MSwyLjU4NDc0MTk3IEM2LjE5NjQzOTY0LDIuMjA5OTA0MzEgNy4wNzM3MDY5MywyIDgsMiBDMTEuMzEzNzA4NSwyIDE0LDQuNjg2MjkxNSAxNCw4IEMxNCw4Ljg4MDQwNzcyIDEzLjgxMDM3NjUsOS43MTY1MjY0OCAxMy40Njk3NDI5LDEwLjQ2OTc0MjkgTDIwLjU4NTg2MzYsMTcuNTg1ODYzNiBDMjEuMzY2OTEyMiwxOC4zNjY5MTIyIDIxLjM2NjkxMjIsMTkuNjMzMjQyMiAyMC41ODU4NjM2LDIwLjQxNDI5MDcgTDE5LjkxNDI5MDcsMjEuMDg1ODYzNiBDMTkuMTMzMjQyMiwyMS44NjY5MTIyIDE3Ljg2NjkxMjIsMjEuODY2OTEyMiAxNy4wODU4NjM2LDIxLjA4NTg2MzYgTDkuNzQyOTI5MzksMTMuNzQyOTI5NCBaIi8+IDwvc3ZnPg==)'
	};
	const BT_ICON = {
		GRAY: 'url(data:image/svg+xml;base64,PHN2ZyByb2xlPSJpbWciIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgd2lkdGg9IjI0cHgiIGhlaWdodD0iMjRweCIgdmlld0JveD0iMCAwIDI0IDI0IiBhcmlhLWxhYmVsbGVkYnk9InNlYXJjaEljb25UaXRsZSIgc3Ryb2tlPSIjQjJCMkIyIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1saW5lam9pbj0ibWl0ZXIiIGZpbGw9Im5vbmUiIGNvbG9yPSIjQjJCMkIyIj4gPHRpdGxlIGlkPSJzZWFyY2hJY29uVGl0bGUiPlNlYXJjaDwvdGl0bGU+IDxwYXRoIGQ9Ik0xNC40MTIxMTIyLDE0LjQxMjExMjIgTDIwLDIwIi8+IDxjaXJjbGUgY3g9IjEwIiBjeT0iMTAiIHI9IjYiLz4gPC9zdmc+)',
		BLUE: 'url(data:image/svg+xml;base64,PHN2ZyByb2xlPSJpbWciIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgd2lkdGg9IjI0cHgiIGhlaWdodD0iMjRweCIgdmlld0JveD0iMCAwIDI0IDI0IiBhcmlhLWxhYmVsbGVkYnk9InNlYXJjaEljb25UaXRsZSIgc3Ryb2tlPSIjNzlBNENGIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHN0cm9rZS1saW5lam9pbj0ibWl0ZXIiIGZpbGw9Im5vbmUiIGNvbG9yPSIjNzlBNENGIj4gPHRpdGxlIGlkPSJzZWFyY2hJY29uVGl0bGUiPlNlYXJjaDwvdGl0bGU+IDxwYXRoIGQ9Ik0xNC40MTIxMTIyLDE0LjQxMjExMjIgTDIwLDIwIi8+IDxjaXJjbGUgY3g9IjEwIiBjeT0iMTAiIHI9IjYiLz4gPC9zdmc+)'
	};
	const URL_REG = /^[\S\s]*?((?:magnet:\?xt=urn:btih:|ftp:\/\/|ed2k:\/\/|thunder:\/\/|flashget:\/\/|qqdl:\/\/|xfplay:\/\/|https?:\/\/[\w-]*\.*[\w-]+\.+\w+)\S+)/i;
	const DOWNLOAD_REG = /^[\S\s]*?((?:magnet:\?xt=urn:btih:|ed2k:\/\/|thunder:\/\/)\S+)/i;
	const WWW_REG = /^[\S\s]*?(www\.[\w-]+\.[a-z]+[\w#=%+?/-]*)/i;
	const BAIDUPAN_REG = /^https?:\/\/pan\.baidu\.com\/s(?:hare)?\/[\w=?&-]+$/i;
	const BAIDUPAN_INCLUDE_CODE_REG = /^https?:\/\/pan\.baidu\.com\/s(?:hare)?\/[\w=?#&-]+$/i;
	const CODE_REG = /(?:提取)+[^a-z0-9解压]*([a-z0-9]{4})[^a-z0-9]*/i;
	const BAIDUPAN_CODE_REG = /^(?:(?:下载)?链接\S+\s+)?(?:[^解压]+\s+)?[^a-z0-9解压]*([a-z0-9]{4})[^a-z0-9]*(?:app)?[^a-z0-9]*$/i;
	const SINGLE_CHAR_CODE_REG = /^[a-z0-9]$/i;
	const MISSING_HEADER_BAIDUPAN_REG = /^[\S\s]*?[^/\w-]?(\/?s(?:hare)?\/[\w=?-]{10,50})/i;
	const MISSING_HEADER_BAIDUPAN_TEST_REG = /^([\w=?-]{15,50})\s+[a-z0-9]{4}$/i;
	const PAN_REG = /^[\S\s]*?(pan\.baidu\.com\/s(?:hare)?\/[\w=?&-]+)/i;
	const HASH_REG = /(?:[^a-z0-9]|^)([a-z0-9]{40}|[a-z0-9]{32})(?:&dn=.*|[^a-z0-9]|$)/i;
	const CORE_VALUES_REG = /^.*?((?:富强|民主|文明|和谐|自由|平等|公正|法治|爱国|敬业|诚信|友善){10,}).*?$/i;
	const BAIJIA_REG = /^.*?([赵钱孙李周吴郑王冯陈褚卫蒋沈韩杨朱秦尤许何吕施张孔曹严华金魏陶姜戚谢邹喻福水窦章云苏潘葛奚范彭郎鲁韦昌马苗凤花方俞任袁柳唐罗薛伍余米贝姚孟顾尹江钟]{10,}).*?$/i;
	const FOYU_REG = /^.*?((?:佛曰：|如是我闻：)\S{10,}).*?$/i;
	const PREFIX_LINK_REG = {
		MAGNET: /^https?:\/\/www\.wnflb\d*\.com\/magnet:\?xt=.*$/i,
		MAGNET_SWITCH: /^https?:\/\/www\.wnflb\d*\.com\//i,
	};
	const PREFIX_CODE_REG = {
		CODE: /^https?:\/\/www\.wnflb\d*\.com\/\w+-\w+$/i,
		CODE_SWITCH: /^https?:\/\/www\.wnflb\d*\.com\//i,
	};
	const BASE_IMAGE_REG = /^https?:\/\/(data:)/i;
	const FILTER_LINK_REG = {
		PAN_TEXT: /^https?:\/\/pan\.baidu\.com\/(?:s|share|mbox)?\/[\w#?%=/&-]*[^\w#?%=/&-]+/i,
		POJIE: /^https?:\/\/www\.52pojie\.cn\/?#?$/i,
		POJIE_PHP: /^https?:\/\/www\.52pojie\.cn\/(?:forum|home|misc)\.php\?/i,
		POJIE_HTML: /^https?:\/\/www\.52pojie\.cn\/(?:forum|thread)-\d+-\d+(?:-\d+)?\.html$/i,
		FULIBA: /^https?:\/\/www\.wnflb\d*\.com\/?$/i,
		FULIBA_PHP: /^https?:\/\/www\.wnflb\d*\.com\/(?:home|forum)\.php\?/i,
		FULIBA_HTML: /^https?:\/\/www\.wnflb\d*\.com\/(?:thread|forum)-\d+-\d+(?:-\d+)?\.html$/i,
		IMDB: /^https?:\/\/www\.imdb\.com\/title\//i,
		DOUBAN: /^https?:\/\/movie\.douban\.com\/(?:subject|celebrity)/i,
		PHOTO_WEIBO: /^https?:\/\/photo\.weibo\.com\//i,
		S_WEIBO: /^https?:\/\/s\.weibo\.com\/weibo\?q=/i,
		BAIKE: /^https?:\/\/baike\.(?:so|baidu|sogou)\.com/i,
		BILIBILI_APP: /^https?:\/\/app\.bilibili\.com/i,
		ZHIYOO: /^https?:\/\/bbs\.zhiyoo\.com\/(?:forum|gforum)-\d+-\d+\.html/i,
		TAG_3DM: /^https?:\/\/www\.3dmgame\.com\/tag\//i,
		GAMES_3DM: /^https?:\/\/www\.3dmgame\.com\/games\/[^/]*\/?$/i,
		TV432: /^https?:\/\/www\.tv432\.com\/search\.php\?searchword=/i,
		VIIDII: /^https?:\/\/www\.viidii\.info\/\?/i,
		DAYBOX: /^https?:\/\/www\.daybox\.net\/image\//i,
		YIDIANZIXUN: /^https?:\/\/www\.yidianzixun\.com\/channel\//i,
		SINA: /^https?:\/\/[\w-]*\.?sina\.com\.cn\/?/i,
	};
	const CORE_VALUES = '富强民主文明和谐自由平等公正法治爱国敬业诚信友善';
	const BAIJIA_VALUES = {
		"赵": "0",
		"钱": "1",
		"孙": "2",
		"李": "3",
		"周": "4",
		"吴": "5",
		"郑": "6",
		"王": "7",
		"冯": "8",
		"陈": "9",
		"褚": "a",
		"卫": "b",
		"蒋": "c",
		"沈": "d",
		"韩": "e",
		"杨": "f",
		"朱": "g",
		"秦": "h",
		"尤": "i",
		"许": "j",
		"何": "k",
		"吕": "l",
		"施": "m",
		"张": "n",
		"孔": "o",
		"曹": "p",
		"严": "q",
		"华": "r",
		"金": "s",
		"魏": "t",
		"陶": "u",
		"姜": "v",
		"戚": "w",
		"谢": "x",
		"邹": "y",
		"喻": "z",
		"福": "A",
		"水": "B",
		"窦": "C",
		"章": "D",
		"云": "E",
		"苏": "F",
		"潘": "G",
		"葛": "H",
		"奚": "I",
		"范": "J",
		"彭": "K",
		"郎": "L",
		"鲁": "M",
		"韦": "N",
		"昌": "O",
		"马": "P",
		"苗": "Q",
		"凤": "R",
		"花": "S",
		"方": "T",
		"俞": "U",
		"任": "V",
		"袁": "W",
		"柳": "X",
		"唐": "Y",
		"罗": "Z",
		"薛": ".",
		"伍": "-",
		"余": "_",
		"米": "+",
		"贝": "=",
		"姚": "/",
		"孟": "?",
		"顾": "#",
		"尹": "%",
		"江": "&",
		"钟": "*"
	};
	var highlight_config = {
		highlight_enable: true,
		agree_threshold: 0,
		agree_color: '',
		reply_threshold: 0,
		reply_color: '',
		copy_enable: true,
		text_color: '',
		link_color: '',
		float_enable: false,
		extract_enable: false,
		pandownload_enable: false,
		query_enable: false,
		code_enable: false,
		bt_enable: false,
		click_enable: false,
	};
	var default_config = {
		highlight_enable: true,
		agree_threshold: 20,
		agree_color: '#EE1B2E',
		reply_threshold: 50,
		reply_color: '#2B65B7',
		copy_enable: true,
		text_color: '#FF33CC',
		link_color: '#369',
		float_enable: false,
		extract_enable: false,
		pandownload_enable: false,
		query_enable: false,
		code_enable: false,
		bt_enable: false,
		click_enable: false,
	};
	var check_date = '';
	var bt_page_num = 0;

	function rand_Bin() {
		return Math.random() >= 0.5
	}
	function str_2_Utf8(str) {
		let not_encoded = /[A-Za-z0-9\-_.!~*'()]/g;
		let str1 = str.replace(not_encoded, c => c.codePointAt(0).toString(16));
		let str2 = encodeURIComponent(str1);
		let concated = str2.replace(/%/g, '').toUpperCase();
		return concated
	}
	function hex_2_Duo(hexs) {
		let duo = [];
		for (let c of hexs) {
			let n = Number.parseInt(c, 16);
			if (n < 10) {
				duo.push(n)
			} else {
				if (rand_Bin()) {
					duo.push(10);
					duo.push(n - 10)
				} else {
					duo.push(11);
					duo.push(n - 6)
				}
			}
		}
		return duo
	}
	function utf8_2_Str(utfs) {
		let l = utfs.length;
		let splited = [];
		for (let i = 0; i < l; i++) {
			if ((i & 1) === 0) {
				splited.push('%')
			}
			splited.push(utfs[i])
		}
		return decodeURIComponent(splited.join(''))
	}
	function duo_2_Hex(duo) {
		let hex = [];
		let l = duo.length;
		let i = 0;
		while (i < l) {
			if (duo[i] < 10) {
				hex.push(duo[i])
			} else {
				if (duo[i] === 10) {
					i++;
					hex.push(duo[i] + 10)
				} else {
					i++;
					hex.push(duo[i] + 6)
				}
			}
			i++
		}
		return hex.map(v => v.toString(16).toUpperCase()).join('')
	}
	function duo_2_Values(duo) {
		return duo.map(d => CORE_VALUES[2 * d] + CORE_VALUES[2 * d + 1]).join('')
	}
	function values_Encode(str) {
		return duo_2_Values(hex_2_Duo(str_2_Utf8(str)))
	}
	function values_Decode(encoded) {
		let duo = [];
		for (let c of encoded) {
			let i = CORE_VALUES.indexOf(c);
			if (i === -1) {
				continue
			} else if (i & 1) {
				continue
			} else {
				duo.push(i >> 1)
			}
		}
		let hexs = duo_2_Hex(duo);
		let str;
		try {
			str = utf8_2_Str(hexs)
		} catch (e) {
			throw e;
		}
		return str
	}
	function get_Cut_Link_Text(link_text, float_enable = false) {
		if (check_Mobile_Page()) {
			return (link_text.length >= 35) ? (link_text.slice(0, 15) + ' ... ' + link_text.slice(-10)) : (link_text)
		} else if (float_enable) {
			return (link_text.length >= 50) ? (link_text.slice(0, 25) + ' ... ' + link_text.slice(-15)) : (link_text)
		}
		return (link_text.length >= 80) ? (link_text.slice(0, 45) + ' ... ' + link_text.slice(-25)) : (link_text)
	}
	function create_Link(link_href, list_style, float_enable = false) {
		let link_li = document.createElement('li');
		if (list_style) {
			link_li.style.listStyleType = 'disc'
		} else {
			link_li.style.listStyleType = 'circle'
		}
		let link_a = document.createElement('a');
		link_a.title = '点击访问';
		link_href = manage_Prefix_Code(link_href);
		link_a.href = encodeURI(link_href);
		link_a.target = '_blank';
		link_a.innerText = get_Cut_Link_Text(link_href, float_enable);
		link_a.style.display = 'inline';
		link_a.style.fontSize = '15px';
		link_a.style.color = highlight_config.link_color;
		link_a.style.whiteSpace = 'nowrap';
		link_li.appendChild(link_a);
		if (highlight_config.copy_enable) {
			let copy_a = document.createElement('a');
			copy_a.className = 'copy_btn';
			copy_a.title = '复制链接';
			copy_a.href = 'javascript:;';
			copy_a.target = '_self';
			copy_a.innerText = '复制';
			copy_a.style.display = 'inline-block';
			copy_a.style.fontSize = '15px';
			copy_a.style.color = highlight_config.link_color;
			copy_a.style.marginLeft = '20px';
			copy_a.style.textDecoration = 'underline';
			copy_a.addEventListener('click', function() {
				GM_setClipboard(link_href, "text");
				this.style.color = '#f60';
				this.title = '复制成功'
			});
			link_li.appendChild(copy_a);
			if (BAIDUPAN_INCLUDE_CODE_REG.test(link_href) && (/#[a-z0-9]{4}$/i.test(link_href))) {
				let code_value = /#([a-z0-9]{4})$/i.exec(link_href)[1];
				let code_copy_a = document.createElement('a');
				code_copy_a.className = 'code_copy_btn';
				code_copy_a.title = '复制提取码';
				code_copy_a.href = 'javascript:;';
				code_copy_a.target = '_self';
				code_copy_a.innerText = '复制提取码';
				code_copy_a.style.display = 'inline-block';
				code_copy_a.style.fontSize = '15px';
				code_copy_a.style.color = highlight_config.link_color;
				code_copy_a.style.marginLeft = '20px';
				code_copy_a.style.textDecoration = 'underline';
				code_copy_a.addEventListener('click', function() {
					GM_setClipboard(code_value, "text");
					this.style.color = '#f60';
					this.title = '复制成功'
				});
				link_li.appendChild(code_copy_a)
			}
		}
		if (highlight_config.pandownload_enable) {
			if (BAIDUPAN_INCLUDE_CODE_REG.test(link_href)) {
				let jump_a = document.createElement('a');
				jump_a.className = 'jump_btn';
				jump_a.title = '跳转到PanDownload网页版';
				jump_a.href = link_href.replace('pan.baidu.com', 'pan.baiduwp.com');
				jump_a.target = '_blank';
				jump_a.innerText = '跳转';
				jump_a.style.display = 'inline-block';
				jump_a.style.fontSize = '15px';
				jump_a.style.color = highlight_config.link_color;
				jump_a.style.marginLeft = '20px';
				jump_a.style.textDecoration = 'underline';
				link_li.appendChild(jump_a)
			}
		}
		if (highlight_config.query_enable) {
			if (BAIDUPAN_REG.test(link_href)) {
				let query_a = document.createElement('a');
				query_a.className = 'query_btn';
				query_a.title = '查询百度网盘提取码';
				query_a.href = 'javascript:;';
				query_a.target = '_self';
				query_a.innerText = '查询';
				query_a.style.display = 'inline-block';
				query_a.style.fontSize = '15px';
				query_a.style.color = highlight_config.link_color;
				query_a.style.marginLeft = '20px';
				query_a.style.textDecoration = 'underline';
				query_a.addEventListener('click', function() {
					let details = {
						'method': 'GET',
						'url': 'https://search.pandown.cn/api/query?surl=' + link_href.split('/').pop(),
						'responseType': 'json',
						'headers': {
							'Content-Type': 'application/x-www-form-urlencoded'
						},
						'onload': function(res) {
							if ((res.response.code === 0) && (res.response.data[0].password)) {
								alert(res.response.data[0].password)
							} else {
								console.log(res.response.message);
								alert('没有查询到提取码哦。')
							}
						},
						'onerror': function() {
							alert('网络连接出问题啦。')
						}
					};
					GM_xmlhttpRequest(details)
				});
				link_li.appendChild(query_a)
			}
		}
		return link_li
	}
	function manage_Prefix(input_link_array) {
		let return_link_array = [];
		$.each(input_link_array, function(_index, item) {
			return_link_array.push(PREFIX_LINK_REG.MAGNET.test(item) ? item.replace(PREFIX_LINK_REG.MAGNET_SWITCH, '') : item)
		});
		return return_link_array
	}
	function manage_Prefix_Code(input_link) {
		return (PREFIX_CODE_REG.CODE.test(input_link) ? input_link.replace(PREFIX_CODE_REG.CODE_SWITCH, '') : input_link)
	}
	function manage_Text(text_array) {
		let temp_array = [];
		$.each(text_array, function(_index, item) {
			let temp_link = '';
			if (PAN_REG.test(item)) {
				temp_link = 'https://' + PAN_REG.exec(item)[1]
			} else if (URL_REG.test(item)) {
				temp_link = URL_REG.exec(item)[1]
			} else if (WWW_REG.test(item)) {
				temp_link = 'http://' + WWW_REG.exec(item)[1]
			} else if (MISSING_HEADER_BAIDUPAN_REG.test(item)) {
				let link_miss_value = MISSING_HEADER_BAIDUPAN_REG.exec(item)[1];
				temp_link = (/^\//i.test(link_miss_value)) ? ('https://pan.baidu.com' + link_miss_value) : ('https://pan.baidu.com/' + link_miss_value)
			} else if (MISSING_HEADER_BAIDUPAN_TEST_REG.test(item)) {
				temp_link = 'https://pan.baidu.com/s/' + MISSING_HEADER_BAIDUPAN_TEST_REG.exec(item)[1]
			} else if (HASH_REG.test(item)) {
				temp_link = 'magnet:?xt=urn:btih:' + HASH_REG.exec(item)[1]
			} else if (item.length > 32) {
				let item_1 = item.replace(/[^a-z0-9:=?/.&%|-]/gi, '');
				if (DOWNLOAD_REG.test(item_1)) {
					temp_link = DOWNLOAD_REG.exec(item_1)[1]
				} else {
					let item_2 = item.replace(/[^a-z0-9:=?/.,，。|\s-]/gi, '');
					if (HASH_REG.test(item_2) && (!(/^(?:[a-z]+|[0-9]+)$/i.test(item_2))) && (!(URL_REG.test(item_2)))) {
						temp_link = 'magnet:?xt=urn:btih:' + HASH_REG.exec(item_2)[1]
					}
				}
			}
			if (filter_Link(temp_link)) {
				temp_array.push(temp_link)
			}
		});
		return manage_Prefix(temp_array)
	}
	function decode_Link(input_link_array) {
		$.each(input_link_array, function(index, item) {
			if (URL_REG.test(item)) {
				input_link_array[index] = decodeURI(item)
			}
		});
		return input_link_array
	}
	function foyu_Promise(encoded) {
		return new Promise(function(resolve, _reject) {
			let details = {
				'method': 'POST',
				'url': 'http://keyfc.net/bbs/tools/tudou.aspx',
				'data': 'orignalMsg=' + encoded.replace(/\s/g, '') + '&action=Decode',
				'headers': {
					'Content-Type': 'application/x-www-form-urlencoded'
				},
				'onload': function(res) {
					resolve(res.responseText.replace(/^<BUDDHIST><Message><!\[CDATA\[|\]\]><\/Message><\/BUDDHIST>$/g, ''))
				},
				'onerror': function() {
					console.log('Decode is error.');
					resolve('')
				}
			};
			GM_xmlhttpRequest(details)
		})
	}
	async function foyu_Decode(container, id_number, encoded, float_enable) {
		await foyu_Promise(encoded).then(function(data) {
			if (data) {
				let good_boy_ul = document.getElementById('goodBoyId_' + id_number);
				if (good_boy_ul) {
					if (float_enable) {
						good_boy_ul.appendChild(create_Link(data, true, true))
					} else {
						good_boy_ul.appendChild(create_Link(data, true))
					}
				} else {
					if (float_enable) {
						let good_boy_div = create_Good_Boy_Div();
						let good_boy_p = create_Good_Boy_P();
						good_boy_ul = document.createElement('ul');
						good_boy_ul.id = 'goodBoyId_' + id_number;
						good_boy_ul.appendChild(good_boy_p);
						good_boy_div.appendChild(good_boy_ul);
						good_boy_ul.appendChild(create_Link(data, true, true));
						container.append(good_boy_div)
					} else {
						good_boy_ul = document.createElement('ul');
						good_boy_ul.id = 'goodBoyId_' + id_number;
						good_boy_ul.className = 'goodBoy';
						let good_boy_p = create_Good_Boy_P();
						good_boy_ul.appendChild(good_boy_p);
						good_boy_ul.appendChild(create_Link(data, true));
						container.append(good_boy_ul)
					}
				}
			}
		})
	}
	function baijia_Encode(str) {
		str = str.replace(/^\s\s*/, '').replace(/\s\s*$/, '');
		let v = str.replace(/magnet:\?xt=urn:btih:/, "");
		let strc = v.split("");
		let a = '';
		for (let i = 0; i < strc.length; i++) {
			for (let key in BAIJIA_VALUES) {
				if (BAIJIA_VALUES[key] === strc[i]) {
					a += key;
					break
				}
			}
		}
		return a
	}
	function baijia_Decode(encoded) {
		let char_array = encoded.split("");
		let str = '';
		for (let i = 0; i < char_array.length; i++) {
			if (BAIJIA_VALUES[char_array[i]]) {
				str += BAIJIA_VALUES[char_array[i]]
			}
		}
		if (/^https?\/\/[\w-]*\.*[\w-]+\.+\w+/i.test(str)) {
			return str.replace('https//', 'https://').replace('http//', 'http://')
		} else {
			return 'magnet:?xt=urn:btih:' + str
		}
	}
	function decode_Core_Values(container, id_number, text_array, float_enable) {
		let decode_array = [];
		$.each(text_array, function(_index, item) {
			if (CORE_VALUES_REG.test(item)) {
				decode_array.push(values_Decode(CORE_VALUES_REG.exec(item)[1]))
			} else if (BAIJIA_REG.test(item)) {
				decode_array.push(baijia_Decode(BAIJIA_REG.exec(item)[1]))
			} else if (FOYU_REG.test(item)) {
				foyu_Decode(container, id_number, FOYU_REG.exec(item)[1], float_enable)
			}
		});
		return decode_array
	}
	function pick_Up_Baidupan_Code(text_array) {
		let code_array = [];
		let char_array = [];
		for (let i = 0; i < text_array.length; i++) {
			if (CODE_REG.test(text_array[i])) {
				let code_value = CODE_REG.exec(text_array[i])[1];
				if (code_array.indexOf(code_value) === -1) {
					code_array.push(code_value)
				}
			} else if (BAIDUPAN_CODE_REG.test(text_array[i])) {
				let paidupan_code_value = BAIDUPAN_CODE_REG.exec(text_array[i])[1];
				if (code_array.indexOf(paidupan_code_value) === -1) {
					code_array.push(paidupan_code_value)
				}
			} else if (SINGLE_CHAR_CODE_REG.test(text_array[i])) {
				char_array.push(text_array[i])
			}
		}
		while ((char_array.length > 0) && (char_array.length % 4 === 0)) {
			let temp_code = char_array.splice(0, 4);
			code_array.push(temp_code.join(""))
		}
		return code_array
	}
	function judge_Links(links_array, link_value) {
		let status = true;
		for (let i = 0; i < links_array.length; i++) {
			if (get_Pure_Link(links_array[i], true).includes(get_Pure_Link(link_value, true))) {
				status = false;
				break
			}
		}
		return status
	}
	function baidupan_Auto_Event(container, id_number, link_obj_array, baidu_obj_array, links_array, hide_text_array, show_text_array, node_text_array, float_enable = false) {
		let link_array = [];
		let link_text_array = [];
		$.each(link_obj_array, function(_index, item) {
			link_array.push(item.ele_value);
			link_text_array.push(item.ele_container)
		});
		let concat_text_array = manage_Repeat_Array(decode_Link(hide_text_array));
		let concat_link_array = manage_Repeat_Array(decode_Link(manage_Text(link_array.concat(concat_text_array))));
		let general_text_array = show_text_array.concat(node_text_array.concat(link_text_array));
		let index_a = [];
		let code_b = pick_Up_Baidupan_Code(concat_text_array);
		let code_c = [];
		if (code_b.length > 0) {
			for (let j = 0; j < concat_link_array.length; j++) {
				if (BAIDUPAN_REG.test(concat_link_array[j])) {
					index_a.push(j)
				}
			}
			if (code_b.length === index_a.length) {
				for (let k = 0; k < index_a.length; k++) {
					concat_link_array[index_a[k]] += ('#' + code_b[k])
				}
			} else if (code_b.length === baidu_obj_array.length) {
				for (let l = 0; l < baidu_obj_array.length; l++) {
					if (float_enable) {
						concat_link_array.push(baidu_obj_array[l].ele_value + '#' + code_b[l])
					} else {
						baidu_obj_array[l].ele.text(baidu_obj_array[l].ele_container + '#' + code_b[l]);
						baidu_obj_array[l].ele.attr('href', baidu_obj_array[l].ele_value + '#' + code_b[l])
					}
				}
			}
		} else {
			code_c = pick_Up_Baidupan_Code(general_text_array);
			if (code_c.length > 0) {
				for (let j = 0; j < concat_link_array.length; j++) {
					if (BAIDUPAN_REG.test(concat_link_array[j])) {
						index_a.push(j)
					}
				}
				if (code_c.length === index_a.length) {
					for (let k = 0; k < index_a.length; k++) {
						concat_link_array[index_a[k]] += ('#' + code_c[k])
					}
				} else if (code_c.length === baidu_obj_array.length) {
					for (let l = 0; l < baidu_obj_array.length; l++) {
						if (float_enable) {
							concat_link_array.push(baidu_obj_array[l].ele_value + '#' + code_c[l])
						} else {
							baidu_obj_array[l].ele.text(baidu_obj_array[l].ele_container + '#' + code_c[l]);
							baidu_obj_array[l].ele.attr('href', baidu_obj_array[l].ele_value + '#' + code_c[l])
						}
					}
				}
			}
		}
		let hash_array = [];
		$.each(general_text_array, function(_index, item) {
			if (DOWNLOAD_REG.test(item)) {
				hash_array.push(DOWNLOAD_REG.exec(item)[1])
			} else if ((HASH_REG.test(item)) && (!URL_REG.test(item))) {
				hash_array.push('magnet:?xt=urn:btih:' + HASH_REG.exec(item)[1])
			} else if (item.length > 32) {
				let item_1 = item.replace(/[^a-z0-9:=?/.&%|-]/gi, '');
				if (DOWNLOAD_REG.test(item_1)) {
					hash_array.push(DOWNLOAD_REG.exec(item_1)[1])
				} else {
					let item_2 = item.replace(/[^a-z0-9:=?/.,，。|\s-]/gi, '');
					if (HASH_REG.test(item_2) && (!(/^(?:[a-z]+|[0-9]+)$/i.test(item_2))) && (!(URL_REG.test(item_2)))) {
						hash_array.push('magnet:?xt=urn:btih:' + HASH_REG.exec(item_2)[1])
					}
				}
			}
		});
		hash_array = decode_Link(hash_array);
		concat_link_array = manage_Repeat_Array(concat_link_array.concat(hash_array));
		let extract_array = [];
		if (highlight_config.extract_enable) {
			let general_link_array = decode_Link(manage_Text(general_text_array));
			$.each(general_link_array, function(_index, item) {
				if ((filter_Link(item)) && (judge_Links(links_array, item))) {
					if (judge_Links(concat_link_array, item)) {
						extract_array.push(item)
					}
				}
			})
		}
		if (extract_array.length > 0) {
			extract_array = manage_Repeat_Array(extract_array);
			if ((index_a.length === 0) && (baidu_obj_array.length === 0)) {
				if ((code_b.length > 0)) {
					let index_m = [];
					for (let m = 0; m < extract_array.length; m++) {
						if (BAIDUPAN_REG.test(extract_array[m])) {
							index_m.push(m)
						}
					}
					if (code_b.length === index_m.length) {
						for (let n = 0; n < index_m.length; n++) {
							extract_array[index_m[n]] += ('#' + code_b[n])
						}
					}
				} else if (code_c.length > 0) {
					let index_p = [];
					for (let p = 0; p < extract_array.length; p++) {
						if (BAIDUPAN_REG.test(extract_array[p])) {
							index_p.push(p)
						}
					}
					if (code_c.length === index_p.length) {
						for (let q = 0; q < index_p.length; q++) {
							extract_array[index_p[q]] += ('#' + code_c[q])
						}
					}
				}
			}
		}
		let hide_code_text_array = decode_Core_Values(container, id_number, hide_text_array.concat(general_text_array), float_enable);
		if (hide_code_text_array.length > 0) {
			concat_link_array = manage_Repeat_Array(concat_link_array.concat(hide_code_text_array))
		}
		let back_obj = {
			concat_link_array: concat_link_array,
			extract_link_array: extract_array,
		};
		return back_obj
	}
	function create_Good_Boy_Div() {
		let good_boy_div = document.createElement('div');
		good_boy_div.className = 'goodBoyDiv';
		good_boy_div.style.position = 'absolute';
		good_boy_div.style.width = '430px';
		good_boy_div.style.paddingLeft = '20px';
		good_boy_div.style.paddingRight = '10px';
		good_boy_div.style.marginLeft = '962px';
		good_boy_div.style.marginTop = '-170px';
		good_boy_div.style.border = '2px #CDCDCD solid';
		good_boy_div.style.borderRadius = '8px';
		return good_boy_div
	}
	function create_Good_Boy_P() {
		let good_boy_p = document.createElement('p');
		good_boy_p.innerText = '好孩子看得见：';
		good_boy_p.style.color = 'red';
		good_boy_p.style.fontSize = '15px';
		return good_boy_p
	}
	function create_Good_Boy_Button(container, id_number, link_obj, text_obj, node_text_array, float_enable = false) {
		let back_obj = baidupan_Auto_Event(container, id_number, link_obj.link_obj_array, link_obj.baidu_obj_array, link_obj.links_array, text_obj.hide_text_array, text_obj.show_text_array, node_text_array, float_enable);
		if ((back_obj.concat_link_array.length !== 0) || (back_obj.extract_link_array.length !== 0)) {
			let good_boy_ul = document.getElementById('goodBoyId_' + id_number);
			if (good_boy_ul) {
				if (float_enable) {
					$.each(back_obj.concat_link_array, function(_index, item) {
						good_boy_ul.appendChild(create_Link(item, true, true))
					});
					$.each(back_obj.extract_link_array, function(_index, item) {
						good_boy_ul.appendChild(create_Link(item, false, true))
					})
				} else {
					$.each(back_obj.concat_link_array, function(_index, item) {
						good_boy_ul.appendChild(create_Link(item, true))
					});
					$.each(back_obj.extract_link_array, function(_index, item) {
						good_boy_ul.appendChild(create_Link(item, false))
					})
				}
			} else {
				if (float_enable) {
					let good_boy_div = create_Good_Boy_Div();
					let good_boy_p = create_Good_Boy_P();
					good_boy_ul = document.createElement('ul');
					good_boy_ul.id = 'goodBoyId_' + id_number;
					good_boy_ul.appendChild(good_boy_p);
					good_boy_div.appendChild(good_boy_ul);
					$.each(back_obj.concat_link_array, function(_index, item) {
						good_boy_ul.appendChild(create_Link(item, true, true))
					});
					$.each(back_obj.extract_link_array, function(_index, item) {
						good_boy_ul.appendChild(create_Link(item, false, true))
					});
					container.append(good_boy_div)
				} else {
					good_boy_ul = document.createElement('ul');
					good_boy_ul.id = 'goodBoyId_' + id_number;
					good_boy_ul.className = 'goodBoy';
					let good_boy_p = create_Good_Boy_P();
					good_boy_ul.appendChild(good_boy_p);
					$.each(back_obj.concat_link_array, function(_index, item) {
						good_boy_ul.appendChild(create_Link(item, true))
					});
					$.each(back_obj.extract_link_array, function(_index, item) {
						good_boy_ul.appendChild(create_Link(item, false))
					});
					container.append(good_boy_ul)
				}
			}
		}
	}
	function filter_Link(input_link) {
		let status = true;
		if (input_link) {
			$.each(FILTER_LINK_REG, function(_index, item) {
				if (item.test(input_link)) {
					status = false;
					return false
				}
			})
		} else {
			status = false
		}
		return status
	}
	function manage_Repeat_Array(input_link_array) {
		let output_link_array = [];
		for (let i = 0, l = input_link_array.length; i < l; i++) {
			for (let j = i + 1; j < l; j++) {
				if (get_Pure_Link(input_link_array[i]) === get_Pure_Link(input_link_array[j])) {
					++i;
					j = i
				}
			}
			output_link_array.push(input_link_array[i])
		}
		return output_link_array
	}
	function get_Pure_Link(input_link, depth_boolean) {
		let output_link = input_link;
		if (depth_boolean) {
			if (BAIDUPAN_INCLUDE_CODE_REG.test(output_link)) {
				if (/#[a-z0-9]{4}$/i.test(output_link)) {
					output_link = output_link.replace(/#[a-z0-9]{4}$/i, '')
				}
			} else if (/^https?:\/\/www\.bilibili\.com\/video\/av\d+\?from=search/i.test(output_link)) {
				output_link = output_link.replace(/\?from=search.*/, '')
			}
		}
		return output_link.replace(/(^(?:\s+)?(?:\[url\])?(?:\s+)?(?:https?:\/\/)?|(?:\/+)?(?:\s+)?(?:\[\/url\])?$|%C2%A0$)/gi, '').replace(/%C2%A0/gi, '%20')
	}
	function contrast_Text_And_Link(text_value, link_value) {
		let status = true;
		text_value = get_Pure_Link(text_value, true);
		link_value = get_Pure_Link(link_value, true);
		if (/\s...\s/i.test(text_value)) {
			status = false
		} else if (text_value === link_value) {
			status = false
		}
		return status
	}
	function find_Link(container) {
		let link = container.find('a').not($('div.aimg_tip a'));
		let temp_obj = {
			link_obj_array: [],
			baidu_obj_array: [],
			links_array: [],
		};
		let temp_baidu_array = [];
		for (let i = 0; i < link.length; i++) {
			let temp_link = link.eq(i).attr('href');
			if ((link.eq(i).find('img.zoom').length === 1) && (!BAIDUPAN_REG.test(temp_link))) {
				let zoom_img = link.eq(i).find('img.zoom');
				if (!/^data:/i.test(zoom_img.attr('src'))) {
					continue
				}
			}
			if (filter_Link(temp_link)) {
				let temp_img = link.eq(i).find('img');
				if ((temp_img.length === 0) || ((temp_img.length !== 0) && (temp_img.attr('src') !== temp_link))) {
					let temp_text = link.eq(i).text().replace(/^\s+|\s+$/gi, '');
					if (contrast_Text_And_Link(temp_text, temp_link)) {
						let link_obj = {
							ele_value: temp_link,
							ele_container: temp_text,
							ele: link.eq(i),
						};
						temp_obj.link_obj_array.push(link_obj)
					} else if (BAIDUPAN_REG.test(temp_link)) {
						let baidu_obj = {
							ele_value: temp_link,
							ele_container: temp_text,
							ele: link.eq(i),
						};
						if (temp_baidu_array.indexOf(temp_link) === -1) {
							temp_baidu_array.push(temp_link);
							temp_obj.baidu_obj_array.push(baidu_obj)
						}
					}
				}
				if (temp_obj.links_array.indexOf(temp_link) === -1) {
					temp_obj.links_array.push(temp_link)
				}
			}
		}
		return temp_obj
	}
	function judge_Color(rgb_color_value) {
		if (/rgb\(/i.test(rgb_color_value)) {
			let rgb_value = rgb_color_value.replace('rgb(', '').replace(')', '');
			let rgb_value_array = rgb_value.split(',');
			let gray_level = rgb_value_array[0] * 0.299 + rgb_value_array[1] * 0.587 + rgb_value_array[2] * 0.114;
			return gray_level > 192
		} else if (/rgba\(/i.test(rgb_color_value)) {
			let rgba_value = rgb_color_value.replace('rgba(', '').replace(')', '');
			let rgba_value_array = rgba_value.split(',');
			if (rgba_value_array[3] <= 0.2) {
				return true
			} else {
				let gray_level_2 = rgba_value_array[0] * 0.299 + rgba_value_array[1] * 0.587 + rgba_value_array[2] * 0.114;
				return gray_level_2 > 192
			}
		}
		return false
	}
	function rgb_To_Rgba(color_string) {
		let color_value = color_string.match(/\d+/g);
		if (color_value.length === 3) {
			return 'rgba(' + color_value[0] + ', ' + color_value[1] + ', ' + color_value[2] + (', 1)')
		}
		return color_string
	}
	function display_Text(container, new_text_color, new_text_background_color) {
		let text = container.find('font').not('.quote font').not('font:has(.aimg_tip)');
		let temp_obj = {
			hide_text_array: [],
			show_text_array: [],
		};
		for (let i = 0; i < text.length; i++) {
			let temp_text = text.eq(i).text().replace(/^\s+|\s+$/gi, '');
			if (!/^\s*$/i.test(temp_text)) {
				let text_color = text.eq(i).css('color');
				let text_background_color = text.eq(i).css('background-color');
				if ((judge_Color(text_color)) && (judge_Color(text_background_color))) {
					text.eq(i).css('color', new_text_color);
					temp_obj.hide_text_array.push(temp_text)
				} else if (rgb_To_Rgba(text_background_color) === rgb_To_Rgba(text_color)) {
					text.eq(i).css('background-color', new_text_background_color);
					text.eq(i).css('color', new_text_color);
					temp_obj.hide_text_array.push(temp_text)
				} else if ((!judge_Color(text_background_color)) && (!judge_Color(text_color))) {
					text.eq(i).css('background-color', new_text_background_color);
					text.eq(i).css('color', new_text_color);
					temp_obj.hide_text_array.push(temp_text)
				} else {
					if (!temp_obj.show_text_array.includes(temp_text)) {
						temp_obj.show_text_array.push(temp_text)
					}
				}
			}
		}
		let temp_table = container.find('table');
		for (let j = 0; j < temp_table.length; j++) {
			if ((!judge_Color(temp_table.eq(j).css('background-color'))) && (!judge_Color(temp_table.eq(j).css('color')))) {
				temp_table.eq(j).css('background-color', new_text_background_color)
			} else if ((judge_Color(temp_table.eq(j).css('color')) && (judge_Color(temp_table.eq(j).css('background-color'))))) {
				temp_table.eq(j).css('color', new_text_color)
			}
		}
		return temp_obj
	}
	function analysis_Text(dom_point) {
		let node_list = dom_point.childNodes;
		let node_text_array = [];
		for (let i = 0; i < node_list.length; i++) {
			if (node_list[i].nodeType === 3) {
				let temp_text = node_list[i].nodeValue.replace(/^\s+|\s+$/gi, '');
				if (!/^\s*$/i.test(temp_text)) {
					node_text_array.push(temp_text)
				}
			} else if ((node_list[i].nodeType === 1) && (!node_list[i].className.includes('quote')) && (!node_list[i].className.includes('pstatus')) && (!node_list[i].className.includes('aimg_tip')) && (!node_list[i].className.includes('blockcode')) && ((node_list[i].nodeName !== 'FONT') || ((node_list[i].nodeName === 'FONT') && node_list[i].getElementsByTagName('br').length > 0)) && (node_list[i].nodeName !== 'A') && (node_list[i].nodeName !== 'SCRIPT') && (node_list[i].childNodes.length > 0)) {
				let recursive_array = analysis_Text(node_list[i]);
				for (let j = 0; j < recursive_array.length; j++) {
					node_text_array.push(recursive_array[j])
				}
			}
		}
		return node_text_array
	}
	function check_Mobile_Page() {
		return $('.footer').length !== 0
	}
	function get_Now_Date() {
		let now = new Date();
		return now.getFullYear() + '-' + (now.getMonth() + 1) + '-' + now.getDate()
	}
	function highlight_Post() {
		let access_num = $('#g_upmine').text();
		access_num = /LV\.(-?[0-9])/.exec(access_num)[1];
		if (access_num) {
			access_num = Number(access_num);
			switch (access_num) {
			case -1:
				access_num = 0;
				break;
			case 0:
				access_num = 5;
				break;
			case 1:
				access_num = 10;
				break;
			case 2:
				access_num = 20;
				break;
			case 3:
				access_num = 30;
				break;
			case 4:
				access_num = 40;
				break;
			case 5:
				access_num = 50;
				break;
			case 6:
				access_num = 60;
				break;
			case 7:
				access_num = 70;
				break;
			case 8:
				access_num = 80;
				break;
			case 9:
				access_num = 90;
				break;
			default:
				access_num = 90;
				break
			}
		} else {
			access_num = 90
		}
		let common_btn = $('tbody .common, tbody .new, tbody .lock');
		for (let i = 0; i < common_btn.length; i++) {
			let read_num = common_btn.eq(i).find('.xw1').text();
			if (read_num) {
				read_num = Number(read_num);
				if (read_num > 90) {
					common_btn.eq(i).find('.xst').css({
						'color': '#999999',
						'font-weight': 'bold',
						'text-decoration-line': 'line-through',
						'text-decoration-color': '#000000',
					});
					continue
				} else if (read_num > access_num) {
					common_btn.eq(i).find('.xst').css({
						'color': '#999999',
						'font-weight': 'bold',
					});
					continue
				}
			}
			if (common_btn.eq(i).find('.xst').css('font-weight') === '700') {
				continue
			}
			let agree_num = 0;
			let font_ele = common_btn.eq(i).find('font');
			for (let j = 0; j < font_ele.length; j++) {
				let font_num = font_ele.eq(j).text();
				if (font_num) {
					font_num = Number(font_num.replace('+', ''));
					if (font_num > agree_num) {
						agree_num = font_num
					}
				}
			}
			if (agree_num > 0) {
				if (agree_num >= highlight_config.agree_threshold) {
					common_btn.eq(i).find('.xst').css({
						'color': highlight_config.agree_color,
						'font-weight': 'bold',
					});
					continue
				}
			}
			let reply_num = common_btn.eq(i).parent().find('td.num .xi2:first').text();
			if (reply_num) {
				reply_num = Number(reply_num);
				if (reply_num >= highlight_config.reply_threshold) {
					common_btn.eq(i).find('.xst').css({
						'color': highlight_config.reply_color,
						'font-weight': 'bold',
					})
				}
			}
		}
	}
	function insert_Checkbox(ul_node, li_array, check_enable_value) {
		let temp_li = document.createElement('li');
		temp_li.innerHTML = '<label style="vertical-align: middle;"><input id="' + li_array[0] + '" type="checkbox" style="margin-right: 5px; margin-bottom: 6px;"' + (check_enable_value === true ? 'checked' : '') + '>' + li_array[1] + '</label>';
		ul_node.appendChild(temp_li)
	}
	function insert_Input(ul_node, text_array, input_array, input_value, eg_array) {
		let temp_li = document.createElement('li');
		let text_span = document.createElement('span');
		text_span.id = text_array[0];
		text_span.innerText = text_array[1];
		text_span.style.marginLeft = '5px';
		temp_li.appendChild(text_span);
		let temp_input = document.createElement('input');
		temp_input.id = input_array[0];
		temp_input.placeholder = input_array[1];
		temp_input.value = input_value;
		temp_input.style.width = '120px';
		temp_li.appendChild(temp_input);
		if (arguments.length === 5) {
			let eg_span = document.createElement('span');
			eg_span.id = eg_array[0];
			eg_span.innerText = eg_array[1];
			eg_span.style.marginLeft = '5px';
			eg_span.style.color = input_value;
			temp_input.oninput = function() {
				eg_span.style.color = this.value
			};
			temp_li.appendChild(eg_span)
		}
		ul_node.appendChild(temp_li)
	}
	function create_Bt_Icon() {
		let icon_span = document.createElement('span');
		let bt_a = document.createElement('a');
		bt_a.className = 'btTool';
		bt_a.title = '磁力链接搜索工具';
		bt_a.target = '_self';
		bt_a.href = 'javascript:;';
		bt_a.style.backgroundColor = '#f4f4f4';
		bt_a.style.backgroundImage = BT_ICON.GRAY;
		bt_a.style.backgroundRepeat = 'no-repeat';
		bt_a.style.backgroundSize = '24px auto';
		bt_a.style.backgroundPosition = 'center';
		bt_a.style.visibility = 'visible';
		bt_a.style.position = 'fixed';
		bt_a.style.display = 'block';
		bt_a.style.border = '1px #cdcdcd solid';
		bt_a.style.borderRadius = '3px';
		bt_a.style.width = '40px';
		bt_a.style.height = '30px';
		bt_a.style.right = '10px';
		if (document.getElementsByClassName('codeTool').length > 0) {
			bt_a.style.top = '60px'
		} else {
			bt_a.style.top = '30px'
		}
		$(bt_a).hover(function() {
			this.style.backgroundImage = BT_ICON.BLUE
		}, function() {
			this.style.backgroundImage = BT_ICON.GRAY
		});
		$(bt_a).on('click', function() {
			if (document.getElementById(TOOL_VALUE.WRAP_DIV[0])) {
				document.getElementById(TOOL_VALUE.WRAP_DIV[0]).style.display = 'none'
			}
			if (document.getElementById(BT_VALUE.WRAP_DIV[0])) {
				if (document.getElementById(BT_VALUE.WRAP_DIV[0]).style.display === 'none') {
					document.getElementById(BT_VALUE.WRAP_DIV[0]).style.display = 'block'
				} else {
					document.getElementById(BT_VALUE.WRAP_DIV[0]).style.display = 'none'
				}
			} else {
				document.getElementById('hd').appendChild(create_Bt_Tag())
			}
		});
		icon_span.appendChild(bt_a);
		return icon_span
	}
	function create_Tool_Icon() {
		let icon_span = document.createElement('span');
		let tool_a = document.createElement('a');
		tool_a.className = 'codeTool';
		tool_a.title = '编码、解码工具';
		tool_a.target = '_self';
		tool_a.href = 'javascript:;';
		tool_a.style.backgroundColor = '#f4f4f4';
		tool_a.style.backgroundImage = TOOL_ICON.GRAY;
		tool_a.style.backgroundRepeat = 'no-repeat';
		tool_a.style.backgroundSize = '24px auto';
		tool_a.style.backgroundPosition = 'center';
		tool_a.style.visibility = 'visible';
		tool_a.style.position = 'fixed';
		tool_a.style.display = 'block';
		tool_a.style.border = '1px #cdcdcd solid';
		tool_a.style.borderRadius = '3px';
		tool_a.style.width = '40px';
		tool_a.style.height = '30px';
		tool_a.style.top = '30px';
		tool_a.style.right = '10px';
		$(tool_a).hover(function() {
			this.style.backgroundImage = TOOL_ICON.BLUE
		}, function() {
			this.style.backgroundImage = TOOL_ICON.GRAY
		});
		$(tool_a).on('click', function() {
			if (document.getElementById(BT_VALUE.WRAP_DIV[0])) {
				document.getElementById(BT_VALUE.WRAP_DIV[0]).style.display = 'none'
			}
			if (document.getElementById(TOOL_VALUE.WRAP_DIV[0])) {
				if (document.getElementById(TOOL_VALUE.WRAP_DIV[0]).style.display === 'none') {
					document.getElementById(TOOL_VALUE.WRAP_DIV[0]).style.display = 'block'
				} else {
					document.getElementById(TOOL_VALUE.WRAP_DIV[0]).style.display = 'none'
				}
			} else {
				document.getElementById('hd').appendChild(create_Tool_Tag())
			}
		});
		icon_span.appendChild(tool_a);
		return icon_span
	}
	function create_Operate_Button(text_array, callback, status = 0) {
		let operate_btn = document.createElement('button');
		operate_btn.className = 'pn pnc';
		operate_btn.id = text_array[0];
		operate_btn.innerText = text_array[1];
		operate_btn.title = text_array[2];
		operate_btn.style.height = 'auto';
		operate_btn.style.margin = '5px';
		operate_btn.style.padding = '0 5px';
		$(operate_btn).on('click', function() {
			let str = $('#' + TOOL_VALUE.LEFT_TEXTAREA[0]).val();
			let result = callback(str);
			if (result) {
				$('#' + TOOL_VALUE.RIGHT_TEXTAREA[0]).val(result);
				if (status === 0) {
					$('#' + TOOL_VALUE.STATUS_BAR[0]).text('编码完成!')
				} else {
					$('#' + TOOL_VALUE.STATUS_BAR[0]).text('解码完成!')
				}
			}
		});
		return operate_btn
	}
	function create_Col(width) {
		let col = document.createElement('col');
		col.width = width;
		return col
	}
	function create_Th(class_name, text_value, align_value = 0) {
		let th = document.createElement('th');
		th.className = class_name;
		th.innerText = text_value;
		if (align_value === 1) {
			th.style.textAlign = 'center'
		}
		return th
	}
	function create_Td(id_name, html_value, align_value = 0) {
		let td = document.createElement('td');
		td.id = id_name;
		td.innerHTML = html_value;
		if (align_value === 1) {
			td.style.textAlign = 'center'
		}
		return td
	}
	function create_Magnet_Result(num, name_html, format_size, hot, date, magnet) {
		let tr = document.createElement('tr');
		tr.appendChild(create_Td('btNum_' + num, num + 1, 1));
		tr.appendChild(create_Td('btName_' + num, name_html));
		tr.appendChild(create_Td('btSize_' + num, format_size, 1));
		tr.appendChild(create_Td('btHot_' + num, hot, 1));
		tr.appendChild(create_Td('btDate_' + num, date, 1));
		let temp_td = document.createElement('td');
		temp_td.style.textAlign = 'center';
		let copy_button = document.createElement('button');
		copy_button.id = 'btCopy_' + num;
		copy_button.className = 'pn pnc';
		copy_button.innerText = '复制';
		copy_button.title = '复制磁力链接';
		copy_button.style.padding = '0 5px';
		copy_button.style.marginRight = '0';
		copy_button.addEventListener('click', function() {
			GM_setClipboard(magnet);
			$('#' + BT_VALUE.STATUS_BAR[0]).text('复制成功!')
		});
		temp_td.appendChild(copy_button);
		tr.appendChild(temp_td);
		return tr
	}
	function search_Magnet(page_num = 1) {
		$('#' + BT_VALUE.STATUS_BAR[0]).text(BT_VALUE.STATUS_BAR[2]);
		let bt_details = {
			'method': 'GET',
			'url': 'http://www.gsi8.com/api/search?source=%E7%A7%8D%E5%AD%90%E6%90%9C&keyword=' + $('#' + BT_VALUE.SEARCH_INPUT[0]).val() + '&page=' + page_num + '&sort=time',
			'responseType': 'json',
			'headers': {
				'Content-Type': 'application/x-www-form-urlencoded'
			},
			'onload': function(res) {
				$('#' + BT_VALUE.TBODY[0]).empty();
				if (res.response.data) {
					if (res.response.data.results.length > 0) {
						let results = res.response.data.results;
						for (let i = 0; i < results.length; i++) {
							document.getElementById(BT_VALUE.TBODY[0]).appendChild(create_Magnet_Result(i, results[i].nameHtml, results[i].formatSize, results[i].hot, results[i].date, results[i].magnet))
						}
						if (results.length === 15) {
							document.getElementById(BT_VALUE.NEXT_PAGE_BUTTON[0]).style.display = 'inline-block'
						} else {
							document.getElementById(BT_VALUE.NEXT_PAGE_BUTTON[0]).style.display = 'none'
						}
					}
				} else {
					document.getElementById(BT_VALUE.NEXT_PAGE_BUTTON[0]).style.display = 'none'
				}
				bt_page_num = page_num;
				document.getElementById(BT_VALUE.PAGE_TEXT[0]).innerText = BT_VALUE.PAGE_TEXT[1] + bt_page_num;
				if (bt_page_num > 1) {
					document.getElementById(BT_VALUE.PREV_PAGE_BUTTON[0]).style.display = 'inline-block'
				} else {
					document.getElementById(BT_VALUE.PREV_PAGE_BUTTON[0]).style.display = 'none'
				}
				if (res.response.message) {
					$('#' + BT_VALUE.STATUS_BAR[0]).text(res.response.message)
				} else {
					$('#' + BT_VALUE.STATUS_BAR[0]).text(BT_VALUE.STATUS_BAR[3])
				}
			},
			'onerror': function() {
				$('#' + BT_VALUE.STATUS_BAR[0]).text('网络连接出问题啦!')
			}
		};
		GM_xmlhttpRequest(bt_details)
	}
	function create_Bt_Tag() {
		let wrap_div = document.createElement('div');
		wrap_div.id = BT_VALUE.WRAP_DIV[0];
		wrap_div.setAttribute('style', 'position: fixed; top:50%; left: 50%; z-index: 250; background-color: #fff; dispaly: block; padding: 0; margin: -300px 0 0 -450px; border: 1px solid #a0a0a0; border-radius: 3px; width: 900px; height: 600px;');
		let main_fieldset = document.createElement('fieldset');
		main_fieldset.id = BT_VALUE.MAIN_FIELDSET[0];
		main_fieldset.setAttribute('style', 'border: 3px solid #ccc; border-radius: 3px; padding: 4px 9px 6px 9px; margin: 8px; height: 540px;');
		wrap_div.appendChild(main_fieldset);
		let headline_legend = document.createElement('legend');
		headline_legend.id = BT_VALUE.HEADLINE_LEGEND[0];
		let headline_link = document.createElement('a');
		headline_link.id = BT_VALUE.HEADLINE_LINK[0];
		headline_link.innerText = BT_VALUE.HEADLINE_LINK[1];
		headline_link.title = BT_VALUE.HEADLINE_LINK[2];
		headline_link.href = BT_VALUE.HEADLINE_LINK[3];
		headline_link.target = '_blank';
		headline_legend.appendChild(headline_link);
		main_fieldset.appendChild(headline_legend);
		let top_bar = document.createElement('div');
		top_bar.id = BT_VALUE.TOP_BAR[0];
		main_fieldset.appendChild(top_bar);
		let search_input = document.createElement('input');
		search_input.id = BT_VALUE.SEARCH_INPUT[0];
		search_input.type = 'text';
		search_input.placeholder = BT_VALUE.SEARCH_INPUT[1];
		search_input.style.width = '400px';
		search_input.style.marginTop = '5px';
		search_input.oninput = function() {
			document.getElementById(BT_VALUE.PREV_PAGE_BUTTON[0]).style.display = 'none';
			document.getElementById(BT_VALUE.NEXT_PAGE_BUTTON[0]).style.display = 'none'
		};
		$(search_input).on('keyup', function(e) {
			if (e.keyCode === 13) {
				search_Magnet(1)
			}
		});
		top_bar.appendChild(search_input);
		let search_button = document.createElement('button');
		search_button.id = BT_VALUE.SEARCH_BUTTON[0];
		search_button.className = 'pn pnc';
		search_button.innerText = BT_VALUE.SEARCH_BUTTON[1];
		search_button.title = BT_VALUE.SEARCH_BUTTON[2];
		search_button.style.padding = '0 5px';
		search_button.style.marginLeft = '5px';
		search_button.addEventListener('click', function() {
			search_Magnet(1)
		});
		top_bar.appendChild(search_button);
		let prev_page_button = document.createElement('button');
		prev_page_button.id = BT_VALUE.PREV_PAGE_BUTTON[0];
		prev_page_button.innerText = BT_VALUE.PREV_PAGE_BUTTON[1];
		prev_page_button.title = BT_VALUE.PREV_PAGE_BUTTON[1];
		prev_page_button.className = 'pn pnc';
		prev_page_button.style.padding = '0 5px';
		prev_page_button.style.display = 'none';
		prev_page_button.addEventListener('click', function() {
			if (bt_page_num > 1) {
				search_Magnet(bt_page_num - 1)
			}
		});
		top_bar.appendChild(prev_page_button);
		let next_page_button = document.createElement('button');
		next_page_button.id = BT_VALUE.NEXT_PAGE_BUTTON[0];
		next_page_button.innerText = BT_VALUE.NEXT_PAGE_BUTTON[1];
		next_page_button.title = BT_VALUE.NEXT_PAGE_BUTTON[1];
		next_page_button.className = 'pn pnc';
		next_page_button.style.padding = '0 5px';
		next_page_button.style.display = 'none';
		next_page_button.addEventListener('click', function() {
			search_Magnet(bt_page_num + 1)
		});
		top_bar.appendChild(next_page_button);
		let page_text = document.createElement('span');
		page_text.id = BT_VALUE.PAGE_TEXT[0];
		page_text.innerText = BT_VALUE.PAGE_TEXT[1] + 0;
		page_text.style.float = 'right';
		page_text.style.marginRight = '5px';
		top_bar.appendChild(page_text);
		let middle_bar = document.createElement('div');
		middle_bar.id = BT_VALUE.MIDDLE_BAR[0];
		middle_bar.style.marginTop = '5px';
		main_fieldset.appendChild(middle_bar);
		let table_header_div = document.createElement('div');
		table_header_div.id = BT_VALUE.TABLE_HEADER_DIV[0];
		let table_header = document.createElement('table');
		table_header.id = BT_VALUE.TABLE_HEADER[0];
		table_header.border = '1';
		let colgroup_header = document.createElement('colgroup');
		colgroup_header.appendChild(create_Col(30));
		colgroup_header.appendChild(create_Col(560));
		colgroup_header.appendChild(create_Col(90));
		colgroup_header.appendChild(create_Col(50));
		colgroup_header.appendChild(create_Col(80));
		colgroup_header.appendChild(create_Col(50));
		table_header.appendChild(colgroup_header);
		let theader = document.createElement('thead');
		let theader_tr = document.createElement('tr');
		theader_tr.appendChild(create_Th(BT_VALUE.TH[0] + '1', '序号', 1));
		theader_tr.appendChild(create_Th(BT_VALUE.TH[0] + '2', '名称'));
		theader_tr.appendChild(create_Th(BT_VALUE.TH[0] + '3', '大小', 1));
		theader_tr.appendChild(create_Th(BT_VALUE.TH[0] + '4', '人气', 1));
		theader_tr.appendChild(create_Th(BT_VALUE.TH[0] + '5', '发布日期', 1));
		theader_tr.appendChild(create_Th(BT_VALUE.TH[0] + '6', '操作', 1));
		theader.appendChild(theader_tr);
		table_header.appendChild(theader);
		table_header_div.appendChild(table_header);
		middle_bar.appendChild(table_header_div);
		let table_body_div = document.createElement('div');
		table_body_div.id = BT_VALUE.TABLE_BODY_DIV[0];
		table_body_div.style.marginTop = '1px';
		middle_bar.appendChild(table_body_div);
		let table_body = document.createElement('table');
		table_body.id = BT_VALUE.TABLE_BODY[0];
		table_body.border = '1';
		table_body_div.appendChild(table_body);
		let colgroup_body = colgroup_header.cloneNode(true);
		table_body.appendChild(colgroup_body);
		let tbody = document.createElement('tbody');
		tbody.id = BT_VALUE.TBODY[0];
		table_body.appendChild(tbody);
		let close_btn = document.createElement('button');
		close_btn.className = 'pn pnc';
		close_btn.id = BT_VALUE.CLOSE_BUTTON[0];
		close_btn.innerText = BT_VALUE.CLOSE_BUTTON[1];
		close_btn.title = BT_VALUE.CLOSE_BUTTON[2];
		close_btn.setAttribute('style', 'position: relative; float: right; margin-right: 10px; padding: 0 5px;');
		close_btn.addEventListener('click', function() {
			document.getElementById(BT_VALUE.WRAP_DIV[0]).style.display = 'none'
		});
		wrap_div.appendChild(close_btn);
		let status_bar = document.createElement('span');
		status_bar.id = BT_VALUE.STATUS_BAR[0];
		status_bar.innerText = BT_VALUE.STATUS_BAR[1];
		status_bar.style.marginLeft = '10px';
		wrap_div.appendChild(status_bar);
		return wrap_div
	}
	function create_Tool_Tag() {
		let wrap_div = document.createElement('div');
		wrap_div.id = TOOL_VALUE.WRAP_DIV[0];
		wrap_div.setAttribute('style', 'position: fixed; top:50%; left: 50%; z-index: 250; background-color: #fff; dispaly: block; padding: 0; margin: -300px 0 0 -450px; border: 1px solid #a0a0a0; border-radius: 3px; width: 900px; height: 600px;');
		let main_fieldset = document.createElement('fieldset');
		main_fieldset.id = TOOL_VALUE.MAIN_FIELDSET[0];
		main_fieldset.setAttribute('style', 'border: 3px solid #ccc; border-radius: 3px; padding: 4px 9px 6px 9px; margin: 8px;');
		wrap_div.appendChild(main_fieldset);
		let headline_legend = document.createElement('legend');
		headline_legend.id = TOOL_VALUE.HEADLINE_LEGEND[0];
		headline_legend.innerText = TOOL_VALUE.HEADLINE_LEGEND[1];
		main_fieldset.appendChild(headline_legend);
		let left_bar = document.createElement('span');
		left_bar.id = TOOL_VALUE.LEFT_BAR[0];
		left_bar.style.float = 'left';
		main_fieldset.appendChild(left_bar);
		let left_title = document.createElement('div');
		left_title.id = TOOL_VALUE.LEFT_TITLE[0];
		left_title.innerText = TOOL_VALUE.LEFT_TITLE[1];
		left_bar.appendChild(left_title);
		let left_textarea = document.createElement('textarea');
		left_textarea.id = TOOL_VALUE.LEFT_TEXTAREA[0];
		left_textarea.placeholder = TOOL_VALUE.LEFT_TEXTAREA[1];
		left_textarea.setAttribute('style', 'width: 372px; height: 500px; border: 1px solid #ccc;');
		left_bar.appendChild(left_textarea);
		let operate_bar = document.createElement('span');
		operate_bar.id = TOOL_VALUE.OPERATE_BAR[0];
		operate_bar.style.float = 'left';
		operate_bar.style.width = '100px';
		operate_bar.style.marginTop = '20px';
		main_fieldset.appendChild(operate_bar);
		operate_bar.appendChild(create_Operate_Button(TOOL_VALUE.BJX_ENCODE, baijia_Encode, 0));
		operate_bar.appendChild(create_Operate_Button(TOOL_VALUE.BJX_DECODE, baijia_Decode, 1));
		operate_bar.appendChild(create_Operate_Button(TOOL_VALUE.JZG_ENCODE, values_Encode, 0));
		operate_bar.appendChild(create_Operate_Button(TOOL_VALUE.JZG_DECODE, values_Decode, 1));
		operate_bar.appendChild(create_Operate_Button(TOOL_VALUE.YFLC_ENCODE, function(str) {
			$('#' + TOOL_VALUE.STATUS_BAR[0]).text('编码中...');
			let encode_details = {
				'method': 'POST',
				'url': 'http://keyfc.net/bbs/tools/tudou.aspx',
				'data': 'orignalMsg=' + encodeURIComponent(str) + '&action=Encode',
				'headers': {
					'Content-Type': 'application/x-www-form-urlencoded'
				},
				'onload': function(res) {
					$('#' + TOOL_VALUE.RIGHT_TEXTAREA[0]).val(res.responseText.replace(/^<BUDDHIST><Message><!\[CDATA\[|\]\]><\/Message><\/BUDDHIST>$/g, ''));
					$('#' + TOOL_VALUE.STATUS_BAR[0]).text('编码完成!')
				},
				'onerror': function() {
					$('#' + TOOL_VALUE.RIGHT_TEXTAREA[0]).val('编码出现错误!');
					$('#' + TOOL_VALUE.STATUS_BAR[0]).text('编码完成!')
				}
			};
			GM_xmlhttpRequest(encode_details);
			return false
		}));
		operate_bar.appendChild(create_Operate_Button(TOOL_VALUE.YFLC_DECODE, function(str) {
			$('#' + TOOL_VALUE.STATUS_BAR[0]).text('解码中...');
			let decode_details = {
				'method': 'POST',
				'url': 'http://keyfc.net/bbs/tools/tudou.aspx',
				'data': 'orignalMsg=' + str.replace(/\s/g, '') + '&action=Decode',
				'headers': {
					'Content-Type': 'application/x-www-form-urlencoded'
				},
				'onload': function(res) {
					$('#' + TOOL_VALUE.RIGHT_TEXTAREA[0]).val(res.responseText.replace(/^<BUDDHIST><Message><!\[CDATA\[|\]\]><\/Message><\/BUDDHIST>$/g, ''));
					$('#' + TOOL_VALUE.STATUS_BAR[0]).text('解码完成!')
				},
				'onerror': function() {
					$('#' + TOOL_VALUE.RIGHT_TEXTAREA[0]).val('解码出现错误!');
					$('#' + TOOL_VALUE.STATUS_BAR[0]).text('解码完成!')
				}
			};
			GM_xmlhttpRequest(decode_details);
			return false
		}));
		operate_bar.appendChild(create_Operate_Button(TOOL_VALUE.BASE64_ENCODE, function(str) {
			str = CryptoJS.enc.Utf8.parse(str);
			return CryptoJS.enc.Base64.stringify(str)
		}, 0));
		operate_bar.appendChild(create_Operate_Button(TOOL_VALUE.BASE64_DECODE, function(str) {
			let words = CryptoJS.enc.Base64.parse(str);
			return words.toString(CryptoJS.enc.Utf8)
		}, 1));
		operate_bar.appendChild(create_Operate_Button(TOOL_VALUE.BAIDU_QUERY, function(str) {
			$('#' + TOOL_VALUE.STATUS_BAR[0]).text('查询提取码中...');
			let query_details = {
				'method': 'GET',
				'url': 'https://search.pandown.cn/api/query?surl=' + str.split('/').pop(),
				'responseType': 'json',
				'headers': {
					'Content-Type': 'application/x-www-form-urlencoded'
				},
				'onload': function(res) {
					if ((res.response.code === 0) && (res.response.data[0].password)) {
						$('#' + TOOL_VALUE.RIGHT_TEXTAREA[0]).val(res.response.data[0].password)
					} else {
						console.log(res.response.message);
						$('#' + TOOL_VALUE.RIGHT_TEXTAREA[0]).val('没有查询到提取码哦。')
					}
					$('#' + TOOL_VALUE.STATUS_BAR[0]).text('查询提取码完成!')
				},
				'onerror': function() {
					$('#' + TOOL_VALUE.RIGHT_TEXTAREA[0]).val('网络连接出问题啦。');
					$('#' + TOOL_VALUE.STATUS_BAR[0]).text('查询提取码完成!')
				}
			};
			GM_xmlhttpRequest(query_details);
			return false
		}));
		let right_bar = document.createElement('span');
		right_bar.id = TOOL_VALUE.RIGHT_BAR[0];
		right_bar.style.float = 'right';
		main_fieldset.appendChild(right_bar);
		let right_title = document.createElement('div');
		right_title.id = TOOL_VALUE.RIGHT_TITLE[0];
		right_title.innerText = TOOL_VALUE.RIGHT_TITLE[1];
		right_bar.appendChild(right_title);
		let right_textarea = document.createElement('textarea');
		right_textarea.id = TOOL_VALUE.RIGHT_TEXTAREA[0];
		right_textarea.placeholder = TOOL_VALUE.RIGHT_TEXTAREA[1];
		right_textarea.setAttribute('style', 'width: 372px; height: 500px; border: 1px solid #ccc;');
		right_bar.appendChild(right_textarea);
		let close_btn = document.createElement('button');
		close_btn.className = 'pn pnc';
		close_btn.id = TOOL_VALUE.CLOSE_BUTTON[0];
		close_btn.innerText = TOOL_VALUE.CLOSE_BUTTON[1];
		close_btn.title = TOOL_VALUE.CLOSE_BUTTON[2];
		close_btn.setAttribute('style', 'position: relative; float: right; margin-right: 10px; padding: 0 5px;');
		close_btn.addEventListener('click', function() {
			document.getElementById(TOOL_VALUE.WRAP_DIV[0]).style.display = 'none'
		});
		wrap_div.appendChild(close_btn);
		let copy_btn = document.createElement('button');
		copy_btn.className = 'pn pnc';
		copy_btn.id = TOOL_VALUE.COPY_BUTTON[0];
		copy_btn.innerText = TOOL_VALUE.COPY_BUTTON[1];
		copy_btn.title = TOOL_VALUE.COPY_BUTTON[2];
		copy_btn.setAttribute('style', 'position: relative; float: right; margin-right: 10px; padding: 0 5px;');
		copy_btn.addEventListener('click', function() {
			GM_setClipboard($('#' + TOOL_VALUE.RIGHT_TEXTAREA[0]).val());
			$('#' + TOOL_VALUE.STATUS_BAR[0]).text('复制成功!')
		});
		wrap_div.appendChild(copy_btn);
		let status_bar = document.createElement('span');
		status_bar.id = TOOL_VALUE.STATUS_BAR[0];
		status_bar.innerText = TOOL_VALUE.STATUS_BAR[1];
		status_bar.style.marginLeft = '10px';
		wrap_div.appendChild(status_bar);
		return wrap_div
	}
	function create_Setting_Tag() {
		let wrap_div = document.createElement('div');
		wrap_div.id = SETTING_VALUE.WRAP_DIV[0];
		wrap_div.setAttribute('style', 'position: fixed; top: 4vw; right: 2vw; z-index: 9999; background-color: #fff; text-align: left; display: block; padding: 0; margin: 0; border: 1px solid #a0a0a0; border-radius: 3px; color: #000; font-size: 13px; display: block;');
		let main_fieldset = document.createElement('fieldset');
		main_fieldset.id = SETTING_VALUE.MAIN_FIELDSET[0];
		main_fieldset.setAttribute('style', 'border: 3px solid #ccc; border-radius: 3px; padding: 4px 9px 6px 9px; margin: 8px; min-width: 300px; width: auto; height: auto;');
		wrap_div.appendChild(main_fieldset);
		let headline_legend = document.createElement('legend');
		headline_legend.id = SETTING_VALUE.HEADLINE_LEGEND[0];
		let headline_link = document.createElement('a');
		headline_link.id = SETTING_VALUE.HEADLINE_LINK[0];
		headline_link.innerText = SETTING_VALUE.HEADLINE_LINK[1];
		headline_link.title = SETTING_VALUE.HEADLINE_LINK[2];
		headline_link.href = SETTING_VALUE.HEADLINE_LINK[3];
		headline_link.target = '_blank';
		headline_legend.appendChild(headline_link);
		main_fieldset.appendChild(headline_legend);
		let tag_ul = document.createElement('ul');
		tag_ul.id = SETTING_VALUE.TAG_UL[0];
		tag_ul.setAttribute('style', 'list-style: none; padding-left: 0;');
		main_fieldset.appendChild(tag_ul);
		insert_Checkbox(tag_ul, SETTING_VALUE.HIGHLIGHT_CHECKBOX, highlight_config.highlight_enable);
		insert_Input(tag_ul, SETTING_VALUE.AGREE_NUMBER_TEXT, SETTING_VALUE.AGREE_NUMBER_INPUT, highlight_config.agree_threshold);
		insert_Input(tag_ul, SETTING_VALUE.AGREE_COLOR_TEXT, SETTING_VALUE.AGREE_COLOR_INPUT, highlight_config.agree_color, SETTING_VALUE.AGREE_COLOR_EG);
		insert_Input(tag_ul, SETTING_VALUE.REPLY_NUMBER_TEXT, SETTING_VALUE.REPLY_NUMBER_INPUT, highlight_config.reply_threshold);
		insert_Input(tag_ul, SETTING_VALUE.REPLY_COLOR_TEXT, SETTING_VALUE.REPLY_COLOR_INPUT, highlight_config.reply_color, SETTING_VALUE.REPLY_COLOR_EG);
		let br = document.createElement('li');
		br.innerHTML = '------------------------------------------------------------------';
		br.style.textAlign = 'center';
		tag_ul.appendChild(br);
		insert_Checkbox(tag_ul, SETTING_VALUE.FLOAT_CHECKBOX, highlight_config.float_enable);
		insert_Checkbox(tag_ul, SETTING_VALUE.CLICK_CHECKBOX, highlight_config.click_enable);
		insert_Checkbox(tag_ul, SETTING_VALUE.EXTRACT_CHECKBOX, highlight_config.extract_enable);
		insert_Checkbox(tag_ul, SETTING_VALUE.COPY_CHECKBOX, highlight_config.copy_enable);
		insert_Checkbox(tag_ul, SETTING_VALUE.PANDOWNLOAD_CHECKBOX, highlight_config.pandownload_enable);
		insert_Checkbox(tag_ul, SETTING_VALUE.QUERY_CHECKBOX, highlight_config.query_enable);
		let br_clone_1 = br.cloneNode(true);
		tag_ul.appendChild(br_clone_1);
		insert_Checkbox(tag_ul, SETTING_VALUE.CODE_CHECKBOX, highlight_config.code_enable);
		insert_Checkbox(tag_ul, SETTING_VALUE.BT_CHECKBOX, highlight_config.bt_enable);
		let br_clone_2 = br.cloneNode(true);
		tag_ul.appendChild(br_clone_2);
		insert_Input(tag_ul, SETTING_VALUE.TEXT_COLOR_TEXT, SETTING_VALUE.TEXT_COLOR_INPUT, highlight_config.text_color, SETTING_VALUE.TEXT_COLOR_EG);
		insert_Input(tag_ul, SETTING_VALUE.LINK_COLOR_TEXT, SETTING_VALUE.LINK_COLOR_INPUT, highlight_config.link_color, SETTING_VALUE.LINK_COLOR_EG);
		let br_clone_3 = br.cloneNode(true);
		tag_ul.appendChild(br_clone_3);
		let save_button = document.createElement('button');
		save_button.id = SETTING_VALUE.SAVE_BUTTON[0];
		save_button.className = 'pn pnc';
		save_button.type = 'button';
		save_button.setAttribute('style', 'position: relative; float: right; margin-right: 5px; margin-top: 5px; padding: 0 5px;');
		save_button.innerText = SETTING_VALUE.SAVE_BUTTON[1];
		save_button.title = SETTING_VALUE.SAVE_BUTTON[2];
		save_button.addEventListener('click', function() {
			highlight_config.highlight_enable = document.getElementById(SETTING_VALUE.HIGHLIGHT_CHECKBOX[0]).checked;
			highlight_config.agree_threshold = document.getElementById(SETTING_VALUE.AGREE_NUMBER_INPUT[0]).value;
			highlight_config.agree_color = document.getElementById(SETTING_VALUE.AGREE_COLOR_INPUT[0]).value;
			highlight_config.reply_threshold = document.getElementById(SETTING_VALUE.REPLY_NUMBER_INPUT[0]).value;
			highlight_config.reply_color = document.getElementById(SETTING_VALUE.REPLY_COLOR_INPUT[0]).value;
			highlight_config.copy_enable = document.getElementById(SETTING_VALUE.COPY_CHECKBOX[0]).checked;
			highlight_config.text_color = document.getElementById(SETTING_VALUE.TEXT_COLOR_INPUT[0]).value;
			highlight_config.link_color = document.getElementById(SETTING_VALUE.LINK_COLOR_INPUT[0]).value;
			highlight_config.float_enable = document.getElementById(SETTING_VALUE.FLOAT_CHECKBOX[0]).checked;
			highlight_config.extract_enable = document.getElementById(SETTING_VALUE.EXTRACT_CHECKBOX[0]).checked;
			highlight_config.pandownload_enable = document.getElementById(SETTING_VALUE.PANDOWNLOAD_CHECKBOX[0]).checked;
			highlight_config.query_enable = document.getElementById(SETTING_VALUE.QUERY_CHECKBOX[0]).checked;
			highlight_config.code_enable = document.getElementById(SETTING_VALUE.CODE_CHECKBOX[0]).checked;
			highlight_config.bt_enable = document.getElementById(SETTING_VALUE.BT_CHECKBOX[0]).checked;
			highlight_config.click_enable = document.getElementById(SETTING_VALUE.CLICK_CHECKBOX[0]).checked;
			GM_setValue('highlight_config', highlight_config);
			location.reload()
		});
		tag_ul.appendChild(save_button);
		let cancel_button = document.createElement('button');
		cancel_button.id = SETTING_VALUE.CANCEL_BUTTON[0];
		cancel_button.className = 'pn pnc';
		cancel_button.type = 'button';
		cancel_button.setAttribute('style', 'position: relative; float: left; margin-left: 5px; margin-top:5px; padding: 0 5px;');
		cancel_button.innerText = SETTING_VALUE.CANCEL_BUTTON[1];
		cancel_button.title = SETTING_VALUE.CANCEL_BUTTON[2];
		cancel_button.addEventListener('click', function(e) {
			document.getElementById(SETTING_VALUE.WRAP_DIV[0]).style.display = 'none';
			e.stopPropagation()
		});
		tag_ul.appendChild(cancel_button);
		return wrap_div
	}
	function init() {
		let old_url = location.href;
		if (check_Mobile_Page()) {
			if (highlight_config.highlight_enable) {
				if ((old_url.indexOf('mod=forumdisplay') !== -1) || (/forum-\d+-\d+\.html/i.test(old_url))) {
					let li_btn = $('ul li');
					$.each(li_btn, function(_index, item) {
						let reply_num = $(item).find('.num:first').text();
						if (reply_num) {
							reply_num = Number(/\d+/.exec(reply_num)[0]);
							if (reply_num >= highlight_config.reply_threshold) {
								$(item).find('div.thread-item-sub').css({
									'color': highlight_config.reply_color,
									'font-weight': 'bold',
								})
							}
						}
					})
				}
			}
			if ((old_url.indexOf('mod=viewthread') !== -1) || (/thread-\d+-\d+(?:-\d+)?\.html/i.test(old_url))) {
				$.each($('div.message img'), function(_index, item) {
					if (item.width === 224) {
						item.removeAttribute('height')
					}
				});
				let message_btn = $('div.message');
				for (let i = 0; i < message_btn.length; i++) {
					create_Good_Boy_Button(message_btn.eq(i), i, find_Link(message_btn.eq(i)), display_Text(message_btn.eq(i), highlight_config.text_color, '#efefef'), analysis_Text(message_btn.eq(i)[0]))
				}
			}
			Promise.all([GM_getValue('check_date')]).then(function(data) {
				if (data[0] !== undefined) {
					check_date = data[0]
				} else {
					check_date = '2000-1-1'
				}
				let now_date = get_Now_Date();
				if (now_date !== check_date) {
					GM_setValue('check_date', now_date);
					let check_btn;
					if ($('.bg > a').length !== 0) {
						check_btn = $('.bg > a')
					}
					if (check_btn.text() === '签到领奖') {
						check_btn[0].click()
					}
				}
			})
		} else {
			let html_background_color = $('html').css('background-color');
			if (highlight_config.highlight_enable) {
				if ((old_url.indexOf('mod=forumdisplay') !== -1) || (/forum-\d+-\d+\.html/i.test(old_url))) {
					highlight_Post();
					try {
						let observer = new MutationObserver(function() {
							highlight_Post()
						});
						let listener_container = document.querySelector("body");
						let option = {
							'childList': true,
							'subtree': true
						};
						observer.observe(listener_container, option)
					} catch (e) {
						console.log(e)
					}
				}
			}
			if (highlight_config.code_enable) {
				$('#scrolltop').after(create_Tool_Icon())
			}
			if (highlight_config.bt_enable) {
				$('#scrolltop').after(create_Bt_Icon())
			}
			if ((old_url.indexOf('mod=viewthread') !== -1) || (/thread-\d+-\d+(?:-\d+)?\.html/i.test(old_url))) {
				$.each($('td.t_f img'), function(_index, item) {
					let base_src = $(item).attr('file');
					if (BASE_IMAGE_REG.test(base_src)) {
						base_src = base_src.replace(BASE_IMAGE_REG, '$1');
						$(item).attr('file', base_src);
						item.src = base_src
					}
				});
				$.each($('.t_f img.zoom'), function(_index, item) {
					item.removeAttribute('height')
				});
				let td_btn = $('td.t_f');
				if (highlight_config.float_enable) {
					let favatar_btn = $('div.favatar').filter(function() {
						return $(this).closest('tbody').find('td div.locked').length === 0
					});
					for (let j = 0; j < td_btn.length; j++) {
						create_Good_Boy_Button(favatar_btn.eq(j), j, find_Link(td_btn.eq(j)), display_Text(td_btn.eq(j), highlight_config.text_color, html_background_color), analysis_Text(td_btn.eq(j)[0]), true)
					}
				} else {
					let main_btn = $('div.cm');
					for (let k = 0; k < td_btn.length; k++) {
						create_Good_Boy_Button(main_btn.eq(k), k, find_Link(td_btn.eq(k)), display_Text(td_btn.eq(k), highlight_config.text_color, html_background_color), analysis_Text(td_btn.eq(k)[0]))
					}
				}
				if (highlight_config.click_enable) {
					// $('.cm').arrive('.buttona', function() {
					// 	let click_status = true;
					// 	let uid_href = $('.vwmy a').attr('href');
					// 	let uid = /&uid=(\d+)/.exec(uid_href)[1];
					// 	let ratl_l = $('.ratl_l tr');
					// 	for (let ra = 0; ra < ratl_l.length; ra++) {
					// 		let rate_id = ratl_l[ra].id.replace(/rate_\d+_/, '');
					// 		if (rate_id === uid) {
					// 			click_status = false;
					// 			break
					// 		}
					// 	}
						// if (click_status) {
							document.querySelector(".buttona").click()
						// }
					// })
				}
				$.each($('div.sign a'), function(_index, item) {
					if (/member\.php\?mod=logging&action=logout/i.test(item.href)) {
						item.style.display = 'none'
					}
				})
			}
			let check_btn = $('a#fx_checkin_topb');
			if (check_btn.attr('initialized') !== 'true') {
				check_btn.click()
			}
		}
	}
	Promise.all([GM_getValue('highlight_config')]).then(function(data) {
		if (data[0] !== undefined) {
			highlight_config = data[0]
		} else {
			highlight_config = default_config
		}
		try {
			GM_registerMenuCommand('好孩子看得见 - 设置', function() {
				if (document.getElementById(SETTING_VALUE.WRAP_DIV[0])) {
					if (document.getElementById(SETTING_VALUE.WRAP_DIV[0]).style.display === 'none') {
						document.getElementById(SETTING_VALUE.WRAP_DIV[0]).style.display = 'block'
					} else {
						document.getElementById(SETTING_VALUE.WRAP_DIV[0]).style.display = 'none'
					}
				} else {
					let hd = document.getElementById('hd');
					if (hd) {
						hd.appendChild(create_Setting_Tag())
					} else {
						let header = document.getElementsByClassName('header')[0];
						if (header) {
							header.appendChild(create_Setting_Tag())
						}
					}
				}
			})
		} catch (e) {
			console.log(e)
		}
		init()
	}).
	catch (function(except) {
		console.log(except)
	})
})();