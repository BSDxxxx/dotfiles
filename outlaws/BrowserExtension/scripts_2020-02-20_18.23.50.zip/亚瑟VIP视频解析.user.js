// ==UserScript==
// @icon            https://appstatic.yaseok.com/static/src/images/favicon.ico
// @name            亚瑟VIP视频解析
// @namespace       https://fulibus.net/
// @author          fuliba
// @description     解析亚瑟vip视频
// @include         *yase*/video/view/*
// @include         *yase*/live/view/*
// @include         *huase*/video/view/*
// @Require         https://cdn.bootcss.com/jquery/1.8.3/jquery.min.js
// @Require         https://cdn.bootcss.com/clipboard.js/2.0.4/clipboard.js
// @version         0.0.8
// ==/UserScript==
//=============================================

(function () {
    'use strict';
    setAd = function () {};
    setPlayerAd = function () {};
    ad_time = -1;
    ad_time_auto = 0;
    $(".player-tips").remove();
    $("#" + si1).parent("fieldset").remove();
    $("#" + si2).remove();
    $("#" + si4).remove();
    $("#" + si5).remove();
    var h = '<div id="loadingTip" class="player-loading" style="bottom: 0; top: auto;"><div data-loading="正在请求数据..." class="load-indicator loading loading-light" style="width: 100px; height:100px;"></div></div>';
    $("#player").html(h);
    function copyM3u8(m3u8) {
        $(".btn.btn-primary.btn-share-copy").after('&nbsp;&nbsp;<button type="button" id="m3u8Link" class="btn btn-success"><i class="icon icon-link"></i> 获取M3U8</button>');
        new ClipboardJS('#m3u8Link', {
            text: function (trigger) {
                confirmModal('<span style="color: red; font-size: large;">M3U8地址已复制到粘贴板<br>使用N_m3u8DL-CLI等下载</span>', function () {}, true, false);
                return m3u8;
            }
        });
    }
    if (document.location.pathname.indexOf("/live/view/") >= 0) {
        $.get("/api/live/player_domain", {
            id: app.Info.id
        }, function (res) {
            if (res.code === 1) {
                $("#loadingTip").remove();
                copyM3u8(res.data);
            } else {
                $(".player-tips").remove();
                console.log('loadVipLive');
                if (m3u8_url) {
                    new HlsJsPlayer({
                        "id": "player",
                        "url": m3u8_url,
                        "playsinline": true,
                        "whitelist": [
                            ""
                        ],
                        "width": "100%",
                        "height": "100%",
                        "enterLogo": {
                            "url": "/static/assets/images/logo-pc.png?ver=2019101421",
                            "width": 102,
                            "height": 30
                        },
                        "enterBg": {
                            "color": "rgba(0,0,0,0.87)"
                        },
                        "enterTips": {
                            "background": "linear-gradient(to right, rgba(0,0,0,0.87), #3D96FD, rgba(86,195,248), #3D96FD, rgba(0,0,0,0.87))"
                        }
                    });
                    $("#loadingTip").remove();
                    $(".player-tips").remove();
                    copyM3u8(m3u8_url);
                } else {
                    confirmModal('<span style="color: red; font-size: large;">无法获取直播源地址！', function () {}, true, false);
                }
            }
        });
    } else if (document.location.pathname.indexOf("/video/view/") >= 0) {
        var videoApiUrl = "/api/video/player_domain";
        function loadVipVedio() {
            var tryToLoadM3u8 = function (res) {
                console.log("tryToLoadM3u8:", res.data);
                var ok = false;
                $.ajax({
                    url: res.data,
                    async: false,
                    type: "GET",
                    success: function (data, status) {
                        if (status === "success") {
                            setPlayer(res);
                            ok = true;
                            $("#loadingTip").remove();
                            $(".player-tips").remove();
                            copyM3u8(res.data);
                        }
                    },
                    error: function (xhr, status, error) {
                        console.log("tryToLoadM3u8 error:", error);
                    }
                });
                console.log("tryToLoadM3u8 success:", ok);
                return ok;
            }
            var m3u8Pool = ["//htwo.", "//dan1.", "//shuang2.", "//tou11.", "//tou22."];
            $.get(videoApiUrl, {
                id: 1116957
            }, function (res, status) {
                console.log(videoApiUrl, res.data, status);
                try {
                    var success = false;
                    if (res && res.code === 1) {
                        res.data = res.data.replace(/\/\w{8}\/\w{32}\//, poster_url.match(/\/\w{8}\/\w{32}\//)[0]);
                        if (!(success = tryToLoadM3u8(res))) {
                            for (var i = 0; i < m3u8Pool.length; i++) {
                                var m3u8Element = m3u8Pool[i];
                                res.data = res.data.replace(/\/\/\w+\./, m3u8Element);
                                if ((success = tryToLoadM3u8(res))) {
                                    break;
                                }
                            }
                        }
                    }
                    if (!success) {
                        confirmModal('<span style="color: red; font-size: large;">无法解析视频！</span>', function () {}, true, false);
                    }
                } catch (e) {
                    confirmModal('<span style="color: red; font-size: large;">' + e + '</span>', function () {}, true, false);
                }
            });
        }
        $.get(videoApiUrl, {
            id: app.Info.id
        }, function (res) {
            if (res.code === 1) {
                $("#loadingTip").remove();
                copyM3u8(res.data);
            } else {
                $(".player-tips").remove();
                console.log('loadVipVedio');
                loadVipVedio();
            }
        });
    }
})();
